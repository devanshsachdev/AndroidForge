package `in`.maahee.pos

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/** Native read-only invoice details. For the official, full invoice/alteration/payment
 * workflow use the original POS invoice in the authenticated web workspace.
 */
@Composable
fun InvoiceScreen(api: PosApi, id: Int, back: () -> Unit, openOriginal: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    var invoice by remember(id) { mutableStateOf<JSONObject?>(null) }
    var error by remember(id) { mutableStateOf("") }
    var loading by remember(id) { mutableStateOf(true) }
    var reload by remember(id) { mutableIntStateOf(0) }
    LaunchedEffect(id, reload) {
        loading = true
        try { invoice = api.sale(id); error = "" }
        catch (e: Exception) { error = e.message.orEmpty() }
        finally { loading = false }
    }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            TextButton(onClick = back) { Icon(Icons.Outlined.ArrowBack, null); Text("Back") }
        }
        item { BrandHeader("Invoice details", "Bill #$id", "Review items, taxes, payments and notes.") }
        item {
            PremiumCard {
                Text("Original POS invoice", style = MaterialTheme.typography.titleMedium, color = Wine)
                Text("Use the existing web invoice for the official receipt, tailoring details and all available actions. It may ask you to sign in to the website separately.",
                    style = MaterialTheme.typography.bodySmall, color = Subdued)
                Button(onClick = { openOriginal(id) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.OpenInBrowser, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open complete web invoice")
                }
            }
        }
        if (loading) item { Busy() }
        if (error.isNotEmpty()) item { ErrorCard(error) { reload++ } }
        invoice?.let { record ->
            val sale = record.getJSONObject("sale")
            val lines = record.optJSONArray("items")?.asObjects().orEmpty()
            val payments = record.optJSONArray("payments")?.asObjects().orEmpty()
            item {
                PremiumCard {
                    Text("MAAHEE — THE FASHION STUDIO", color = Gold,
                        style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    DividerLine()
                    InvoiceRow(sale)
                    DetailRow("Invoice date", sale.str("date"))
                    DetailRow("Customer", sale.str("customer_name"))
                    DetailRow("Status", sale.str("status"))
                    DetailRow("Store", sale.str("store_id"))
                    DetailRow("Employee", sale.str("employee_name"))
                }
            }
            item { SectionTitle("Items (${lines.size})") }
            items(lines) { line ->
                PremiumCard {
                    Text(line.str("product_name"), fontWeight = FontWeight.SemiBold)
                    DetailRow("Code", line.str("product_code"))
                    DetailRow("Quantity", line.str("quantity"))
                    DetailRow("Unit price", line.money("real_unit_price").rupees())
                    if (line.has("discount")) DetailRow("Item discount", line.str("discount"))
                    if (line.has("item_discount")) DetailRow("Discount value", line.money("item_discount").rupees())
                    if (line.has("tax")) DetailRow("Tax rate", line.str("tax"))
                    if (line.has("item_tax")) DetailRow("Item tax", line.money("item_tax").rupees())
                    if (line.str("comment").isNotBlank()) DetailRow("Item note", line.str("comment"))
                    DividerLine()
                    DetailRow("Line total", line.money("subtotal").rupees())
                }
            }
            item {
                PremiumCard {
                    Text("Invoice totals", style = MaterialTheme.typography.titleMedium)
                    listOf(
                        "Products" to "total",
                        "Item discount" to "product_discount",
                        "Order discount" to "order_discount",
                        "Tax on products" to "product_tax",
                        "Order tax" to "order_tax",
                        "Total tax" to "total_tax",
                        "Rounding" to "rounding",
                        "Reward discount" to "reward_amount",
                        "Points discount" to "points_discount"
                    ).forEach { (label, key) ->
                        if (sale.has(key) && sale.optString(key) != "null") DetailRow(label, sale.money(key).rupees())
                    }
                    DividerLine()
                    DetailRow("Grand total", sale.money("grand_total").rupees())
                    DetailRow("Paid", sale.money("paid").rupees())
                    DetailRow("Balance", (sale.money("grand_total") - sale.money("paid")).rupees())
                    if (sale.has("points_earned")) DetailRow("Points earned", sale.str("points_earned"))
                    if (sale.has("points_redeemed")) DetailRow("Points redeemed", sale.str("points_redeemed"))
                }
            }
            if (payments.isNotEmpty()) {
                item { SectionTitle("Recorded payments") }
                items(payments) { payment ->
                    PremiumCard {
                        DetailRow("Date", payment.str("date"))
                        DetailRow("Method", payment.str("paid_by"))
                        DetailRow("Amount", payment.money("amount").rupees())
                        DetailRow("Note", payment.str("note"))
                    }
                }
            }
            item {
                PremiumCard {
                    Text("Notes & fulfilment", style = MaterialTheme.typography.titleMedium)
                    DetailRow("Billing note", sale.str("billing_note").ifBlank { sale.str("note") })
                    DetailRow("Internal note (staff only)", sale.str("internal_note"))
                    DetailRow("Delivery date", sale.str("delivery_date"))
                    DetailRow("Tailoring stage", sale.str("tailoring_status"))
                    DetailRow("Alteration items", sale.str("tailoring_items"))
                }
            }
            item {
                PremiumCard {
                    Text("Quick mobile PDF", style = MaterialTheme.typography.titleMedium)
                    Text("This is a summary PDF. Use the original POS invoice above for the full official template.",
                        color = Subdued, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { Receipt.print(ctx, record) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Outlined.Print, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Print")
                        }
                        Button(onClick = { Receipt.share(ctx, record) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Outlined.Share, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Share PDF")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    if (value.isBlank() || value == "null") return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, color = Subdued, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
