package `in`.maahee.pos

import android.app.DownloadManager
import android.app.Dialog
import android.os.Message
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Button as AndroidButton
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.SslErrorHandler
import android.net.http.SslError
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.URLUtil
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

/** Clear the website session whenever the native staff member signs out or switches stores. */
object WebSession {
    fun clear() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }
}

/** Original POS web workflows embedded with their own authenticated web session.
 * This is deliberate: the mobile API has a bearer token, NOT a browser cookie.
 * Never send mobile bearer tokens to JS, cookies, or WebView headers.
 */
@Composable
fun LegacyWebScreen(baseUrl: String, path: String, onClose: () -> Unit, warning: String? = null) {
    val ctx = LocalContext.current
    val origin = remember(baseUrl) { Uri.parse(baseUrl.trimEnd('/')) }
    val posHost = origin.host.orEmpty()
    val safePath = if (path.trimStart('/').matches(Regex("[A-Za-z0-9_./?=&%~-]*"))) path.trimStart('/') else ""
    val entryUrl = "${baseUrl.trimEnd('/')}/$safePath"
    var progress by remember { mutableIntStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var currentUrl by remember { mutableStateOf(entryUrl) }
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val popupDialogs = remember(entryUrl) { mutableListOf<Dialog>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        fileCallback = null
    }

    val webView = remember(entryUrl) {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true // Required by the existing POS UI.
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true // Required for user-approved document/photo uploads.
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(true)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    val scheme = uri.scheme.orEmpty().lowercase()
                    if (scheme == "https" && uri.host.equals(posHost, ignoreCase = true)) return false
                    // Open external apps / other sites with the system, not in the privileged POS WebView.
                    if (scheme in listOf("https", "tel", "mailto", "sms")) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                        catch (_: Exception) { Toast.makeText(ctx, "No app available for this link", Toast.LENGTH_SHORT).show() }
                    }
                    return true
                }
                override fun onPageFinished(view: WebView, url: String) {
                    currentUrl = url
                    canGoBack = view.canGoBack()
                    canGoForward = view.canGoForward()
                }
                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    super.doUpdateVisitedHistory(view, url, isReload)
                    canGoBack = view.canGoBack()
                    canGoForward = view.canGoForward()
                    if (url != null) currentUrl = url
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, errorValue: WebResourceError) {
                    if (request.isForMainFrame) error = errorValue.description?.toString() ?: "Unable to load page"
                }
                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, sslError: SslError) {
                    handler.cancel() // Never bypass a certificate failure for POS/customer data.
                    error = "Secure connection could not be verified. Contact your POS administrator."
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress = newProgress
                    if (newProgress > 5) error = ""
                }
                override fun onShowFileChooser(
                    view: WebView, callback: ValueCallback<Array<Uri>>,
                    params: WebChromeClient.FileChooserParams
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    return try { picker.launch(params.createIntent()); true }
                    catch (e: Exception) {
                        callback.onReceiveValue(null)
                        fileCallback = null
                        error = "No compatible file picker installed"
                        true
                    }
                }
                // POS opens invoices, labels and print previews via target=_blank / window.open.
                // A contained child WebView preserves the same web cookies and supports blank
                // windows populated with document.write(), unlike a system-browser redirect.
                override fun onCreateWindow(
                    view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
                ): Boolean {
                    if (popupDialogs.size >= 3) return false
                    val dialog = Dialog(ctx)
                    val popup = WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                                val u = request.url
                                if ((u.scheme == "https" && u.host.equals(posHost, true)) || u.scheme == "about") return false
                                if (u.scheme == "https") {
                                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                                }
                                return true
                            }
                        }
                    }
                    val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                    val buttons = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                    val closeButton = AndroidButton(ctx).apply {
                        text = "Close"; setOnClickListener { dialog.dismiss() }
                    }
                    val printButton = AndroidButton(ctx).apply {
                        text = "Print"; setOnClickListener {
                            try {
                                val manager = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                                manager.print("Maahee POS document", popup.createPrintDocumentAdapter("Maahee Document"),
                                    PrintAttributes.Builder().build())
                            } catch (_: Exception) { Toast.makeText(ctx, "Print unavailable", Toast.LENGTH_SHORT).show() }
                        }
                    }
                    buttons.addView(closeButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    buttons.addView(printButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    root.addView(buttons)
                    root.addView(popup, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                    dialog.setContentView(root)
                    popup.webChromeClient = object : WebChromeClient() {
                        override fun onCloseWindow(window: WebView) { dialog.dismiss() }
                    }
                    dialog.setOnDismissListener {
                        popupDialogs.remove(dialog)
                        root.removeView(popup)
                        popup.destroy()
                    }
                    popupDialogs.add(dialog)
                    dialog.show()
                    dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    val transport = resultMsg.obj as WebView.WebViewTransport
                    transport.webView = popup
                    resultMsg.sendToTarget()
                    return true
                }
            }
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                val uri = Uri.parse(url)
                if (uri.scheme != "https" || !uri.host.equals(posHost, ignoreCase = true)) {
                    Toast.makeText(ctx, "Download blocked: unexpected host", Toast.LENGTH_SHORT).show()
                } else try {
                    val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                        .substringAfterLast('/').substringAfterLast('\\')
                        .replace(Regex("[^a-zA-Z0-9_.() -]"), "_")
                        .ifBlank { "pos-download" }
                    val request = DownloadManager.Request(uri)
                        .setMimeType(mimeType)
                        .setTitle(filename)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
                    if (userAgent.isNotBlank()) request.addRequestHeader("User-Agent", userAgent)
                    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                    Toast.makeText(ctx, "Downloading $filename", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Download unavailable: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            loadUrl(entryUrl)
        }
    }
    BackHandler {
        if (webView.canGoBack()) {
            webView.goBack()
            canGoBack = webView.canGoBack()
        } else onClose()
    }
    DisposableEffect(webView) {
        onDispose {
            popupDialogs.toList().forEach { it.dismiss() }
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            webView.stopLoading()
            webView.destroy()
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (webView.canGoBack()) webView.goBack() else onClose() }) {
                Icon(Icons.Outlined.ArrowBack, "Back")
            }
            IconButton(enabled = canGoForward, onClick = { webView.goForward() }) {
                Icon(Icons.Outlined.ArrowForward, "Forward")
            }
            IconButton(onClick = { webView.reload() }) { Icon(Icons.Outlined.Refresh, "Reload") }
            Column(Modifier.weight(1f)) {
                Text("WEB POS • FULL FEATURES", style = MaterialTheme.typography.labelSmall, color = Wine, fontWeight = FontWeight.Bold)
                Text(currentUrl.removePrefix(baseUrl.trimEnd('/')).ifBlank { "/" },
                    style = MaterialTheme.typography.labelSmall, maxLines = 1, color = Subdued)
            }
            TextButton(onClick = { webView.loadUrl(entryUrl) }) { Text("Page") }
            IconButton(onClick = {
                try {
                    val manager = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                    manager.print("Maahee Web POS", webView.createPrintDocumentAdapter("Maahee POS"), PrintAttributes.Builder().build())
                } catch (e: Exception) { Toast.makeText(ctx, "Print unavailable", Toast.LENGTH_SHORT).show() }
            }) { Icon(Icons.Outlined.Print, "Print web page") }
        }
        if (progress in 0..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        if (warning != null) {
            Text(warning, modifier = Modifier.padding(horizontal = 15.dp, vertical = 5.dp),
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (error.isNotBlank()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(error, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelSmall)
                TextButton(onClick = { error = ""; webView.reload() }) { Text("Retry") }
            }
        }
        // Website login is separate from bearer-token login. Once signed in here,
        // the same WebView cookie jar serves all original POS modules.
        androidx.compose.ui.viewinterop.AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
    }
}
