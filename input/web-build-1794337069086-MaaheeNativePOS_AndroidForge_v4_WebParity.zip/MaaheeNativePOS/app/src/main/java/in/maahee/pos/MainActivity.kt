package `in`.maahee.pos

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaaheeTheme { MaaheeApp() } }
    }
}

/**
 * Native core pages + the original, staff-authenticated website for feature parity.
 * The website deliberately keeps its own cookie session; mobile bearer tokens are
 * NEVER injected into the WebView or exposed to JavaScript.
 */
@Composable
fun MaaheeApp() {
    val ctx = LocalContext.current
    val auth = remember { AuthStore(ctx) }
    val api = remember { PosApi(auth) }
    val scope = rememberCoroutineScope()
    val billingDraft = remember { BillingDraft() }
    var loggedIn by remember { mutableStateOf(auth.token.isNotBlank()) }
    var store by remember { mutableIntStateOf(auth.storeId) }
    var page by remember { mutableStateOf("home") }
    var selectedSale by remember { mutableIntStateOf(0) }
    val history = remember { mutableStateListOf<String>() }
    var confirmExit by remember { mutableStateOf(false) }

    fun navigate(to: String) {
        if (to != page) {
            history.add(page)
            if (history.size > 30) history.removeAt(0)
            page = to
        }
    }
    fun back() {
        if (history.isNotEmpty()) page = history.removeAt(history.lastIndex)
        else if (page != "home") page = "home"
        else confirmExit = true
    }
    fun web(path: String) = navigate("web:" + path.trimStart('/'))

    BackHandler(enabled = true) {
        if (!loggedIn || store == 0 || (page == "home" && history.isEmpty())) {
            confirmExit = true
        } else back()
    }
    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave Maahee POS?") },
            text = { Text("Exit the app? Your unsaved billing cart is kept while the app remains running.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; (ctx as? Activity)?.finish() }) { Text("Exit") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay in POS") } }
        )
    }
    if (!loggedIn) {
        LoginScreen(auth, api) { payload ->
            auth.token = payload.str("token")
            auth.name = payload.optJSONObject("user")?.str("name") ?: "Team member"
            auth.storeId = payload.optInt("store_id", 0)
            store = auth.storeId
            history.clear()
            page = "home"
            loggedIn = true
        }
        return
    }
    if (store == 0) {
        SelectStoreScreen(api) { id -> store = id; auth.storeId = id }
        return
    }
    val title = when {
        page == "home" -> "Overview"
        page == "billing" -> "New Bill"
        page == "sales" -> "Sales"
        page == "products" -> "Products"
        page == "more" -> "All Modules"
        page.startsWith("sale:") -> "Invoice"
        page.startsWith("web:") -> "Full Web POS"
        page.startsWith("module:") -> allModules.find { it.id == page.removePrefix("module:") }?.title ?: "Module"
        else -> "Maahee"
    }
    Scaffold(
        containerColor = Cream,
        topBar = {
            Surface(color = Cream) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().height(66.dp).padding(horizontal = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (page != "home") {
                        IconButton(onClick = { back() }) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Wine) }
                    } else {
                        Icon(Icons.Outlined.AutoAwesome, "Maahee", tint = Gold, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(10.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("MAAHEE", fontWeight = FontWeight.Bold, color = Wine, style = MaterialTheme.typography.labelMedium)
                        Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { web("pos") }) { Icon(Icons.Outlined.OpenInBrowser, "Full billing", tint = Wine) }
                    IconButton(onClick = { navigate("more") }) { Icon(Icons.Outlined.Apps, "All modules", tint = Wine) }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                listOf(
                    Triple("home", "Home", Icons.Outlined.SpaceDashboard),
                    Triple("billing", "Bill", Icons.Outlined.PointOfSale),
                    Triple("sales", "Sales", Icons.Outlined.ReceiptLong),
                    Triple("products", "Stock", Icons.Outlined.Inventory2),
                    Triple("more", "More", Icons.Outlined.GridView)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = page == route,
                        onClick = { navigate(route) },
                        icon = { Icon(icon, null) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Wine,
                            selectedTextColor = Wine,
                            indicatorColor = Rose
                        )
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(220)) togetherWith
                    slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(160))
            },
            label = "screen",
            modifier = Modifier.fillMaxSize().padding(padding)
        ) { route ->
            when {
                route == "home" -> DashboardScreen(api, ::navigate)
                route == "billing" -> BillingScreen(api,
                    onSaved = { id -> selectedSale = id; navigate("sale:$id") },
                    draft = billingDraft,
                    openFullPos = { web("pos") })
                route == "sales" -> SalesScreen(api) { id -> selectedSale = id; navigate("sale:$id") }
                route == "products" -> ProductsScreen(api) { navigate("billing") }
                route == "more" -> ModuleMenuScreen(
                    auth, { m -> navigate("module:${m.id}") },
                    { scope.launch { try { api.logout() } catch (_: Exception) {} ; WebSession.clear(); auth.clear(); loggedIn = false; history.clear(); page = "home" } },
                    { WebSession.clear(); store = 0; auth.storeId = 0 },
                    onOpenWeb = { path -> web(path) }
                )
                route.startsWith("sale:") -> InvoiceScreen(api, selectedSale,
                    back = { back() }, openOriginal = { id -> web("pos/view/$id") })
                route.startsWith("web:") -> LegacyWebScreen(
                    auth.url, route.removePrefix("web:"), onClose = { back() })
                route.startsWith("module:") -> {
                    val module = allModules.find { it.id == route.removePrefix("module:") }
                    if (module == null) EmptyState("Unavailable module", "This feature is not defined.")
                    else if (module.kind == "planned") {
                        LegacyWebScreen(auth.url, module.legacyPath, onClose = { back() },
                            warning = if (module.sourceStatus == "Unresolved")
                                "This legacy route was unresolved in the source audit. It may not open until the web POS is repaired."
                            else null)
                    } else ModuleScreen(module, api,
                        onBill = { navigate("billing") },
                        onSale = { id -> selectedSale = id; navigate("sale:$id") },
                        onWeb = { path -> web(path) }, onNavigate = ::navigate)
                }
            }
        }
    }
}
