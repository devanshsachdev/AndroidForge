package `in`.maahee.pos

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Native billing flow. Product prices/taxes are calculated again by the server. */
data class BasketLine(val productId: Int, val code: String, val name: String,
    val price: Double, val stock: Int, val quantity: Int = 1, val discountPercent: Double = 0.0)
class BillingDraft {
    val lines = mutableStateListOf<BasketLine>()
    var customer by mutableStateOf<JSONObject?>(null)
    var orderDiscount by mutableStateOf("0")
    var paid by mutableStateOf("")
    var paidEdited by mutableStateOf(false)
    var method by mutableStateOf("cash")
    var note by mutableStateOf("")
    var checkoutKey by mutableStateOf(UUID.randomUUID().toString())
    fun clear() { lines.clear();customer=null;orderDiscount="0";paid="";paidEdited=false;note="";checkoutKey=UUID.randomUUID().toString() }
}

@Composable fun BillingScreen(api: PosApi, onSaved: (Int)->Unit, draft: BillingDraft = remember { BillingDraft() }, openFullPos: () -> Unit = {}) {
    val scope=rememberCoroutineScope()
    val ctx=LocalContext.current
    var search by remember{mutableStateOf("")}
    var products by remember {mutableStateOf<List<JSONObject>>(emptyList())}
    var quote by remember{mutableStateOf<JSONObject?>(null)}
    var checking by remember{mutableStateOf(false)}
    var saving by remember{mutableStateOf(false)}
    var error by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var showCustomer by remember{mutableStateOf(false)}
    var showNewCustomer by remember{mutableStateOf(false)}
    var loadingSearch by remember{mutableStateOf(false)}
    LaunchedEffect(search) {
        if(search.isBlank()){products=emptyList();return@LaunchedEffect}
        delay(240);loadingSearch=true
        try {products=api.products(search).asObjects()}
        catch(e:Exception){error=e.message.orEmpty()}
        finally{loadingSearch=false}
    }
    val cartIdentity=draft.lines.joinToString("|"){"${it.productId}:${it.quantity}:${it.discountPercent}"}
    val discount=draft.orderDiscount
    LaunchedEffect(cartIdentity, discount) {
        if(draft.lines.isEmpty()){quote=null;return@LaunchedEffect}
        delay(250);checking=true
        try {
            quote=api.quote(draft.toPayload())
            if(!draft.paidEdited) draft.paid=String.format(java.util.Locale.US,"%.2f",quote!!.money("grand_total"))
            error=""
        }catch(e:Exception){quote=null;error=e.message.orEmpty()}
        finally{checking=false}
    }
    if(showCustomer)CustomerPicker(api,onDismiss={showCustomer=false},onSelect={draft.customer=it;showCustomer=false},
        onNew={showCustomer=false;showNewCustomer=true})
    if(showNewCustomer)NewCustomerDialog(api,onDismiss={showNewCustomer=false},onSaved={showNewCustomer=false;showCustomer=true})

    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {BrandHeader("Point of sale","Create an invoice","Native quick bill or the full original POS workflow.")}
        item {PremiumCard {
            Text("Full-featured invoicing", style = MaterialTheme.typography.titleMedium, color = Wine)
            Text("For split payments, gift cards, credit notes, reward points, delivery and alterations, open your existing POS billing page inside the app.",
                color = Subdued, style = MaterialTheme.typography.bodySmall)
            Button(onClick = openFullPos, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.OpenInBrowser, null)
                Spacer(Modifier.width(8.dp))
                Text("Full POS billing • all web options")
            }
        }}
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                SearchBar(search,{search=it},"Scan or search a product",Modifier.weight(1f))
                FilledIconButton(onClick={
                    GmsBarcodeScanning.getClient(ctx).startScan()
                        .addOnSuccessListener { barcode ->
                            barcode.rawValue?.let { search=it }
                        }.addOnFailureListener { e -> error=e.message ?: "Scanning unavailable" }
                },modifier=Modifier.size(52.dp)) {Icon(Icons.Outlined.QrCodeScanner,"Scan barcode")}
            }
        }
        if(loadingSearch)item{Busy()}
        if(products.isNotEmpty()) {
            item {Text("SEARCH RESULTS",color=Gold,style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold,letterSpacing=1.sp)}
            items(products.take(8),key={it.optInt("id")}){p->
                val inCart=draft.lines.any{it.productId==p.optInt("id")}
                PremiumCard {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.str("name"),fontWeight=FontWeight.SemiBold,maxLines=2)
                            Text("${p.str("code")} · ${p.optInt("quantity")} available",color=Subdued,style=MaterialTheme.typography.bodySmall)
                        }
                        Text(p.money("store_price").rupees(),color=Wine,fontWeight=FontWeight.Bold)
                        IconButton(onClick={
                            val id=p.optInt("id")
                            val i=draft.lines.indexOfFirst{it.productId==id}
                            if(i>=0){val old=draft.lines[i];draft.lines[i]=old.copy(quantity=old.quantity+1)}
                            else draft.lines.add(BasketLine(id,p.str("code"),p.str("name"),p.money("store_price"),p.optInt("quantity")))
                            search="";products=emptyList()
                        },enabled=p.optInt("quantity")>0 && (!inCart || draft.lines.first{it.productId==p.optInt("id")}.quantity<p.optInt("quantity"))) {
                            Icon(Icons.Outlined.AddCircle,null,tint=Wine)
                        }
                    }
                }
            }
        }
        item {SectionTitle("Cart (${draft.lines.sumOf{it.quantity}} items)",if(draft.lines.isNotEmpty())"Clear" else "") { draft.clear() }}
        if(draft.lines.isEmpty()) item { EmptyState("Your cart is waiting","Search or scan an item to get started.") }
        items(draft.lines,key={it.productId}) {line ->
            PremiumCard {
                Text(line.name,fontWeight=FontWeight.SemiBold)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text(line.price.rupees(),color=Subdued,modifier=Modifier.weight(1f))
                    IconButton(onClick={
                        val idx=draft.lines.indexOfFirst{it.productId==line.productId}
                        if(idx>=0){if(line.quantity<=1)draft.lines.removeAt(idx)
                            else draft.lines[idx]=line.copy(quantity=line.quantity-1)}
                    }){Icon(Icons.Outlined.RemoveCircleOutline,"Decrease")}
                    Text("${line.quantity}",fontWeight=FontWeight.Bold)
                    IconButton(onClick={
                        val idx=draft.lines.indexOfFirst{it.productId==line.productId}
                        if(idx>=0 && line.quantity<line.stock)draft.lines[idx]=line.copy(quantity=line.quantity+1)
                    }){Icon(Icons.Outlined.AddCircleOutline,"Increase")}
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("Item discount %",modifier=Modifier.weight(1f),color=Subdued)
                    var discountText by remember(line.productId){mutableStateOf(line.discountPercent.toString())}
                    OutlinedTextField(discountText,onValueChange={new->
                        discountText=new
                        new.toDoubleOrNull()?.let { v ->
                            if(v>=0 && v<=100){val i=draft.lines.indexOfFirst{it.productId==line.productId}
                                if(i>=0)draft.lines[i]=line.copy(discountPercent=v)}
                        }
                    },singleLine=true,modifier=Modifier.width(105.dp),
                        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                }
            }
        }
        if(draft.lines.isNotEmpty()) {
            item {SectionTitle("Customer")}
            item {PremiumCard {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Outlined.PersonOutline,null,tint=Gold)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(draft.customer?.str("name") ?: "Select customer",fontWeight=FontWeight.SemiBold)
                        Text(draft.customer?.str("phone") ?: "Required before saving invoice",color=Subdued,style=MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick={showCustomer=true}){Text("Choose")}
                }
            }}
            item {SectionTitle("Discount & notes")}
            item {PremiumCard {
                OutlinedTextField(draft.orderDiscount,{draft.orderDiscount=it},label={Text("Order discount (%)")},
                    modifier=Modifier.fillMaxWidth(),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                OutlinedTextField(draft.note,{draft.note=it},label={Text("Billing note (optional)")},modifier=Modifier.fillMaxWidth(),minLines=2)
            }}
            item {SectionTitle("Payment")}
            item {PremiumCard {
                Text("Payment method",color=Subdued)
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("cash" to "Cash","upi" to "UPI","card" to "Card","other" to "Other").forEach{(method,label)->
                        FilterChip(selected=draft.method==method,onClick={draft.method=method},label={Text(label)})
                    }
                }
                OutlinedTextField(draft.paid,{draft.paid=it;draft.paidEdited=true},label={Text("Amount received (₹)")},
                    modifier=Modifier.fillMaxWidth(),singleLine=true,
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                Text("UPI and card selections record an externally received payment; the app does not process bank transactions.",
                    color=Subdued,style=MaterialTheme.typography.bodySmall)
            }}
            item {PremiumCard {
                Text("TOTAL PREVIEW",color=Gold,style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold)
                if(checking) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Gold)
                quote?.let { q ->
                    TotalRow("Subtotal",q.money("subtotal").rupees())
                    TotalRow("Tax",q.money("tax").rupees())
                    TotalRow("Order discount","−${q.money("order_discount").rupees()}")
                    DividerLine()
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Text("Grand total",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f))
                        Text(q.money("grand_total").rupees(),fontSize=24.sp,fontWeight=FontWeight.Bold,color=Wine)
                    }
                    Text("Total is calculated by the live server; payment is not authorized by this screen.",color=Subdued,style=MaterialTheme.typography.bodySmall)
                }
                if(error.isNotBlank()) ErrorCard(error)
                if(message.isNotBlank()) SuccessCard(message)
                Button(onClick={
                    saving=true;error="";message=""
                    scope.launch {
                        try {
                            val payload=draft.toPayload()
                                .put("customer_id",draft.customer?.optInt("id") ?: 0)
                                .put("paid",draft.paid.toDoubleOrNull() ?: 0.0)
                                .put("payment_method",draft.method)
                                .put("note",draft.note)
                                .put("request_id",draft.checkoutKey)
                            val result=api.checkout(payload)
                            val id=result.optInt("sale_id")
                            draft.clear()
                            message="Invoice #$id created"
                            onSaved(id)
                        } catch(e:Exception){error=e.message ?: "Invoice not saved"}
                        finally {saving=false}
                    }
                },enabled=!saving && !checking && quote!=null && draft.customer!=null,
                    modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(13.dp)) {
                    if(saving)CircularProgressIndicator(Modifier.size(18.dp),color=Color.White,strokeWidth=2.dp)
                    else {Icon(Icons.Outlined.CheckCircle,null);Spacer(Modifier.width(8.dp));Text("Save invoice")}
                }
            }}
        }
    }
}
private fun BillingDraft.toPayload(): JSONObject {
    val items=JSONArray()
    lines.forEach { line -> items.put(JSONObject().put("product_id",line.productId)
        .put("quantity",line.quantity).put("discount_percent",line.discountPercent)) }
    return JSONObject().put("items",items).put("order_discount_percent",orderDiscount.toDoubleOrNull() ?: 0.0)
}
@Composable private fun TotalRow(label:String,value:String) {
    Row(Modifier.fillMaxWidth()) { Text(label,Modifier.weight(1f),color=Subdued);Text(value,fontWeight=FontWeight.SemiBold) }
}
@Composable fun CustomerPicker(api:PosApi,onDismiss:()->Unit,onSelect:(JSONObject)->Unit,onNew:()->Unit) {
    var query by remember{mutableStateOf("")}
    var data by remember{mutableStateOf<List<JSONObject>>(emptyList())}
    var error by remember{mutableStateOf("")}
    LaunchedEffect(query){ delay(250);try{data=api.customers(query).asObjects()}catch(e:Exception){error=e.message.orEmpty()} }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Choose customer")},text={
        Column {
            SearchBar(query,{query=it},"Name or mobile")
            if(error.isNotBlank())Text(error,color=Color.Red)
            Spacer(Modifier.height(9.dp))
            LazyColumn(Modifier.heightIn(max=340.dp)){
                items(data,key={it.optInt("id")}){c->
                    Row(Modifier.fillMaxWidth().clickable{onSelect(c)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {Text(c.str("name"),fontWeight=FontWeight.SemiBold);Text(c.str("phone"),color=Subdued,style=MaterialTheme.typography.bodySmall)}
                        Icon(Icons.Outlined.Add,null,tint=Wine)
                    }
                    DividerLine()
                }
            }
        }
    },confirmButton={TextButton(onClick=onNew){Text("Add new")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})
}
