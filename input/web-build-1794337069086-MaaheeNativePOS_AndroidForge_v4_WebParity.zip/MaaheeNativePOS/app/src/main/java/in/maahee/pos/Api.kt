package `in`.maahee.pos

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class ApiException(message: String) : Exception(message)

class AuthStore(context: Context) {
    private val preferences = context.getSharedPreferences("maahee_native_settings", Context.MODE_PRIVATE)
    private val alias = "maahee_native_token"
    var url: String
        get() {
            val saved = preferences.getString("url", "https://pos.maahee.co.in") ?: ""
            // Migrate the incorrect host shipped in the first source release.
            return if (saved.trimEnd('/').equals("https://pos.apsarasbawree.in", ignoreCase = true))
                "https://pos.maahee.co.in" else saved
        }
        set(value) { preferences.edit().putString("url", value.trimEnd('/')).apply() }
    var name: String
        get() = preferences.getString("name", "") ?: ""
        set(value) { preferences.edit().putString("name", value).apply() }
    var storeId: Int
        get() = preferences.getInt("store", 0)
        set(value) { preferences.edit().putInt("store", value).apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return gen.generateKey()
    }
    var token: String
        get() = try {
            val blob = preferences.getString("token", "") ?: ""
            if (blob.isEmpty()) "" else {
                val bytes = Base64.decode(blob, Base64.NO_WRAP)
                val iv = bytes.copyOfRange(0, 12)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
            }
        } catch (_: Exception) { "" }
        set(value) {
            if (value.isEmpty()) { preferences.edit().remove("token").apply(); return }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val bytes = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            preferences.edit().putString("token", Base64.encodeToString(bytes, Base64.NO_WRAP)).apply()
        }
    fun clear() { token = ""; name = ""; storeId = 0 }
}

class PosApi(private val auth: AuthStore) {
    private val client = OkHttpClient.Builder()
        .callTimeout(35, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()
    private val json = "application/json; charset=utf-8".toMediaType()
    private suspend fun request(path: String, payload: JSONObject? = null, bearer: Boolean = true): JSONObject =
        withContext(Dispatchers.IO) {
            val base = auth.url.trimEnd('/')
            if (!base.startsWith("https://", ignoreCase = true)) throw ApiException("A secure HTTPS POS address is required")
            val builder = Request.Builder().url("$base/api/mobile/$path")
                .header("Accept", "application/json")
                .header("Cache-Control", "no-store")
            if (bearer && auth.token.isNotEmpty()) builder.header("Authorization", "Bearer ${auth.token}")
            if (payload == null) builder.get() else builder.post(payload.toString().toRequestBody(json))
            try {
                client.newCall(builder.build()).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    val obj = try { JSONObject(raw) } catch (_: Exception) {
                        throw ApiException("The server did not return JSON (${response.code}). Check the API installation.")
                    }
                    if (!response.isSuccessful || !obj.optBoolean("success", false)) {
                        throw ApiException(obj.optString("message", "Request failed (${response.code})"))
                    }
                    obj
                }
            } catch (e: ApiException) { throw e }
              catch (e: Exception) { throw ApiException(e.localizedMessage ?: "Unable to reach your POS server") }
        }
    private fun esc(s: String): String = java.net.URLEncoder.encode(s, "UTF-8")
    suspend fun login(identity: String, password: String): JSONObject =
        request("login", JSONObject().put("identity", identity).put("password", password), false).getJSONObject("data")
    suspend fun logout() { request("logout", JSONObject()) }
    suspend fun me(): JSONObject = request("me").getJSONObject("data")
    suspend fun stores(): JSONArray = request("stores").getJSONArray("data")
    suspend fun selectStore(id: Int): JSONObject = request("set_store", JSONObject().put("store_id", id)).getJSONObject("data")
    suspend fun registerStatus(): JSONObject = request("register_status").getJSONObject("data")
    suspend fun openRegister(cash: Double): JSONObject =
        request("open_register",JSONObject().put("cash_in_hand",cash)).getJSONObject("data")
    suspend fun dashboard(): JSONObject = request("dashboard").getJSONObject("data")
    suspend fun products(query: String): JSONArray = request("products?q=${esc(query)}").getJSONArray("data")
    suspend fun customers(query: String): JSONArray = request("customers?q=${esc(query)}").getJSONArray("data")
    suspend fun createCustomer(name: String, mobile: String, email: String): JSONObject =
        request("create_customer", JSONObject().put("name", name).put("phone", mobile).put("email", email)).getJSONObject("data")
    suspend fun sales(query: String): JSONArray = request("sales?q=${esc(query)}").getJSONArray("data")
    suspend fun sale(id: Int): JSONObject = request("sale/$id").getJSONObject("data")
    suspend fun records(resource: String, query: String): JSONArray = request("records/$resource?q=${esc(query)}").getJSONArray("data")
    suspend fun tracker(): JSONArray = request("tracker").getJSONArray("data")
    suspend fun trackerStatus(saleId: Int, status: String): JSONObject =
        request("tracker_status", JSONObject().put("sale_id", saleId).put("status", status)).getJSONObject("data")
    suspend fun quote(payload: JSONObject): JSONObject = request("quote", payload).getJSONObject("data")
    suspend fun checkout(payload: JSONObject): JSONObject = request("checkout", payload).getJSONObject("data")
}

fun JSONArray.asObjects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONObject.str(name: String): String = optString(name, "").takeUnless { it == "null" } ?: ""
fun JSONObject.money(name: String): Double = optDouble(name, 0.0)
fun String.rupees(): String = "₹" + String.format(java.util.Locale("en", "IN"), "%,.2f", this.toDoubleOrNull() ?: 0.0)
fun Double.rupees(): String = "₹" + String.format(java.util.Locale("en", "IN"), "%,.2f", this)
