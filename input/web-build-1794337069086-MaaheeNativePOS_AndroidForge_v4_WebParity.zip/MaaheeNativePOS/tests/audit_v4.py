"""Static preflight for the AndroidForge v4 hybrid package (not a Gradle build)."""
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
K = ROOT/'app/src/main/java/in/maahee/pos'
main = (K/'MainActivity.kt').read_text()
api = (K/'Api.kt').read_text()
web = (K/'LegacyWeb.kt').read_text()
billing = (K/'Billing.kt').read_text()
invoice = (K/'Invoice.kt').read_text()
modules = (K/'Modules.kt').read_text()
assert (ROOT/'settings.gradle.kts').exists() and (ROOT/'app/build.gradle.kts').exists()
assert len(re.findall(r'\bModuleItem\("route_\d+"',modules)) == 74
assert 'https://pos.maahee.co.in' in api
assert 'https://pos.apsarasbawree.in' in api  # migration ONLY
assert 'BackHandler(enabled = true)' in main
assert 'confirmExit' in main and 'history.removeAt(history.lastIndex)' in main
assert 'LegacyWebScreen(auth.url' in main
assert 'openFullPos = { web("pos") }' in main
assert 'web("pos/view/$id")' in main
assert 'WebSession.clear()' in main
assert 'addJavascriptInterface' not in web
assert 'handler.cancel()' in web
assert 'uri.host.equals(posHost' in web
assert 'onShowFileChooser' in web
assert 'setDownloadListener' in web
assert 'createPrintDocumentAdapter' in web
assert 'onCreateWindow' in web and 'WebView.WebViewTransport' in web
assert 'WebStorage.getInstance().deleteAllData()' in web
assert 'split payments' in billing.lower() and 'gift cards' in billing.lower()
assert 'Original POS invoice' in invoice and 'payments' in invoice
assert 'LockOutline' not in ''.join(p.read_text() for p in K.glob('*.kt'))
ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
for x in (ROOT/'app/src/main/res').rglob('*.xml'):ET.parse(x)
php = ROOT/'backend/app/controllers/api/Mobile.php'
cp = subprocess.run(['php','-l',str(php)], capture_output=True, text=True)
assert cp.returncode == 0, cp.stdout+cp.stderr
print('PASS: Gradle root, URL migration, all 74 routes, Back stack and exit confirmation')
print('PASS: 7 unresolved routes still flagged; original web + 2 independent auth sessions')
print('PASS: Full-web invoice entry and details; WebView same-origin/TLS/file/print/download handling')
print('PASS: Android XML parse; PHP syntax; previous LockOutline issue absent')
print('NOT TESTED: Gradle/Kotlin compilation, APK build, device navigation, browser login, real POS writes')
