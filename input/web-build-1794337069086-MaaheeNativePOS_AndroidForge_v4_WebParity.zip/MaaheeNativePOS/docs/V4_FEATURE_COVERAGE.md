# v4 — Feature coverage and limitations

| Workflow | Native in v4 | Original website in app | Notes |
|---|---|---|---|
| Account login, store select | Yes (mobile bearer) | Yes (independent PHP web cookie) | Website login is separate on first visit |
| Dashboard, native navigation, animation | Yes | Yes | Android Back now navigates instead of instantly exiting |
| Quick cart, barcode, customer select, quote | Yes | Yes | Native checkout off until tax/stock/serial parity is certified |
| Full POS invoice entry | Limited quick bill | Original `/pos` | The web form includes split payments, gift cards, credit notes, reward/loyalty, delivery, alteration, notes and more |
| Sales history, invoice display | Native read-only | Original `/pos/view/{id}` | Native PDF is a summary; use web receipt for full original format |
| Products, customers, stock | Native core read/search/create customer | Web CRUD, imports, adjustments | Native product/customer edits not yet API implemented |
| Register open and status | Yes | Web register close/reconciliation | Financial controls need staging validation |
| Tailor tracker | Native stage updates | Web tailoring screens | Verify staff permissions |
| Purchases, suppliers, expenses, gift cards, credit notes | Native records mostly read-only | Original create/edit/settle pages | Web source remains authority for mutations |
| Analytics, reports, employees, settings, printers, labels | Module directory + web entry | Original web pages | Some pages may require desktop layout/external printer hardware |
| 7 unresolved links in original navigation | Marked as unverified | Attempt original URL | Site route/server repair required; don't claim working |

## Two levels of functionality

1. **Native**: uses a dedicated server-side authenticated mobile API, and only exposed writes use that API.
2. **Web**: loads the existing PHP website inside a same-origin, HTTPS-only WebView. This provides access to existing original forms without reimplementing financial logic. It is not a claim that those forms have been rewritten natively.

## Invoice paths

- `/pos` — original web POS billing, with its complete options.
- `/pos/view/{sale_id}` — original invoice view (verified in `app/controllers/Pos.php`).
- Native sales invoice — shows available API fields including line discounts, tax, payment history, delivery/tailoring and notes; uses the separate mobile API.

## Test before release

1. Back on dashboard -> confirmation; Back on modules -> previous screen; Back in web module -> web history then app.
2. Login from saved canonical domain; update from v3 preserves mobile token and replaces the incorrect old domain if previously stored.
3. Web sign-in and store selection; visit **Sales**, **Purchases**, **Gift Cards**, **Reports**, and all other menu entries.
4. `/pos` test in staging: one customer, discount, tax inclusive/exclusive, split payments, points redemption, gift card, credit note, delivery and alterations; compare financial records to the desktop workflow.
5. `/pos/view/{id}` print a real invoice; compare stock, tax and layout with the site.
6. Browser file chooser, exports/downloads, pop-up printing (`window.open` / `target=_blank`), phone and external links, printer dialog, scanning and permission behavior.
7. Clear website cookies by clearing app data only if staff approves re-login; do not embed web credentials or turn off CSRF globally.
8. Monitor production access logs for web errors (especially the seven known unresolved routes).
