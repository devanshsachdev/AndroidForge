# AndroidForge — Maahee v4

Use **MaaheeNativePOS_AndroidForge_v4_WebParity.zip**, not the earlier v3 archive.

The ZIP contains `MaaheeNativePOS/settings.gradle.kts` directly alongside `MaaheeNativePOS/app/` and `MaaheeNativePOS/build.gradle.kts`, matching the working AndroidForge input layout.

- Version: 0.4.0 (versionCode 4).
- First test: sign in on the native screen with `https://pos.maahee.co.in`.
- Press Android Back from the dashboard: it must offer to stay or exit; on a detail page: it must return to the previous page.
- Tap **Bill > Full POS billing**, sign in on the WEBSITE if prompted, then tap **Page** to return to the original `/pos` path after website login.
- Open **More**: existing native modules remain native; web-only modules now open first-party HTTPS web pages with the original site's workflow. The small web icon on each row opens its original website route.
- Confirm popup/print-preview windows open in a contained in-app dialog, with **Close** and **Print** buttons.
- Open a sale > **Open complete web invoice**: it should load `/pos/view/<id>` with the full template. Webview and native API login sessions are separate.
- Logout clears both the native token and web cookies, and switching stores clears the web cookie.
- The original POS still contains 7 unresolved legacy menu routes: these will require web-server fixes separately.

## Security and accounting

The native quick checkout remains **disabled server-side by default** until financial parity testing. The web route uses the existing web POS backend; it is not a new implementation of gift cards/splits/rewards/returns. Verify all advanced flows against staging before using them on production. No new server migration is required for this v4 UI update.

## Source validation

Run `python3 tests/audit_source.py` and `python3 tests/audit_v4.py`. These tests cannot substitute for AndroidForge/Gradle compilation and device/website testing.
