# One-time CodeIgniter CSRF configuration

The uploaded POS has `$config['csrf_protection'] = TRUE` and `$config['csrf_exclude_uris'] = array();` in `app/config/config.php`. CodeIgniter validates CSRF before controller execution, so a bearer-authenticated JSON API cannot work unless its routes are excluded from *web-form* CSRF checks.

After backing up your server config, change **only** the following setting in **the existing server config**:

```php
$config['csrf_exclude_uris'] = array(
    'api/mobile/.*'
);
```

If the array already contains existing exclusions, **append** `'api/mobile/.*'` instead of replacing the others. Do not disable `$config['csrf_protection']`. The new mobile endpoints authenticate with a bearer token in the Authorization header, not cookie-only browser sessions, so cross-site browser form submissions cannot authenticate these routes. The `ping` and `login` routes are unauthenticated by design; login is rate-limited by existing Ion Auth configuration and should be additionally protected by a reverse-proxy rate limit.

`api/v1/*` is **not** covered by this exception. The old V1 bearer token check is insecure and should be blocked or replaced before external exposure.
