<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Maahee native mobile API. CodeIgniter 3, mounted at /api/mobile/{action}.
 * Install the database migration FIRST. Do not use the existing insecure /api/v1 bearer check.
 * Run behind TLS and review against the live database/settings before enabling checkout.
 */
class Mobile extends CI_Controller {
    private $user = NULL;
    private $tokenRow = NULL;
    private $storeId = 0;

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->library('ion_auth');
        $this->load->model('site');
        $this->load->model('pos_model');
        $this->load->model('sales_model');
    }
    private function reply($data = array(), $code = 200) {
        $this->output->set_status_header($code)->set_content_type('application/json', 'utf-8')
            ->set_header('Cache-Control: no-store')->set_header('X-Content-Type-Options: nosniff')
            ->set_output(json_encode(array('success' => $code < 400, 'data' => $data), JSON_UNESCAPED_UNICODE));
        $this->output->_display(); exit;
    }
    private function fail($message, $code = 400) {
        $this->output->set_status_header($code)->set_content_type('application/json', 'utf-8')
            ->set_header('Cache-Control: no-store')
            ->set_output(json_encode(array('success' => false, 'message' => $message)));
        $this->output->_display(); exit;
    }
    private function requirePost() {
        if (strtoupper($this->input->method()) !== 'POST') $this->fail('POST required', 405);
    }
    private function body() {
        $raw = file_get_contents('php://input');
        if (strlen($raw) > 131072) $this->fail('Payload too large', 413);
        $p = json_decode($raw, true);
        if (!is_array($p)) $this->fail('Invalid JSON payload');
        return $p;
    }
    private function secureTransport() {
        // Never trust an arbitrary client-supplied X-Forwarded-Proto header.
        // TLS-offloading reverse proxies must set HTTPS=on at the trusted webserver boundary.
        if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') $this->fail('HTTPS required', 403);
    }
    private function requireAuth($needStore = true) {
        $this->secureTransport();
        if (!$this->db->table_exists('mobile_tokens')) $this->fail('Mobile API migration not installed', 503);
        $header = $this->input->get_request_header('Authorization', true);
        if (!preg_match('/^Bearer ([a-f0-9]{64})$/i', (string)$header, $m)) $this->fail('Authentication required', 401);
        $hash = hash('sha256', $m[1]);
        $row = $this->db->get_where('mobile_tokens', array('token_hash' => $hash), 1)->row();
        if (!$row || $row->revoked_at || strtotime($row->expires_at) <= time()) $this->fail('Session expired', 401);
        $user = $this->db->get_where('users', array('id' => (int)$row->user_id, 'active' => 1), 1)->row();
        if (!$user) $this->fail('Account disabled', 401);
        $this->user = $user; $this->tokenRow = $row; $this->storeId = (int)$row->store_id;
        if ($needStore && !$this->storeId) $this->fail('Select a store', 409);
        if ($needStore) $this->checkStoreAccess($this->storeId);
        // Existing Site/Pos_model methods rely on the current store in the CI session.
        $this->session->set_userdata(array('user_id'=>(int)$user->id, 'store_id'=>$this->storeId));
    }
    private function checkStoreAccess($sid) {
        if ($sid < 1 || !$this->db->get_where('stores', array('id' => $sid), 1)->row()) $this->fail('Invalid store', 403);
        if (isset($this->user->store_id) && (int)$this->user->store_id > 0 && (int)$this->user->store_id !== $sid) $this->fail('Store access denied', 403);
    }
    private function adminOnly() {
        if (!$this->ion_auth->in_group('admin', (int)$this->user->id)) $this->fail('Admin permission required', 403);
    }
    public function ping() { $this->reply(array('service'=>'Maahee Native API', 'version'=>1)); }
    public function login() {
        $this->secureTransport(); $this->requirePost();
        if (!$this->db->table_exists('mobile_tokens')) $this->fail('Mobile API migration not installed', 503);
        $p = $this->body();
        $identity = trim((string)(isset($p['identity']) ? $p['identity'] : ''));
        $password = isset($p['password']) ? (string)$p['password'] : '';
        if (!$identity || !$password) $this->fail('Username and password required');
        // Ion Auth enforces existing POS password verification, account status and login attempts.
        if (!$this->ion_auth->login($identity, $password, false)) $this->fail('Invalid credentials', 401);
        $user = $this->ion_auth->user()->row();
        if (!$user || !$user->active) $this->fail('Account inactive', 403);
        $storeId = isset($user->store_id) && (int)$user->store_id > 0 ? (int)$user->store_id : 0;
        if (!$storeId && $this->db->count_all('stores') === 1) {
            $storeId = (int)$this->db->select('id')->limit(1)->get('stores')->row()->id;
        }
        $raw = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', time() + 60*60*24*7);
        $this->db->insert('mobile_tokens', array('user_id'=>(int)$user->id,'store_id'=>$storeId,
            'token_hash'=>hash('sha256',$raw),'expires_at'=>$expires,'created_at'=>date('Y-m-d H:i:s')));
        if (!$this->db->insert_id()) $this->fail('Could not create mobile session', 500);
        $this->ion_auth->logout(); // Mobile API uses bearer only, not a browser session.
        $this->reply(array('token'=>$raw,'expires_at'=>$expires,'user'=>array('id'=>(int)$user->id,
            'name'=>trim($user->first_name.' '.$user->last_name),'admin'=>$this->ion_auth->in_group('admin',(int)$user->id)),
            'store_id'=>$storeId));
    }
    public function logout() {
        $this->requirePost(); $this->requireAuth(false);
        $this->db->where('id', (int)$this->tokenRow->id)->update('mobile_tokens',array('revoked_at'=>date('Y-m-d H:i:s')));
        $this->reply(array('logged_out'=>true));
    }
    public function me() {
        $this->requireAuth(false);
        $this->reply(array('name'=>trim($this->user->first_name.' '.$this->user->last_name),
          'id'=>(int)$this->user->id,'store_id'=>$this->storeId,
          'admin'=>$this->ion_auth->in_group('admin',(int)$this->user->id)));
    }
    public function stores() {
        $this->requireAuth(false);
        $rows = $this->db->select('id,name,code,city')->order_by('name')->get('stores')->result_array();
        if (isset($this->user->store_id) && (int)$this->user->store_id > 0) {
            $allowed = (int)$this->user->store_id;
            $rows = array_values(array_filter($rows, function($s) use ($allowed) { return (int)$s['id'] === $allowed; }));
        }
        $this->reply($rows);
    }
    public function set_store() {
        $this->requirePost(); $this->requireAuth(false);
        $p = $this->body(); $sid = (int)(isset($p['store_id']) ? $p['store_id'] : 0);
        $this->checkStoreAccess($sid);
        $this->db->where('id',(int)$this->tokenRow->id)->update('mobile_tokens',array('store_id'=>$sid));
        $this->reply(array('store_id'=>$sid));
    }
    public function register_status() {
        $this->requireAuth();
        $row=$this->db->select('id,date,user_id,store_id,status,cash_in_hand')
            ->where('store_id',$this->storeId)->where('status','open')
            ->order_by('id','DESC')->limit(1)->get('registers')->row_array();
        $this->reply(array('open'=>$row!==NULL,'register'=>$row));
    }
    public function open_register() {
        $this->requirePost();$this->requireAuth();$p=$this->body();
        $cash=(float)(isset($p['cash_in_hand'])?$p['cash_in_hand']:-1);
        if (!is_finite($cash)||$cash<0||$cash>100000000) $this->fail('Invalid opening cash');
        // Serialize register-opening requests by store. Requires MySQL/MariaDB backend.
        $lock='maahee_mobile_register_'.(int)$this->storeId;
        $q=$this->db->query('SELECT GET_LOCK(?, 3) AS acquired',array($lock))->row();
        if (!$q || (int)$q->acquired!==1) $this->fail('Register is busy; try again',409);
        try {
            $existing=$this->db->where('store_id',$this->storeId)->where('status','open')->limit(1)->get('registers')->row();
            if ($existing) $this->fail('This store already has an open register',409);
            if (!$this->pos_model->openRegister(array('date'=>date('Y-m-d H:i:s'),
                'cash_in_hand'=>$cash,'user_id'=>(int)$this->user->id,'store_id'=>$this->storeId,'status'=>'open')))
                $this->fail('Register could not be opened',500);
            $id=$this->db->insert_id();
        } finally {
            $this->db->query('SELECT RELEASE_LOCK(?)',array($lock));
        }
        $this->reply(array('id'=>(int)$id,'open'=>true),201);
    }
    public function dashboard() {
        $this->requireAuth();
        $today = date('Y-m-d');
        $s = $this->db->select('COUNT(*) sales_count, COALESCE(SUM(grand_total),0) sales_total, COALESCE(SUM(paid),0) paid_total',false)
            ->from('sales')->where('store_id',$this->storeId)
            ->where('date >=',$today.' 00:00:00')->where('date <=',$today.' 23:59:59')->get()->row_array();
        $low = 0;
        if ($this->db->table_exists('product_store_qty')) {
            $low = $this->db->where('store_id',$this->storeId)->where('quantity <=',5)->count_all_results('product_store_qty');
        }
        $recent = $this->db->select('id,date,ser_no,invoice_no,customer_name,grand_total,paid,status')
            ->where('store_id',$this->storeId)->order_by('id','DESC')->limit(5)->get('sales')->result_array();
        $daily=$this->db->select('DATE(date) AS day, SUM(grand_total) AS total',false)
            ->where('store_id',$this->storeId)->where('date >=',date('Y-m-d',strtotime('-6 days')).' 00:00:00')
            ->group_by('DATE(date)')->order_by('DATE(date)','ASC')->get('sales')->result_array();
        $this->reply(array('sales_count'=>(int)$s['sales_count'],'sales_total'=>(float)$s['sales_total'],
            'paid_total'=>(float)$s['paid_total'],'low_stock'=>$low,'recent'=>$recent,'daily'=>$daily));
    }
    public function products() {
        $this->requireAuth();
        $term=trim((string)$this->input->get('q', true));
        $limit=max(1,min(100,(int)$this->input->get('limit') ?: 40));
        $prefix=$this->db->dbprefix('product_store_qty');
        $this->db->select('p.id,p.code,p.name,p.price,p.type,p.tax,p.tax_method, COALESCE(q.quantity,0) AS quantity, COALESCE(q.price,p.price) AS store_price',false)
            ->from('products p')->join($prefix.' q','q.product_id=p.id AND q.store_id='.(int)$this->storeId,'left');
        if ($term !== '') $this->db->group_start()->like('p.code',$term)->or_like('p.name',$term)->group_end();
        $this->reply($this->db->order_by('p.id','DESC')->limit($limit)->get()->result_array());
    }
    public function customers() {
        $this->requireAuth();
        $term=trim((string)$this->input->get('q', true));
        $this->db->select('id,name,phone,email,city,area,total_points')->from('customers');
        if ($term !== '') $this->db->group_start()->like('name',$term)->or_like('phone',$term)->group_end();
        $this->reply($this->db->order_by('id','DESC')->limit(75)->get()->result_array());
    }
    public function create_customer() {
        $this->requirePost(); $this->requireAuth(); $p=$this->body();
        $name=trim((string)(isset($p['name'])?$p['name']:''));
        $phone=preg_replace('/[^0-9+]/','',(string)(isset($p['phone'])?$p['phone']:''));
        if (mb_strlen($name)<2 || mb_strlen($name)>120 || strlen($phone)<8 || strlen($phone)>16) $this->fail('Enter valid name and mobile number');
        $data=array('name'=>$name,'phone'=>$phone,'email'=>trim((string)(isset($p['email'])?$p['email']:'')),
            'city'=>trim((string)(isset($p['city'])?$p['city']:'')));
        if (strlen($data['email'])>150 || ($data['email']!=='' && !filter_var($data['email'],FILTER_VALIDATE_EMAIL))) $this->fail('Invalid email');
        $this->load->model('customers_model');
        $id=$this->customers_model->addCustomer($data);
        if (!$id) $this->fail('Could not save customer',500);
        $data['id']=(int)$id; $this->reply($data,201);
    }
    public function sales() {
        $this->requireAuth();
        $limit=max(1,min(100,(int)$this->input->get('limit') ?: 50));
        $q=trim((string)$this->input->get('q',true));
        $this->db->select('id,date,invoice_no,ser_no,customer_id,customer_name,grand_total,paid,status')
            ->from('sales')->where('store_id',$this->storeId);
        if ($q!=='') $this->db->group_start()->like('customer_name',$q)->or_like('invoice_no',$q)->or_like('ser_no',$q)->group_end();
        $this->reply($this->db->order_by('id','DESC')->limit($limit)->get()->result_array());
    }
    public function sale($id=0) {
        $this->requireAuth();
        $id=(int)$id;
        $s=$this->db->where('id',$id)->where('store_id',$this->storeId)->get('sales')->row_array();
        if (!$s) $this->fail('Invoice not found',404);
        $items=$this->db->where('sale_id',$id)->get('sale_items')->result_array();
        $payments=$this->db->select('date,amount,paid_by,note')->where('sale_id',$id)->get('payments')->result_array();
        $this->reply(array('sale'=>$s,'items'=>$items,'payments'=>$payments));
    }
    public function records($resource='') {
        $this->requireAuth();
        // Explicit allowlist: no arbitrary SQL table name or customer-private columns.
        $map=array(
           'purchases'=>array('purchases',array('id','date','reference','supplier_name','grand_total','paid','status')),
           'suppliers'=>array('suppliers',array('id','name','phone','email','company')),
           'categories'=>array('categories',array('id','name','code')),
           'employees'=>array('employees',array('id','name','phone','incentive')),
           'gift_cards'=>array('gift_cards',array('id','card_no','value','balance','expiry')),
           'registers'=>array('registers',array('id','date','user_id','store_id','status','cash_in_hand')),
           'barcodes'=>array('barcodes',array('id','product_id','quantity')),
           'expenses'=>array('expenses',array('id','date','reference','amount','note')),
           'credit_notes'=>array('credit_notes',array('id','credit_note_no','balance','amount','status','expiry_date')),
           'purchase_returns'=>array('purchase_returns',array('id','date','reference','supplier_id','grand_total','status'))
        );
        if (!isset($map[$resource])) $this->fail('Module needs a dedicated mobile endpoint',501);
        // Sensitive operational ledgers require an administrator.
        if (!in_array($resource, array('categories','barcodes'), true)) $this->adminOnly();
        list($table,$fields)=$map[$resource];
        if (!$this->db->table_exists($table)) $this->reply(array());
        $existing=array_values(array_filter($fields,function($f)use($table){return $this->db->field_exists($f,$table);}));
        if (!$existing) $this->reply(array());
        $this->db->select(implode(',',$existing))->from($table);
        if ($this->db->field_exists('store_id',$table)) $this->db->where('store_id',$this->storeId);
        $q=trim((string)$this->input->get('q',true));
        if ($q!=='') {
            $searchFields=array_values(array_intersect(array('name','code','reference','card_no','credit_note_no','supplier_name','phone','note'),$existing));
            if ($searchFields) {
                $this->db->group_start();
                foreach ($searchFields as $i=>$f) { if ($i===0) $this->db->like($f,$q); else $this->db->or_like($f,$q); }
                $this->db->group_end();
            }
        }
        $this->reply($this->db->order_by('id','DESC')->limit(100)->get()->result_array());
    }
    public function tracker() {
        $this->requireAuth();
        $this->db->select('id,ser_no,invoice_no,customer_name,delivery_date,tailoring_status,tailoring_items')
            ->where('store_id',$this->storeId)->where('tailoring_items >',0)
            ->order_by('delivery_date','ASC')->limit(100);
        $this->reply($this->db->get('sales')->result_array());
    }
    public function tracker_status() {
        $this->requirePost(); $this->requireAuth(); $p=$this->body();
        $id=(int)(isset($p['sale_id'])?$p['sale_id']:0);
        $status=(string)(isset($p['status'])?$p['status']:'');
        if (!$id || !in_array($status,array('Pending','Cutting','Stitching','Ready','Delivered'),true)) $this->fail('Invalid tracker update');
        $sale=$this->db->where('id',$id)->where('store_id',$this->storeId)->get('sales')->row();
        if (!$sale || (int)$sale->tailoring_items<1) $this->fail('Order not found',404);
        $data=array('tailoring_status'=>$status);
        if($this->db->field_exists('updated_at','sales')) $data['updated_at']=date('Y-m-d H:i:s');
        if (!$this->db->where('id',$id)->where('store_id',$this->storeId)->update('sales',$data)) $this->fail('Update failed',500);
        $this->reply(array('sale_id'=>$id,'status'=>$status));
    }
    private function prepareBill($p, $requireStock=true) {
        $lines=isset($p['items'])&&is_array($p['items'])?$p['items']:array();
        if (!$lines || count($lines)>50) $this->fail('Add 1 to 50 products');
        $items=array();$total=0;$taxTotal=0;$discountTotal=0;$quantityTotal=0;$seen=array();
        foreach ($lines as $x) {
            $id=(int)(isset($x['product_id'])?$x['product_id']:0);
            $qty=(int)(isset($x['quantity'])?$x['quantity']:0);
            $pct=(float)(isset($x['discount_percent'])?$x['discount_percent']:0);
            if ($id<1 || $qty<1 || $qty>1000 || !is_finite($pct) || $pct<0 || $pct>100 || isset($seen[$id])) $this->fail('Invalid or duplicate cart item');
            $seen[$id]=true;
            $pr=$this->site->getProductByID($id,$this->storeId);
            if (!$pr || $pr->type!=='standard') $this->fail('Only standard stock items are enabled for mobile billing');
            if ($requireStock && $qty>(float)$pr->quantity) $this->fail('Insufficient stock: '.$pr->name,409);
            $price=round((float)(isset($pr->store_price)?$pr->store_price:$pr->price),4);
            $discount=round($price*$pct/100,4);
            $after=round($price-$discount,4);
            $rate=(float)(isset($pr->tax)?$pr->tax:0);
            $exclusive=(int)(isset($pr->tax_method)?$pr->tax_method:0)===1;
            $unitTax=$rate>0?round($exclusive?$after*$rate/100:$after*$rate/(100+$rate),4):0;
            $net=$exclusive?$after:$after-$unitTax;
            $lineTax=round($unitTax*$qty,4);
            $lineTotal=round(($net+$unitTax)*$qty,4);
            $items[]=array('product_id'=>$id,'quantity'=>$qty,'unit_price'=>$after,'net_unit_price'=>$net,
                'discount'=>$pct.'%','comment'=>'','item_discount'=>round($discount*$qty,4),
                'tax'=>$rate.'%','item_tax'=>$lineTax,'subtotal'=>$lineTotal,'real_unit_price'=>$price,
                'cost'=>(float)$pr->cost,'product_code'=>$pr->code,'product_name'=>$pr->name);
            $total+=round($net*$qty,4);$taxTotal+=$lineTax;$discountTotal+=round($discount*$qty,4);$quantityTotal+=$qty;
        }
        $orderDiscount=(float)(isset($p['order_discount_percent'])?$p['order_discount_percent']:0);
        if (!is_finite($orderDiscount)||$orderDiscount<0||$orderDiscount>100) $this->fail('Invalid order discount');
        $orderDiscountAmount=round(($total+$taxTotal)*$orderDiscount/100,4);
        $gross=max(0,round($total+$taxTotal-$orderDiscountAmount,4));
        return array('items'=>$items,'subtotal'=>round($total,2),'tax'=>round($taxTotal,2),
            'item_discount'=>round($discountTotal,2),'order_discount'=>round($orderDiscountAmount,2),
            'grand_total'=>round($gross,2),'total_quantity'=>$quantityTotal,'total_items'=>count($items),
            'order_discount_percent'=>$orderDiscount);
    }
    public function quote() {
        $this->requirePost();$this->requireAuth();
        $bill=$this->prepareBill($this->body());
        unset($bill['items']);$this->reply($bill);
    }
    public function checkout() {
        $this->requirePost();$this->requireAuth();
        // Disabled until checkout parity is verified on a staging clone of each POS database.
        // Set MAAHEE_MOBILE_CHECKOUT_ENABLED=1 in the server environment only after approval.
        if (getenv('MAAHEE_MOBILE_CHECKOUT_ENABLED') !== '1') $this->fail('Mobile billing not enabled on this server yet', 503);
        $p=$this->body();
        $key=(string)(isset($p['request_id'])?$p['request_id']:'');
        if (!preg_match('/^[0-9a-f-]{36}$/i',$key)) $this->fail('Request ID required');
        if (!$this->db->table_exists('mobile_checkout_requests')) $this->fail('Checkout migration missing',503);
        $customer=(int)(isset($p['customer_id'])?$p['customer_id']:0);
        $cust=$this->db->where('id',$customer)->get('customers')->row();
        if (!$cust) $this->fail('Select a valid customer');
        $method=(string)(isset($p['payment_method'])?$p['payment_method']:'cash');
        $methods=array('cash'=>'cash','card'=>'CC','upi'=>'other','other'=>'other');
        if (!isset($methods[$method])) $this->fail('Unsupported payment method');
        $paid=(float)(isset($p['paid'])?$p['paid']:0);
        if (!is_finite($paid)||$paid<0) $this->fail('Invalid payment amount');
        $existing=$this->db->get_where('mobile_checkout_requests',array('token_id'=>(int)$this->tokenRow->id,'request_key'=>$key),1)->row();
        if ($existing && (int)$existing->sale_id>0) return $this->reply(array('sale_id'=>(int)$existing->sale_id,'already_saved'=>true));
        if ($existing) $this->fail('Checkout is already being processed',409);
        $register=$this->db->where('store_id',$this->storeId)->where('status','open')->limit(1)->get('registers')->row();
        if (!$register) $this->fail('Open your POS register first',409);
        // Validate the full cart before touching a database transaction.
        $this->prepareBill($p);
        $this->db->trans_begin();
        // Lock store stock rows to prevent racing multiple mobile checkouts.
        foreach ($p['items'] as $line) {
            $id=(int)$line['product_id'];
            $locked=$this->db->query('SELECT quantity FROM '.$this->db->dbprefix('product_store_qty').' WHERE product_id=? AND store_id=? FOR UPDATE',array($id,$this->storeId))->row();
            if (!$locked || (float)$locked->quantity<(int)$line['quantity']) { $this->db->trans_rollback();$this->fail('Stock changed; refresh your cart',409); }
        }
        $bill=$this->prepareBill($p);
        $expected=(float)$bill['grand_total'];
        if (round($paid,2)>$expected+0.009) { $this->db->trans_rollback();$this->fail('Paid exceeds total; enter tendered amount net of change'); }
        if ((int)$cust->id===1 && $paid+0.009<$expected) { $this->db->trans_rollback();$this->fail('Choose a customer for a credit sale'); }
        $date=date('Y-m-d H:i:s');
        $status=$paid+0.009>=$expected?'paid':($paid>0?'partial':'due');
        $note=mb_substr(trim((string)(isset($p['note'])?$p['note']:'')),0,500);
        $saleData=array('date'=>$date,'employee_id'=>0,'employee_name'=>'','customer_id'=>$customer,
            'customer_name'=>$cust->name,'total'=>$bill['subtotal'],'product_discount'=>$bill['item_discount'],
            'order_discount_id'=>$bill['order_discount_percent'].'%','order_discount'=>$bill['order_discount'],
            'total_discount'=>$bill['item_discount']+$bill['order_discount'],'product_tax'=>$bill['tax'],
            'order_tax_id'=>null,'order_tax'=>0,'total_tax'=>$bill['tax'],'grand_total'=>$expected,
            'points_earned'=>0,'points_redeemed'=>0,'reward_amount'=>0,'points_used'=>0,'points_discount'=>0,
            'total_items'=>$bill['total_items'],'total_quantity'=>$bill['total_quantity'],
            'rounding'=>0,'paid'=>$paid,'amount_paid_by'=>$methods[$method],'status'=>$status,
            'created_by'=>(int)$this->user->id,'note'=>$note,'billing_note'=>$note,'internal_note'=>'Mobile POS',
            'store_id'=>$this->storeId,'ser_no'=>$this->pos_model->sales_count($this->storeId)+1);
        $payment=$paid>0?array('date'=>$date,'amount'=>$paid,'customer_id'=>$customer,
            'paid_by'=>$methods[$method],'created_by'=>(int)$this->user->id,'store_id'=>$this->storeId,
            'note'=>$method==='upi'?'UPI (mobile POS)':'Mobile POS'):array();
        $this->db->insert('mobile_checkout_requests',array('token_id'=>(int)$this->tokenRow->id,
            'request_key'=>$key,'sale_id'=>null,'created_at'=>$date));
        if ($this->db->trans_status()===false) { $this->db->trans_rollback();$this->fail('Checkout request conflict',409); }
        $sale=$this->pos_model->addSale($saleData,$bill['items'],$payment);
        if (!$sale || !$sale['sale_id']) { $this->db->trans_rollback();$this->fail('Invoice could not be saved',500); }
        $id=(int)$sale['sale_id'];
        if (method_exists($this->sales_model,'syncRewardEarnForSale')) $this->sales_model->syncRewardEarnForSale($id);
        $this->db->where('token_id',(int)$this->tokenRow->id)->where('request_key',$key)
            ->update('mobile_checkout_requests',array('sale_id'=>$id));
        if ($this->db->trans_status()===false) { $this->db->trans_rollback();$this->fail('Transaction failed',500); }
        $this->db->trans_commit();
        $this->reply(array('sale_id'=>$id,'grand_total'=>$expected,'status'=>$status),201);
    }
}
