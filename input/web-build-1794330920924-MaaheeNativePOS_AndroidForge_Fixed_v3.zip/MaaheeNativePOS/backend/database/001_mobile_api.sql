-- Apply after taking and verifying a backup. Original POS uses table prefix tec_.
-- Adjust the prefix ONLY if app/config/database.php has been changed.
CREATE TABLE IF NOT EXISTS `tec_mobile_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `store_id` INT NOT NULL DEFAULT 0,
  `token_hash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `created_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `revoked_at` DATETIME NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `mobile_token_hash_uniq` (`token_hash`),
  KEY `mobile_tokens_user_idx` (`user_id`), KEY `mobile_tokens_exp_idx` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `tec_mobile_checkout_requests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `token_id` BIGINT UNSIGNED NOT NULL,
  `request_key` CHAR(36) NOT NULL,
  `sale_id` INT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `mobile_checkout_uniq` (`token_id`,`request_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
