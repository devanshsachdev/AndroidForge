# Maahee Native POS — Android Studio source + CodeIgniter mobile API

**Deliverable:** A native Kotlin/Jetpack Compose Android project, an isolated CodeIgniter 3 mobile API, a database migration and a GitHub Actions APK build workflow. **This is a staged first release, not a finished feature-complete replacement for every POS workflow.**

The supplied POS archive has 74 workspace links and more than 500 distinct controller/route/file paths. The original mobile-facing V1 bridge accepts arbitrary nonempty bearer tokens. This project deliberately does **not** use or perpetuate that authentication mechanism.

## What actually works in the source

| Area | Native implementation | Backend support | Limitations |
|---|---|---|---|
| Sign-in and store selection | Yes | New per-user hashed, expiring bearer tokens via POS Ion Auth | Requires deployment; TLS mandatory |
| Register opening | Native status and opening balance form | New mobile endpoint; **closing/reconciliation pending** | Matches one-open-register-per-store rule |
| Dashboard | Yes, live KPI cards and animated 7-day graph | New mobile endpoint | Currently store-level overview |
| Billing/cart | Yes, search, barcode scan, quantity, discounts, customer, quote, tenders | New server-side quote and transaction checkout | **Checkout OFF by default**; see validation checklist |
| Sales | Yes, search, invoice detail, share and print native PDF | New read endpoints | Refunds, edits and full audit trails not implemented |
| Products/stock | Yes, live search, store price and stock | New read endpoint | Product CRUD/import/barcode batch labels pending |
| Customers | Yes, search, add, view points | New read/create endpoints | Edits, ledgers and redemption pending |
| Workshop | Yes, job list and update stage | New store-scoped status endpoint | Partial deliveries, proof photos and ticket editing pending |
| Purchases, suppliers, categories, employees, gift cards, registers, barcode queue, expenses, credit notes and returns | Native searchable lists | Whitelisted read-only endpoint, where backing tables exist | Item-specific create/edit/settlement workflows pending |
| Remaining pages | Present in native module directory | No write integration yet | Shown explicitly as **Planned**, never masquerading as functional |

## Getting started

1. **Back up the live POS and database.** Test all work against a staging clone first, using accounts with minimal permissions and test payment instruments.
2. Apply `backend/database/001_mobile_api.sql` in the POS database. The source POS uses `tec_` as the database prefix. Review the SQL before execution.
3. Upload **only** `backend/app/controllers/api/Mobile.php` to `app/controllers/api/Mobile.php` in your existing CodeIgniter server. Do **not** overwrite or redeploy the entire ZIP. Do not upload the Android project to PHP hosting.
4. Apply the scoped CSRF exclusion described in `backend/patches/README_CSRF.md` (the uploaded POS has CSRF enabled). Ensure HTTPS is active all the way to PHP. If using a trusted TLS-terminating proxy, configure the web server to set `HTTPS=on` itself; this API does not trust arbitrary client-supplied `X-Forwarded-Proto`.
5. Verify `https://YOUR-POS-HOST/api/mobile/ping` and POST `https://YOUR-POS-HOST/api/mobile/login` with `Content-Type: application/json` body `{"identity":"YOUR_LOGIN","password":"YOUR_PASSWORD"}`. Keep credentials out of terminal history and shared logs.
6. Open the **`MaaheeNativePOS/` folder** as a project in Android Studio. Set Gradle JDK 17 and Android SDK 35, sync dependencies and run on an Android 8.0+ device.
7. Sign in with an existing POS employee account and select the appropriate store. Scan with a device that has Google Play services installed for the Google Code Scanner feature.
8. **Billing validation gate:** Verify tax-inclusive/exclusive products, POS discount/rounding settings, credit sales, return cases, receipts, register control, stock concurrency, invoice serials, invoice history, mobile permissions, customer rewards, and split payments on staging. This mobile checkout intentionally supports only **standard stock products**, **one payment mode** (cash/card/UPI/other), **percentage discounts**, and no actual bank capture. Only after accounting owners approve parity set the backend environment variable `MAAHEE_MOBILE_CHECKOUT_ENABLED=1` for the PHP process. Leave it unset in production until sign-off.

### APK build options

See `BUILD_INSTRUCTIONS.md`. In Android Studio use **Build > Build APK(s)**. The `.github/workflows/build-debug-apk.yml` workflow also produces a **debug APK** when the `MaaheeNativePOS/` contents are pushed as a GitHub repository root. This execution environment has no Android SDK/Gradle installation, so **no verified APK was produced in this package**.

### Android networking and security

* HTTPS-only client, certificate checks performed by OkHttp, no `usesCleartextTraffic`.
* Login uses existing Ion Auth password validation. Tokens are random 256-bit values; server stores SHA-256 hashes only, 7-day expiry and explicit revocation.
* Tokens stored on Android using AES-GCM keys protected by Android Keystore; not committed to the codebase.
* SQL list endpoints are whitelisted, page-limited and scoped to selected store where supported.
* Mobile checkout requires an open register, re-evaluates stock/price/tax server-side and creates a transaction with a unique request ID.
* No credit-note redemption, stored card capture or gift-card balance mutation from the Android app.
* **Deployment review remains essential.** In particular, validate role scoping, existing multi-store constraints, your site's CSP/proxy rules, backward compatibility and all mobile API authorization behavior before release.

### Paths and compatibility

The backend extension does not alter the existing V1 API. Existing CodeIgniter auto-routing supports `/api/mobile/{method}` with `app/controllers/api/Mobile.php`. If auto-routing is disabled in your deployment, explicitly add equivalent route declarations to `app/config/routes.php`. The Android app uses only the new `/api/mobile/` prefix.

### Project structure

```text
MaaheeNativePOS/
  settings.gradle.kts           Gradle project root (AndroidForge detects this folder)
  build.gradle.kts              Root Gradle build file
  app/                          Android Studio / Kotlin / Jetpack Compose app
    src/main/java/...           Native screens, API, billing, receipts
  .github/workflows/            Optional CI debug APK build
  backend/
    app/controllers/api/Mobile.php  Secure CodeIgniter bridge
    database/001_mobile_api.sql     Two new mobile-only tables
  docs/
    QA_CHECKLIST.md             Staging acceptance criteria
    API_ENDPOINTS.md            API reference
```

### Critical known gaps

* No live integration test was possible without the deployed POS instance and a sandbox database.
* No Gradle compile or APK build could run without the Android SDK and Gradle dependencies. Source should be compiled and reviewed before distribution.
* Full parity for 74 workspace pages / all POS write flows is **not** present. The directory makes scope visible so staff are not misled.
* UI features such as product import, refunds, loyalty redemptions, WhatsApp messaging, reconciliation, employee administration, supplier settlements, printer setup, database restore, and return authorizations require dedicated server interfaces and acceptance testing.


### AndroidForge v2 packaging fix (2026-11-10)
The original archive placed the Gradle build under `MaaheeNativePOS/android/`, but AndroidForge ran Gradle from `MaaheeNativePOS/`. This v2 archive moves the project files directly under `MaaheeNativePOS/` so `settings.gradle.kts` and `build.gradle.kts` exist at the detected workspace root. Also fixes the missing Compose `sp` import and avoids a `Surface` name collision. This is a source-level correction and the APK has **not** been compiled in this environment.
