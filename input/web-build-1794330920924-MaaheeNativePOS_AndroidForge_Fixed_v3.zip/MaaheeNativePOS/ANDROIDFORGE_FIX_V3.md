# AndroidForge v3: Kotlin icon compilation fix

## Error addressed

`app/src/main/java/in/maahee/pos/Screens.kt:59:84 Unresolved reference LockOutline`

## Change

Replaced `Icons.Outlined.LockOutline` with `Icons.Outlined.Lock` using the existing `androidx.compose.material.icons.outlined.*` import and `material-icons-extended` dependency.

## Build instructions

Upload **MaaheeNativePOS_AndroidForge_Fixed_v3.zip** to AndroidForge. The ZIP contains `MaaheeNativePOS/settings.gradle.kts`, `MaaheeNativePOS/build.gradle.kts`, and `MaaheeNativePOS/app/build.gradle.kts` at the same locations as v2.

Run a fresh debug build. This package was not compiled with Android Gradle here: the environment does not provide the Android SDK and Gradle installation.

If another compile error occurs, share the full `e: file:///...:line:col` messages so the next issue can be fixed precisely.
