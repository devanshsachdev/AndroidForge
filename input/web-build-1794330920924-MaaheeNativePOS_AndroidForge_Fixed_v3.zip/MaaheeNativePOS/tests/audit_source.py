"""Static source checks. Does NOT substitute for Android compilation or POS integration tests."""
from pathlib import Path
import re,subprocess,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/in/maahee/pos/Modules.kt').read_text()
entries=re.findall(r'^\s*ModuleItem\(',source,re.M)
assert 'Icons.Outlined.LockOutline' not in (root/'app/src/main/java/in/maahee/pos/Screens.kt').read_text(), 'Invalid Material icon reference'
assert len(entries)==74,f'Expected 74 modules, got {len(entries)}'
assert source.count('"Unresolved"')==7,'Expected seven unresolved web paths'
api=(root/'backend/app/controllers/api/Mobile.php').read_text()
for endpoint in ('login','logout','stores','set_store','dashboard','products','customers','create_customer',
                 'sales','sale','records','tracker','tracker_status','quote','checkout','register_status','open_register'):
    assert re.search(r'public function '+endpoint+r'\s*\(',api),endpoint
assert "MAAHEE_MOBILE_CHECKOUT_ENABLED" in api
assert "hash('sha256'" in api
for p in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(p)
ET.parse(root/'app/src/main/AndroidManifest.xml')
result=subprocess.run(['php','-l',str(root/'backend/app/controllers/api/Mobile.php')],capture_output=True,text=True)
assert result.returncode==0,result.stderr
print('PASS: 74 navigation destinations; 7 flagged unresolved; 17 mobile API actions; Android XML; PHP syntax')
print('NOT TESTED: Android Gradle compile, APK install, deployed server, migrations or live POS transactions')
