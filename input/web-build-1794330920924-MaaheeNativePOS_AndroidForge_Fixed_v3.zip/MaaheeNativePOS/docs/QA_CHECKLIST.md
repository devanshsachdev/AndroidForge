# QA acceptance checklist — stage on a cloned database

Do not switch on live billing until all relevant scenarios are signed off against the established web POS.

- [ ] Android app builds via Gradle, launches and survives background/foreground process restart.
- [ ] Login works for active staff; invalid and disabled users are rejected.
- [ ] Logged-out, expired and revoked tokens cannot access any protected operation.
- [ ] Multi-store operator cannot see or mutate data from another assigned store.
- [ ] HTTPS is enforced at client and backend, with reverse proxy correctly configured.
- [ ] Search by exact barcode and partial product/customer name returns expected records.
- [ ] Native barcode scan returns exact product and handles denied/unavailable scanning.
- [ ] Stock amounts and store-specific prices match web POS.
- [ ] Quote matches web POS for tax-inclusive and tax-exclusive product lines.
- [ ] Discounts and rounding match the live settings (do not enable checkout until equivalent).
- [ ] Admin restrictions for discount edits, product overrides and credit permissions are enforced as required.
- [ ] Closed register cannot create a bill; open register can bill as authorized staff.
- [ ] A mobile-created invoice matches the web POS sale, sale items, payments, stock deduction and invoice numbering.
- [ ] Loyalty points and incentives update to the expected values or billing is refused.
- [ ] Manual UPI/card payments are never described as automatic payment capture.
- [ ] Partial payment, cashless credit, and default walk-in customer rules agree with the web POS.
- [ ] Repeated request ID cannot create a duplicate invoice even on network timeout and retry.
- [ ] Simultaneous till sales cannot oversell the same stock.
- [ ] Invoice PDF print/share is accurate and accessible via system print providers.
- [ ] Customer add requires valid fields and appears in the established web POS.
- [ ] Workshop stages update only authorized store orders.
- [ ] Gift-card redemption, returns, refunds, split payments and credits remain disabled until individually built and tested.
- [ ] User-facing unimplemented modules show **Planned** rather than a dead button or deceptive success.
- [ ] Backups tested, migrations reviewed, and a rollback plan confirmed.
