# Maahee Native API reference

Server setup: the existing CodeIgniter CSRF filter must exempt `api/mobile/.*` only; see `backend/patches/README_CSRF.md`.

All actions respond `{"success":true,"data":...}` or `{"success":false,"message":"..."}`. Use HTTPS and `Authorization: Bearer {64-hex-token}` on all authenticated actions. POST JSON requires `Content-Type: application/json`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/mobile/ping` | API health check |
| POST | `/api/mobile/login` | Exchange existing POS Ion Auth credentials for 7-day mobile token |
| POST | `/api/mobile/logout` | Revoke current token |
| GET | `/api/mobile/me` | Current operator and selected store |
| GET | `/api/mobile/stores` | Available stores respecting user store restriction |
| POST | `/api/mobile/set_store` | Select store with `{ "store_id": 1 }` |
| GET | `/api/mobile/register_status` | Status of the store register |
| POST | `/api/mobile/open_register` | Start register with `{ "cash_in_hand": 2000 }` (refuses duplicate open register) |
| GET | `/api/mobile/dashboard` | Today's revenue, count, collected amount, stock alerts, 7-day trend, recent invoices |
| GET | `/api/mobile/products?q=` | Search products with live store quantities/prices |
| GET | `/api/mobile/customers?q=` | Search customers |
| POST | `/api/mobile/create_customer` | `{ "name": "...", "phone": "...", "email": "" }` |
| GET | `/api/mobile/sales?q=` | Store's recent sales |
| GET | `/api/mobile/sale/{id}` | Sale, line items, payment summary |
| GET | `/api/mobile/records/{resource}?q=` | Whitelisted operational lists |
| GET | `/api/mobile/tracker` | Store tailoring orders |
| POST | `/api/mobile/tracker_status` | `{ "sale_id": 123, "status": "Ready" }` |
| POST | `/api/mobile/quote` | Price + tax + stock validation for cart |
| POST | `/api/mobile/checkout` | Create sale (gated by server env flag) |

`records/{resource}` allowlist: `purchases`, `suppliers`, `categories`, `employees`, `gift_cards`, `registers`, `barcodes`, `expenses`, `credit_notes`, `purchase_returns`. Unknown resources return 501 rather than arbitrary table exposure.

### Checkout / quote input

```json
{
  "items": [
    { "product_id": 101, "quantity": 2, "discount_percent": 5.0 }
  ],
  "order_discount_percent": 0
}
```

Checkout additionally requires `request_id` UUID, `customer_id`, `paid`, `payment_method` (`cash`,`upi`,`card`,`other`), `note`. Idempotency request IDs are bound to the mobile token. All monetary fields are recomputed on the server and stock is locked before commit. Billing is intentionally disabled until staging acceptance.
