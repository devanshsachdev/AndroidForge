package `in`.maahee.pos

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Wine = Color(0xFF622F40)
val Rose = Color(0xFFF0DFE2)
val Gold = Color(0xFFBF976A)
val Ink = Color(0xFF29232B)
val Cream = Color(0xFFFAF8F5)
val PaperWhite = Color(0xFFFFFFFF)
val Subdued = Color(0xFF857C84)
val Sage = Color(0xFF347763)

private val posScheme = lightColorScheme(
    primary = Wine, onPrimary = Color.White, primaryContainer = Rose,
    onPrimaryContainer = Ink, secondary = Gold, background = Cream,
    onBackground = Ink, surface = PaperWhite, onSurface = Ink,
    surfaceVariant = Color(0xFFF4EFEA), outline = Color(0xFFE8E0DA)
)

@Composable fun MaaheeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = posScheme,
        typography = Typography(
            headlineLarge = androidx.compose.ui.text.TextStyle(fontSize = 29.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp),
            headlineMedium = androidx.compose.ui.text.TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold),
            titleLarge = androidx.compose.ui.text.TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
            titleMedium = androidx.compose.ui.text.TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            bodyMedium = androidx.compose.ui.text.TextStyle(fontSize = 14.sp),
            labelSmall = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, letterSpacing = 0.3.sp)
        ), content = content)
}

@Composable fun BrandHeader(kicker: String, heading: String, detail: String = "") {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(kicker.uppercase(), style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold, color = Gold, letterSpacing = 2.sp)
        Text(heading, style = MaterialTheme.typography.headlineLarge, color = Ink)
        if (detail.isNotBlank()) Text(detail, color = Subdued, style = MaterialTheme.typography.bodyMedium)
    }
}
@Composable fun PremiumCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.animateContentSize(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PaperWhite),
        border = BorderStroke(1.dp, Color(0xFFEEE8E3)), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}
@Composable fun StatCard(label: String, value: String, subtitle: String, modifier: Modifier = Modifier, dark: Boolean = false) {
    Card(modifier, shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = if (dark) Wine else Color.White)) {
        Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(label, color = if (dark) Rose else Subdued, style = MaterialTheme.typography.labelMedium)
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, color = if (dark) Color.White else Ink, maxLines = 1)
            Text(subtitle, color = if (dark) Rose else Gold, style = MaterialTheme.typography.labelSmall)
        }
    }
}
@Composable fun SectionTitle(text: String, trailing: String = "", onClick: (() -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(text, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (trailing.isNotBlank()) Text(trailing, color = Wine, modifier = Modifier.clickable(enabled=onClick!=null) { onClick?.invoke() }, style = MaterialTheme.typography.labelMedium)
    }
}
@Composable fun EmptyState(title: String, detail: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(vertical = 38.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Outlined.Inventory2, null, tint = Gold, modifier = Modifier.size(42.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(detail, color = Subdued, style = MaterialTheme.typography.bodyMedium)
    }
}
@Composable fun ErrorCard(message: String, retry: (() -> Unit)? = null) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F0)), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Outlined.ErrorOutline, null, tint = Color(0xFFA23D3D))
            Text(message, modifier = Modifier.weight(1f), color = Color(0xFF7F3131), style = MaterialTheme.typography.bodyMedium)
            if (retry != null) TextButton(onClick = retry) { Text("Retry") }
        }
    }
}
@Composable fun SuccessCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5EF)), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Outlined.CheckCircle, null, tint = Sage)
            Text(message, color = Sage, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
@Composable fun Pill(text: String, color: Color = Wine) {
    Box(Modifier.clip(CircleShape).background(color.copy(alpha=0.11f)).padding(horizontal = 11.dp, vertical = 5.dp)) {
        Text(text, color = color, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}
@Composable fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).padding(horizontal=18.dp, vertical=14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp), content=content)
}
@Composable fun Busy() {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color=Gold) }
}
@Composable fun DividerLine() = HorizontalDivider(color=Color(0xFFEDE7E2), thickness=1.dp)
