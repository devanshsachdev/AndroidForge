package `in`.maahee.pos

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import org.json.JSONObject

/** Native Android PDF print/share. No WebView, browser login or print-service dependency. */
object Receipt {
    private fun bytes(record: JSONObject): ByteArray {
        val sale = record.getJSONObject("sale")
        val lines = record.getJSONArray("items").asObjects()
        val document = PdfDocument()
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=21f;color=android.graphics.Color.rgb(90,41,58);typeface=Typeface.DEFAULT_BOLD }
        val normal = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=11f;color=android.graphics.Color.DKGRAY }
        val bold = Paint(normal).apply { typeface=Typeface.DEFAULT_BOLD }
        val small = Paint(normal).apply { textSize=9f }
        var pageNumber=0
        var page:PdfDocument.Page?=null
        var y=48f
        fun nextPage() {
            page?.let { document.finishPage(it) }
            pageNumber++
            page = document.startPage(PdfDocument.PageInfo.Builder(595,842,pageNumber).create())
            y=48f
            page!!.canvas.drawText("MAAHEE  |  THE FASHION STUDIO",42f,y,title)
            y+=27f
            page!!.canvas.drawText("Invoice #${sale.str("invoice_no").ifBlank{sale.str("ser_no").ifBlank{sale.str("id")}}}",42f,y,bold)
            page!!.canvas.drawText(sale.str("date"),350f,y,small)
            y+=20f
            page!!.canvas.drawText("Customer: ${sale.str("customer_name").take(72)}",42f,y,normal)
            y+=24f
            page!!.canvas.drawLine(42f,y,551f,y,normal)
            y+=20f
        }
        nextPage()
        lines.forEachIndexed { i,line ->
            if(y>750)nextPage()
            val name=line.str("product_name").ifBlank{line.str("product_code")}.take(60)
            page!!.canvas.drawText("${i+1}. $name",42f,y,normal)
            y+=16f
            page!!.canvas.drawText("${line.str("quantity")} × ${line.money("real_unit_price").rupees()}",54f,y,small)
            page!!.canvas.drawText(line.money("subtotal").rupees(),420f,y,bold)
            y+=23f
        }
        if(y>690)nextPage()
        y+=10f
        page!!.canvas.drawLine(42f,y,551f,y,normal)
        y+=24f
        listOf("Total" to sale.money("grand_total"),"Paid" to sale.money("paid"),
            "Balance" to (sale.money("grand_total")-sale.money("paid"))).forEach { (label,amount) ->
            page!!.canvas.drawText(label,300f,y,bold)
            page!!.canvas.drawText(amount.rupees(),420f,y,bold)
            y+=22f
        }
        y+=12f
        page!!.canvas.drawText("Thank you for choosing Maahee.",42f,y,normal)
        page?.let { document.finishPage(it) }
        val out=java.io.ByteArrayOutputStream()
        document.writeTo(out)
        document.close()
        return out.toByteArray()
    }
    fun share(context:Context,record:JSONObject) {
        val folder=File(context.cacheDir,"receipts").apply{mkdirs()}
        val file=File(folder,"maahee_invoice_${record.getJSONObject("sale").optInt("id")}.pdf")
        FileOutputStream(file).use { it.write(bytes(record)) }
        val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",file)
        val intent=Intent(Intent.ACTION_SEND).apply{
            type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent,"Share invoice PDF"))
    }
    fun print(context:Context,record:JSONObject) {
        val pdf=bytes(record)
        val manager=context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        manager.print("Maahee Invoice",object:PrintDocumentAdapter(){
            override fun onLayout(oldAttributes:PrintAttributes?,newAttributes:PrintAttributes?,
                cancellationSignal:CancellationSignal?,callback:LayoutResultCallback?,extras:android.os.Bundle?) {
                if(cancellationSignal?.isCanceled==true){callback?.onLayoutCancelled();return}
                callback?.onLayoutFinished(PrintDocumentInfo.Builder("maahee_invoice.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true)
            }
            override fun onWrite(pages:Array<out PageRange>?,destination:ParcelFileDescriptor?,
                cancellationSignal:CancellationSignal?,callback:WriteResultCallback?) {
                if(cancellationSignal?.isCanceled==true){callback?.onWriteCancelled();return}
                try {
                    FileOutputStream(destination!!.fileDescriptor).use { it.write(pdf) }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch(e:Exception){ callback?.onWriteFailed(e.message) }
            }
        },PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
    }
}
