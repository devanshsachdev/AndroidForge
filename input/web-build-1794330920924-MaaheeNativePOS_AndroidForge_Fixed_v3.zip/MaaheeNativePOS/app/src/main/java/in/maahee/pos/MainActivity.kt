package `in`.maahee.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaaheeTheme { MaaheeApp() } }
    }
}

@Composable fun MaaheeApp() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val auth = remember { AuthStore(ctx) }
    val api = remember { PosApi(auth) }
    val scope = rememberCoroutineScope()
    val billingDraft = remember { BillingDraft() }
    var loggedIn by remember { mutableStateOf(auth.token.isNotBlank()) }
    var store by remember { mutableIntStateOf(auth.storeId) }
    var page by remember { mutableStateOf("home") }
    var selectedSale by remember { mutableIntStateOf(0) }
    if (!loggedIn) {
        LoginScreen(auth, api) { payload ->
            auth.token = payload.str("token")
            auth.name = payload.optJSONObject("user")?.str("name") ?: "Team member"
            auth.storeId = payload.optInt("store_id", 0)
            store = auth.storeId
            loggedIn = true
        }
        return
    }
    if (store == 0) {
        SelectStoreScreen(api) { id -> store = id; auth.storeId = id }
        return
    }
    val title = when {
        page == "home" -> "Overview"
        page == "billing" -> "New Bill"
        page == "sales" -> "Sales"
        page == "products" -> "Products"
        page == "more" -> "All Modules"
        page.startsWith("sale:") -> "Invoice"
        page.startsWith("module:") -> allModules.find { it.id == page.removePrefix("module:") }?.title ?: "Module"
        else -> "Maahee"
    }
    Scaffold(
        containerColor = Cream,
        topBar = {
            Surface(color = Cream) {
                Row(Modifier.fillMaxWidth().statusBarsPadding().height(66.dp).padding(horizontal = 19.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.AutoAwesome, "Maahee", tint=Gold, modifier=Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MAAHEE", fontWeight=FontWeight.Bold, color=Wine, style=MaterialTheme.typography.labelMedium)
                        Text(title, style=MaterialTheme.typography.titleMedium, maxLines=1, overflow=TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { page = "more" }) { Icon(Icons.Outlined.Apps, "Modules", tint=Wine) }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                listOf(
                    Triple("home", "Home", Icons.Outlined.SpaceDashboard),
                    Triple("billing", "Bill", Icons.Outlined.PointOfSale),
                    Triple("sales", "Sales", Icons.Outlined.ReceiptLong),
                    Triple("products", "Stock", Icons.Outlined.Inventory2),
                    Triple("more", "More", Icons.Outlined.GridView)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(selected = page == route,
                        onClick = { page = route }, icon = { Icon(icon, null) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor=Wine, selectedTextColor=Wine, indicatorColor=Rose))
                }
            }
        }
    ) { padding ->
        AnimatedContent(targetState = page,
            transitionSpec = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(220)) togetherWith
                    slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(160))
            }, label="screen", modifier=Modifier.fillMaxSize().padding(padding)) { route ->
            when {
                route == "home" -> DashboardScreen(api, { page = it })
                route == "billing" -> BillingScreen(api, onSaved = { id -> selectedSale = id; page = "sale:$id" }, draft = billingDraft)
                route == "sales" -> SalesScreen(api) { id -> selectedSale = id; page = "sale:$id" }
                route == "products" -> ProductsScreen(api) { page = "billing" }
                route == "more" -> ModuleMenuScreen(auth, { page = "module:${it.id}" }, {
                    scope.launch { try { api.logout() } catch (_: Exception) {} ; auth.clear(); loggedIn = false; page = "home" }
                }) { store=0; auth.storeId=0 }
                route.startsWith("sale:") -> InvoiceScreen(api, selectedSale) { page = "sales" }
                route.startsWith("module:") -> {
                    val module = allModules.find { it.id == route.removePrefix("module:") }
                    if (module == null) EmptyState("Unavailable module", "This feature is not defined.")
                    else ModuleScreen(module, api, onBill = { page = "billing" }, onSale = { id -> selectedSale=id; page="sale:$id" })
                }
            }
        }
    }
}
