package `in`.maahee.pos

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable fun RegisterScreen(api:PosApi) {
    var result by remember{mutableStateOf<JSONObject?>(null)}
    var loading by remember{mutableStateOf(true)}
    var saving by remember{mutableStateOf(false)}
    var openingCash by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var refresh by remember{mutableIntStateOf(0)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(refresh){loading=true;try{result=api.registerStatus()}catch(e:Exception){error=e.message.orEmpty()}finally{loading=false}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        BrandHeader("Cash management","Store register","Confirm your opening float before billing.")
        if(loading)Busy()
        if(error.isNotBlank())ErrorCard(error)
        result?.let{ data ->
            PremiumCard {
                if(data.optBoolean("open")){
                    SuccessCard("This store's POS register is open")
                    val reg=data.optJSONObject("register")
                    Text("Opened at ${reg?.str("date") ?: ""}")
                    Text("Opening cash: ${(reg?.money("cash_in_hand") ?: 0.0).rupees()}")
                    Text("Register #${reg?.optInt("id") ?: ""}",color=Subdued)
                    DividerLine()
                    Text("Register closing requires cash/card/cheque reconciliation and is not enabled in this mobile release.",color=Subdued)
                } else {
                    Text("Open a new register",style=MaterialTheme.typography.titleLarge)
                    OutlinedTextField(openingCash,{openingCash=it},label={Text("Opening cash in hand (₹)")},
                        modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                    Button(onClick={saving=true;error="";scope.launch{
                        try{api.openRegister(openingCash.toDoubleOrNull() ?: -1.0);refresh++}
                        catch(e:Exception){error=e.message.orEmpty()}finally{saving=false}
                    }},enabled=!saving&&openingCash.toDoubleOrNull()?.let{it>=0}==true,modifier=Modifier.fillMaxWidth()){
                        Icon(Icons.Outlined.LockOpen,null);Spacer(Modifier.width(8.dp));Text("Open register")
                    }
                }
            }
        }
        Text("Opening and closing are auditable operations. Close your register using the current web POS until native reconciliation is implemented.",
            color=Subdued,style=MaterialTheme.typography.bodySmall)
    }
}
