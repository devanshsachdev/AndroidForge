package `in`.maahee.pos

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable fun InvoiceScreen(api:PosApi,id:Int,back:()->Unit){
    val ctx=LocalContext.current
    var invoice by remember(id){mutableStateOf<JSONObject?>(null)}
    var error by remember(id){mutableStateOf("")}
    var loading by remember(id){mutableStateOf(true)}
    LaunchedEffect(id){try{invoice=api.sale(id)}catch(e:Exception){error=e.message.orEmpty()}finally{loading=false}}
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item { TextButton(onClick=back){Icon(Icons.Outlined.ArrowBack,null);Text("All sales")}}
        item {BrandHeader("Your invoice","Receipt #$id","An accurate view of the saved sale.")}
        if(loading)item{Busy()}
        if(error.isNotEmpty())item{ErrorCard(error)}
        invoice?.let{ record ->
            val sale=record.getJSONObject("sale")
            val lines=record.optJSONArray("items")?.asObjects().orEmpty()
            item {PremiumCard {
                Text("MAAHEE — THE FASHION STUDIO",color=Gold,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold)
                DividerLine()
                InvoiceRow(sale)
                TotalRowInvoice("Invoice date",sale.str("date"))
                TotalRowInvoice("Customer",sale.str("customer_name"))
                TotalRowInvoice("Status",sale.str("status"))
            }}
            item{SectionTitle("Invoice lines")}
            items(lines){line->PremiumCard {
                Text(line.str("product_name"),fontWeight=FontWeight.SemiBold)
                Text("${line.str("quantity")} × ${line.money("real_unit_price").rupees()}",color=Subdued)
                TotalRowInvoice("Line total",line.money("subtotal").rupees())
            }}
            item{PremiumCard {
                TotalRowInvoice("Grand total",sale.money("grand_total").rupees())
                TotalRowInvoice("Paid",sale.money("paid").rupees())
                DividerLine()
                TotalRowInvoice("Balance",(sale.money("grand_total")-sale.money("paid")).rupees())
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick={Receipt.print(ctx,record)},modifier=Modifier.weight(1f)) {
                        Icon(Icons.Outlined.Print,null);Spacer(Modifier.width(6.dp));Text("Print")
                    }
                    Button(onClick={Receipt.share(ctx,record)},modifier=Modifier.weight(1f)) {
                        Icon(Icons.Outlined.Share,null);Spacer(Modifier.width(6.dp));Text("Share PDF")
                    }
                }
            }}
        }
    }
}
@Composable private fun TotalRowInvoice(name:String,value:String){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(name,color=Subdued,modifier=Modifier.weight(1f))
        Text(value,fontWeight=FontWeight.SemiBold)
    }
}
