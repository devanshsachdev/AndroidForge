package `in`.maahee.pos

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import org.json.JSONArray

@Composable fun SalesSparkline(data: JSONArray?) {
    val records = data?.asObjects().orEmpty()
    val levels = (0 until 7).map { index ->
        // The server supplies the most recent seven days; absent days are displayed as zero.
        val days = java.time.LocalDate.now().minusDays((6-index).toLong()).toString()
        records.firstOrNull { it.str("day") == days }?.money("total") ?: 0.0
    }
    val max = levels.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(data) { started = true }
    val progress by animateFloatAsState(if(started)1f else 0f,tween(850),label="chart reveal")
    PremiumCard {
        Text("7-DAY SALES",style=MaterialTheme.typography.labelSmall,color=Gold)
        Text(levels.sum().rupees(),style=MaterialTheme.typography.headlineMedium,color=Wine)
        Canvas(Modifier.fillMaxWidth().height(112.dp)) {
            val step=size.width/7f
            levels.forEachIndexed { index,value ->
                val height=(size.height*0.87f*(value/max).toFloat()*progress).coerceAtLeast(if(value>0)3f else 0f)
                val width=step*0.52f
                drawRoundRect(color=if(index==6)Wine else Gold.copy(alpha=0.52f),
                    topLeft=Offset(index*step+step*0.24f,size.height-height),
                    size=Size(width,height),cornerRadius=androidx.compose.ui.geometry.CornerRadius(9f,9f))
            }
        }
        Text("Last seven calendar days · live billed amount",color=Subdued,style=MaterialTheme.typography.bodySmall)
    }
}
