# Maahee Caller ID Android V1.4 — Offline-First Calls

AndroidForge-ready native Kotlin Android app. Store 3 only.

## Why V1.4
The call-screening callback and centered popup already worked in V1.3.
During calls, DNS requests for pos.maahee.co.in may fail even when manual POS lookup works.
Repeated DNS retries cannot guarantee service. V1.4 reads an encrypted offline
Store 3 caller snapshot first, then attempts a live refresh without delaying ringing.

## First-time setup (no Android Studio needed)
1. BACK UP `app/controllers/api/Caller.php` on the POS server.
2. Upload V1.4 API controller to `app/controllers/api/Caller.php` on pos.maahee.co.in.
   Do not replace the existing `app/config/caller_api.php` or its token.
3. Upload THIS ZIP to AndroidForge and compile APK (not the PHP ZIP).
4. Install the APK over the existing app (same applicationId). Do not uninstall;
   reinstalling afresh erases app settings and offline cache.
5. While connected to working internet/Wi-Fi, open the app and tap
   `SYNC STORE 3 FOR OFFLINE CALLS`. Wait for completion, which reports
   the number of saved caller numbers. This is a read-only API operation.
6. Optionally enable `Auto-sync on unmetered Wi-Fi` for best-effort background
   refresh about every 12 hours; Android/Samsung may defer background jobs.
7. Enter a known customer number and press `TEST OFFLINE CACHE (NO INTERNET)`.
   This reads ONLY the encrypted local directory; no API requests are made.
8. Test a regular incoming phone call. The cached Store 3 customer should
   appear without depending on live DNS. Fresh POS details replace it if reachable.

## Security/privacy
- API is read-only and requires existing Bearer token over HTTPS.
- Sync endpoint only includes customers with sales in Store 3, and only their
  latest 3 Store 3 purchases plus latest associated alteration ticket.
- The local cache is stored in app-private files encrypted with an AES-256-GCM
  key held in Android Keystore. No data is synced to third-party services.
- Protect the phone with a strong lock screen; this app shows commercial
  customer details during incoming calls.
- `Erase saved customer directory` clears the on-device cache.
- Do NOT publish your API bearer token in GitHub. No token is embedded here.

## API
- Existing: `GET /api/caller/lookup?phone=...`
- Added:    `GET /api/caller/sync?after_id=0&limit=40`
- Both endpoints require `Authorization: Bearer <secret>`.
- The full sync uses keyset pagination and does not overwrite the previous
  offline directory until all pages have been downloaded and encrypted.

## Troubleshooting
If SYNC fails: ensure the POS V1.4 controller has been uploaded, and that the
POS API token entered in the Android app matches the server config.
If the test of offline data shows no customer, check that sync completed and
that the customer has a Store 3 sale.
If no popup appears at all: verify Call Screening and Display Over Apps roles.

Full Gradle build must be run in AndroidForge/Android Studio; XML and PHP syntax
have been validated in the packaging environment.
