package com.maahee.callerid

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Paginated read-only Store 3 snapshot. Uses the existing bearer token. */
object DirectorySync {
    data class Outcome(val ok: Boolean, val count: Int, val message: String)
    private const val PAGE_SIZE = 40
    private const val MAX_PAGES = 500

    fun sync(context: Context, progress: (String) -> Unit): Outcome {
        val apiUrl = Prefs.apiUrl(context).substringBefore('?').trimEnd('/')
        val token = Prefs.token(context).trim()
        if (!apiUrl.startsWith("https://pos.maahee.co.in/api/caller/lookup") || token.isBlank()) {
            return Outcome(false, 0, "Configure the POS URL and API token first.")
        }
        val base = apiUrl.removeSuffix("/lookup") + "/sync"
        val records = JSONObject()
        var cursor = 0L
        try {
            for (page in 1..MAX_PAGES) {
                progress("Syncing Store 3 customers… page $page • ${records.length()} numbers")
                val conn = (URL("$base?after_id=$cursor&limit=$PAGE_SIZE")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 20000
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("X-Maahee-Caller", "android-v1.4-sync")
                }
                val body: String
                val status: Int
                try {
                    status = conn.responseCode
                    body = if (status in 200..299) {
                        conn.inputStream.bufferedReader().use { it.readText() }
                    } else {
                        conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                    }
                } finally { conn.disconnect() }
                if (status !in 200..299) {
                    return Outcome(false, records.length(), "Sync API returned HTTP $status. Install POS Caller API V1.4. ${body.take(100)}")
                }
                val root = JSONObject(body)
                if (root.optInt("store_id", -1) != 3 || root.optString("status") != "success") {
                    return Outcome(false, records.length(), "Unexpected sync response; check Store 3 configuration.")
                }
                val items = root.optJSONArray("rows") ?: return Outcome(false, records.length(), "No rows in API response")
                val now = System.currentTimeMillis()
                for (i in 0 until items.length()) {
                    val row = items.optJSONObject(i) ?: continue
                    val payload = row.optJSONObject("payload") ?: continue
                    val phones = row.optJSONArray("phones") ?: continue
                    for (j in 0 until phones.length()) {
                        val p = OfflineCache.normalize(phones.optString(j))
                        if (p.isBlank()) continue
                        records.put(p, JSONObject().put("timestamp", now).put("payload", payload))
                    }
                }
                val next = root.optLong("next_after_id", -1L)
                if (next < cursor) return Outcome(false, records.length(), "Sync cursor error")
                if (!root.optBoolean("has_more", false)) {
                    OfflineCache.replaceDirectory(context, records)
                    return Outcome(true, records.length(), "Saved ${records.length()} caller numbers securely for offline lookup.")
                }
                if (next == cursor) return Outcome(false, records.length(), "Sync stalled")
                cursor = next
            }
        } catch (e: Exception) {
            return Outcome(false, records.length(), "Sync not completed: ${e.javaClass.simpleName}. Old cache kept.")
        }
        return Outcome(false, records.length(), "Directory is larger than safety limit; old cache kept.")
    }
}
