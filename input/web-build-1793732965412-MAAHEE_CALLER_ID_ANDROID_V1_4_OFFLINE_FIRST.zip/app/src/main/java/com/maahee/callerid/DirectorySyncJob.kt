package com.maahee.callerid

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/** Daily Wi-Fi automatic update. Android decides the actual execution time. */
class DirectorySyncJob : JobService() {
    @Volatile private var stopped = false

    override fun onStartJob(params: JobParameters): Boolean {
        stopped = false
        Thread {
            val outcome = DirectorySync.sync(applicationContext) { }
            if (!stopped) {
                CallDiagnostics.event(applicationContext,
                    if (outcome.ok) "Offline directory synced: ${outcome.count} numbers"
                    else "Offline directory sync unavailable")
                jobFinished(params, !outcome.ok)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        stopped = true
        return true
    }

    companion object {
        private const val ID = 463820
        fun schedule(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val job = JobInfo.Builder(ID, ComponentName(context, DirectorySyncJob::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)
                .setPeriodic(12L * 60L * 60L * 1000L)
                .setPersisted(true)
                .build()
            scheduler.schedule(job)
        }
        fun cancel(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            scheduler.cancel(ID)
        }
    }
}
