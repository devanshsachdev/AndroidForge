package com.maahee.callerid

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** App-private, Android Keystore AES-256-GCM encrypted Store 3 caller snapshot.
 * Stored records contain only the latest 3 purchases and the latest alteration ticket.
 * No call log is stored. Deleting app data destroys the cache and its key.
 */
object OfflineCache {
    data class Entry(val payload: JSONObject, val timestamp: Long)
    data class Stats(val count: Int, val lastSync: Long)
    private const val KEY_ALIAS = "maahee_store3_directory_v14"
    private const val FILE_NAME = "maahee_store3_directory.aes"
    private const val MAX_BYTES = 25 * 1024 * 1024
    private val lock = Any()

    fun normalize(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        return if (digits.length >= 10) digits.takeLast(10) else ""
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun directory(context: Context) = File(context.filesDir, FILE_NAME)

    private fun read(context: Context): JSONObject {
        val file = directory(context)
        if (!file.isFile || file.length() < 30 || file.length() > MAX_BYTES) return JSONObject()
        return try {
            val all = file.readBytes()
            if (all[0].toInt() != 1) return JSONObject()
            val nonce = all.copyOfRange(1, 13)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
            val plain = cipher.doFinal(all.copyOfRange(13, all.size))
            JSONObject(String(plain, Charsets.UTF_8))
        } catch (_: Exception) { JSONObject() }
    }

    private fun write(context: Context, container: JSONObject) {
        val bytes = container.toString().toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_BYTES - 128) { "Cache too large; sync a smaller directory." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(bytes)
        val tmp = File(context.filesDir, "$FILE_NAME.tmp")
        FileOutputStream(tmp).use { output ->
            output.write(byteArrayOf(1))
            output.write(cipher.iv)
            output.write(encrypted)
            output.fd.sync()
        }
        val target = directory(context)
        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IllegalStateException("Could not update encrypted cache")
        }
    }

    fun find(context: Context, phone: String): Entry? = synchronized(lock) {
        val normalized = normalize(phone)
        if (normalized.isEmpty()) return@synchronized null
        val value = read(context).optJSONObject("records")?.optJSONObject(normalized)
            ?: return@synchronized null
        val payload = value.optJSONObject("payload") ?: return@synchronized null
        Entry(payload, value.optLong("timestamp", 0L))
    }

    fun remember(context: Context, phone: String, payload: JSONObject) = synchronized(lock) {
        val normalized = normalize(phone)
        if (normalized.isEmpty() || !payload.optBoolean("found", false)) return@synchronized
        val root = read(context)
        val records = root.optJSONObject("records") ?: JSONObject()
        records.put(normalized, JSONObject()
            .put("timestamp", System.currentTimeMillis())
            .put("payload", payload))
        root.put("records", records)
        write(context, root)
    }

    fun forget(context: Context, phone: String) = synchronized(lock) {
        val normalized = normalize(phone)
        if (normalized.isEmpty()) return@synchronized
        val root = read(context)
        val records = root.optJSONObject("records") ?: return@synchronized
        records.remove(normalized)
        write(context, root)
    }

    /** Commit only after ALL pages have loaded successfully, so failed syncs
     * never destroy the previous offline directory. */
    fun replaceDirectory(context: Context, newRecords: JSONObject) = synchronized(lock) {
        val now = System.currentTimeMillis()
        write(context, JSONObject().put("records", newRecords).put("last_full_sync", now))
    }

    fun stats(context: Context): Stats = synchronized(lock) {
        val root = read(context)
        Stats(root.optJSONObject("records")?.length() ?: 0, root.optLong("last_full_sync", 0L))
    }

    fun clear(context: Context) = synchronized(lock) {
        directory(context).delete()
    }
}
