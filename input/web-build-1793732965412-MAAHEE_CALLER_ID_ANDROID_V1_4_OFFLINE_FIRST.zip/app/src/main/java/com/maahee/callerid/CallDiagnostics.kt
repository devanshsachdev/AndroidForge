package com.maahee.callerid

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local-only diagnostics: does not store complete caller numbers or send diagnostics to the server. */
object CallDiagnostics {
    private const val FILE = "maahee_caller_diagnostics"
    private const val TAG = "MaaheeCallScreen"

    fun event(context: Context, message: String) {
        val stamp = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()).format(Date())
        val detail = "$stamp — $message"
        Log.i(TAG, message)
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString("last_event", detail).apply()
    }

    fun incoming(context: Context, maskedPhone: String) {
        val stamp = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()).format(Date())
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString("last_incoming", "$stamp — $maskedPhone").apply()
        event(context, "Incoming call callback received ($maskedPhone)")
    }

    fun lastEvent(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString("last_event", "No incoming call callback recorded yet") ?: "Not available"

    fun lastIncoming(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString("last_incoming", "No incoming call callback recorded yet") ?: "Not available"

    fun mask(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return if (digits.length >= 4) "••••" + digits.takeLast(4) else "number withheld / unavailable"
    }
}
