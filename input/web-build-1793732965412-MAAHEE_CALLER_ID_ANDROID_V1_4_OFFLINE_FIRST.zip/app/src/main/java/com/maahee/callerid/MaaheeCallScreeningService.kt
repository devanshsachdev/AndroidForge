package com.maahee.callerid

import android.telecom.Call
import android.telecom.CallScreeningService

/** System-invoked only; no always-running background service or call blocking. */
class MaaheeCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) return

        // Enqueue the UI before the Telecom framework unbinds this short-lived service.
        // No network request or blocking work happens on this callback thread.
        try {
            val handle = callDetails.handle
            val phone = if (handle?.scheme.equals("tel", ignoreCase = true))
                handle?.schemeSpecificPart?.trim().orEmpty() else ""
            CallDiagnostics.incoming(applicationContext, CallDiagnostics.mask(phone))
            if (phone.isNotBlank()) {
                CallerOverlay.showAndLookup(applicationContext, phone)
            } else {
                CallDiagnostics.event(applicationContext, "Call has no available phone number")
            }
        } catch (error: Exception) {
            CallDiagnostics.event(applicationContext, "Caller UI trigger failed (${error.javaClass.simpleName})")
        } finally {
            // Incoming calls MUST be answered within 5 seconds, regardless of any UI failure.
            try {
                respondToCall(
                    callDetails,
                    CallResponse.Builder()
                        .setDisallowCall(false)
                        .setRejectCall(false)
                        .setSilenceCall(false)
                        .setSkipCallLog(false)
                        .setSkipNotification(false)
                        .build()
                )
            } catch (error: Exception) {
                CallDiagnostics.event(applicationContext, "Telecom response failed (${error.javaClass.simpleName})")
            }
        }
    }
}
