package com.maahee.callerid

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Optional caller heads-up notification as a fallback when Samsung obscures overlays. */
object CallNotification {
    private const val CHANNEL = "maahee_incoming_call_backup_v1"
    private const val ID = 44382

    fun show(context: Context, maskedPhone: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            CallDiagnostics.event(context, "Notification backup permission not granted")
            return
        }
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Maahee incoming customer", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Backup alert when an incoming caller popup cannot be displayed"
                }
            )
            val launch = Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pending = PendingIntent.getActivity(
                context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Maahee incoming customer")
                .setContentText("Incoming call: $maskedPhone. Tap to open Maahee Caller ID.")
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_CALL)
                .build()
            manager.notify(ID, notification)
            CallDiagnostics.event(context, "Backup call notification posted")
        } catch (error: Exception) {
            CallDiagnostics.event(context, "Backup notification failed (${error.javaClass.simpleName})")
        }
    }
}
