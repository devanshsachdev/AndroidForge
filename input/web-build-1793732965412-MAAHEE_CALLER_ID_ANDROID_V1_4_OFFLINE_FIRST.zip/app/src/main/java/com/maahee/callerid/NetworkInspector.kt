package com.maahee.callerid

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** A short, non-sensitive network diagnostic used only for POS connection errors. */
object NetworkInspector {
    fun describe(context: Context): String {
        return try {
            val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = manager.activeNetwork
            if (network == null) {
                "No active data network"
            } else {
                val caps = manager.getNetworkCapabilities(network)
                if (caps == null) {
                    "Network capabilities unavailable"
                } else {
                    val transport = when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                        else -> "Other network"
                    }
                    val internet = if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        "internet validated"
                    } else {
                        "internet not validated"
                    }
                    "$transport ($internet)"
                }
            }
        } catch (_: Exception) {
            "Network status unavailable"
        }
    }
}
