# Maahee Phone 2.2.2 — call screen cleanup and recording diagnostics

See `V2_2_2_RELEASE_NOTES.md` for current behaviour and device checklist. Same application ID, version code 13. No server changes.

# Maahee Phone 2.2.1 — Kotlin context build fix

See `V2_2_1_RELEASE_NOTES.md` for this patch; see `V2_2_RELEASE_NOTES.md` for the latest changes, limitations and device checklist. The documentation below describes the inherited V2.1 features.

# Version 2.1 update

Read [V2_1_RELEASE_NOTES.md](V2_1_RELEASE_NOTES.md) for the new settings flow, Google Phone-inspired interface, messaging, privileged-only recording and upgrade instructions. The original V2.0 architecture notes follow.

# Maahee Phone 2.0.0 — native dialer + customer desk

**Source preview for AndroidForge / Android Studio, not a compiled APK.**

Application ID: `com.maahee.callerid` • versionCode 9 • minSdk 29 • compile/target SDK 35 • JDK 17 • AGP 8.7.3 • Kotlin 2.0.21.

## Design and compatibility

The existing Maahee 1.7.1 application is the base. The original POS client, settings, hourly best-effort sync job, encrypted Store 3 directory, lookup UI and non-default-dialer screening/overlay remain. The launcher is now Maahee Phone; settings opens the original Maahee dashboard. Native Android Telecom handles calls when Maahee holds ROLE_DIALER, avoiding a duplicate caller overlay; legacy screening remains optional when not default. Same package ID, cache file, cache key, preferences and versioned configuration; updating using the same signing certificate preserves existing app data. No new server endpoint or external library is required by this release. Existing POS endpoint contract and Store 3 restrictions remain. Do not uninstall if you need existing cached data and settings.

Architectural references reviewed: https://github.com/oxcened/opendialer (provided 0.3.4, Apache 2.0) and https://github.com/dhilipmpms/NovaDial (provided 1.8.0, GPL 3.0). No reference project code/assets or their dependencies are incorporated. Telecom API documentation: https://developer.android.com/develop/connectivity/telecom/dialer-app .

## Features in this source preview

- Native Telephony/Telecom integration: default-dialer role, incoming full-screen/heads-up call notifications, answer/decline, outgoing calls, call duration, disconnect, mute, hold/resume, DTMF keypad, audio routes, add call, conference merge when supported, multiple-call selection, SIM/account selection when Telecom requires it. Android 14+ uses CallEndpoint APIs for audio routing; legacy routing on older devices.
- Recents grouped by number, incoming/outgoing/missed/rejected type labels, searchable names, contacts and favorites. Up to latest 500 system records and 200 matching groups per refresh; number timeline shows up to 500 matching calls. No separate duplicate log database. Deliberately excludes hidden/private numbers from per-number annotations.
- Number history detail: local caller profile, category, favorite and timestamped notes; each individual log entry can be annotated, notes can be edited/deleted. A note created during a call uses Telecom creation timestamp; the timeline attempts to associate entries within 2 seconds and all notes remain accessible in the profile if timestamps differ.
- Caller name overrides displayed names in Maahee only; optional Save to phone contacts launches the device's own editor. Existing POS names remain intact. No automatic Android contact writes. All annotations are encrypted using Android Keystore AES-GCM and atomic file replacement. Notes are local to this device: not shared between staff phones, not synced to POS, no server-side write capability. No call recording.
- Existing customer lookup remains available. Native incoming screen and number details query cache first and refresh live POS asynchronously. Detail page includes customer name, recent sales, invoice numbers, payment balances, alteration ticket/status/due date, and trusted links to customer, latest invoice and tracker. Existing API limits the fields available. No online lookup for international/service codes in the new dialer pages; Indian +91/local formats normalize consistently. No POS/network work blocks answer or end-call operations.
- Customer lookup pulse animation, result reveal, premium plum/gold palette, branded launcher mark. Private POS data and annotations are not shown by the incoming UI while device is locked. Call notifications do not include POS data. New notes and cache remain app-private, with app backup disabled.

## Install on a spare test phone first

1. Upload this ZIP as a fresh AndroidForge input (same single-module structure as 1.7.1). Build `:app:assembleDebug` using Android SDK 35 and JDK 17. Or open the root Gradle project in Android Studio. AndroidForge supplies Gradle/wrapper as in the preceding release; wrapper files are not bundled.
2. Install using the same signature as the installed Maahee app for in-place upgrade. If signing differs, do not uninstall your production app merely to test this release; use a spare test phone.
3. Open Maahee Phone > Enable default phone & permissions > select Maahee Phone in the Android role prompt. Allow phone, call history, contacts (optional for contact view) and notifications. Android 14+: allow full-screen incoming calls in the system setting if prompted. The legacy overlay permission is not needed in native dialer mode.
4. Tap Settings, verify existing API URL/token (default lookup URL `https://pos.maahee.co.in/api/caller/lookup`), and run Store 3 sync if necessary. This archive does not contain private API tokens or signing keys.
5. Call the test phone from a known Store 3 phone and an unknown number, accept and annotate; then close the app and reopen Recents > tap the number. Verify notes persist and live and offline purchase details match the previous overlay.
6. Keep the system Phone app installed. If calls are not appearing reliably, go to Android Settings > Apps > Default apps > Phone app and select the original phone app immediately. Maahee lookup/legacy caller ID remain available separately if its screening role is enabled. Do not use an untested replacement dialer as the only phone on a production or emergency-critical device.

## Acceptance tests before store rollout

- **Build:** APK compiles, starts, and same-signature update preserves settings/cache. Check AndroidForge diagnostic logs for any compiler failures.
- **Call reliability:** Incoming call in foreground, background, locked and screen-off, call waiting, decline, end, missed, outgoing from keypad and system tel links. Verify notification actions and ongoing call return path. Test Android 10–15 supported versions as available and the actual target store phone. Confirm no duplicate overlay. Never use emergency numbers for test calls.
- **Permissions:** Role denied, contacts denied, call log permission denied, notifications off, full-screen intent denied; confirm graceful fallbacks. Check restoration of system default phone.
- **Telephony:** both SIMs and default/non-default SIM selection, mute, speaker, Bluetooth, wired audio, DTMF, hold, conference, add call, network lost, airplane mode. These features are dependent on carrier, OEM and device. Video calling, visual voicemail, advanced accessibility/RTT, spam filtering/blocking, call recording and cross-device notes are not implemented in this preview.
- **Business data:** test known customer, unknown number, stale cache, POS offline, wrong token, partial sync, international number with same last 10 digits, note saved while ringing/active, note edit/delete, multiple calls with notes, same number using +91 and local format. Confirm lock-screen doesn't display private customer history/notes. Notes are not backed up or synced.

## Verification performed in authoring environment

- 9 original phone parsing regression checks and 16 additional dialer identity checks passed.
- Kotlin PSI syntax parsing of all 26 source files, XML parsing, resource cross-reference and manifest component checks passed during development.
- Actual Android SDK/Gradle compile, APK install, runtime permissions, real calls, notifications, POS server responses, encryption on a physical Android device, and OEM compatibility have **not** been verified. Treat as an initial integration build, not production-certified phone replacement. Send exact AndroidForge diagnostic output to resolve build issues.

See `README_V1_7_1.md` for the retained previous release documentation (legacy behavior only).
