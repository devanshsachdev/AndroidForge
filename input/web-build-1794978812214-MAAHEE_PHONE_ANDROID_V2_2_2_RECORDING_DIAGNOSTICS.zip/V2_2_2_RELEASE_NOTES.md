# Maahee Phone 2.2.2 — call screen cleanup and recording diagnostics

- Removed the separate Audio route button and its dialog from the live call screen. Speaker toggle, Telecom audio endpoint callbacks, headset routing, mute, keypad and proximity handling remain.
- Settings now shows device manufacturer/model, Android/API version, system call audio grant, microphone grant, saved count, and latest direct recording event (if any). No phone numbers are logged in diagnostics.
- Direct recording still requires a privileged firmware installation with CAPTURE_AUDIO_OUTPUT and RECORD_AUDIO. Selecting Maahee as default dialer alone cannot obtain the privileged permission. Automatic recording remains opt-in, with consent and existing exclusions. No hidden microphone or accessibility capture fallback was added.
- Customer detail > Call recordings > Import existing recording opens the Android document picker. Choose an audio file that belongs to that caller and that you have permission to retain. A private copy (maximum 250 MiB) is validated for an audio track and positive duration, then associated with the normalized number. Existing recordings remain unchanged. Imported files are marked as imported; their displayed date is import time, not necessarily call time. They appear in the caller's recordings and the whole recording library, with playback and deletion. This is manual import, not automatic access to the original dialer's recordings. If the manufacturer dialer cannot export audio, the import route is unavailable. For built-in recording, the device may require its stock dialer to be selected as default.
- Same package and private storage; use the same signing key when updating. Version code 13. No POS server changes.

## Device checklist
1. Build and install the ZIP as an update, open Settings > Call recording, check the two grants and device model.
2. Make a test call. Verify that only Speaker appears (no Audio route button), and that proximity and headset handling still work.
3. If both recording grants are present, obtain caller consent and test manual and opt-in automatic recording, then check playback of both voices. A grant does not guarantee firmware support. If system call audio is not granted, direct recording is unavailable.
4. For manual import, open a known number in Recents, select an audio file, confirm it appears in both libraries, play it, delete the imported copy, and verify the original source remains intact. Test a canceled picker and an invalid file.

Full Gradle and physical-device testing are pending.
