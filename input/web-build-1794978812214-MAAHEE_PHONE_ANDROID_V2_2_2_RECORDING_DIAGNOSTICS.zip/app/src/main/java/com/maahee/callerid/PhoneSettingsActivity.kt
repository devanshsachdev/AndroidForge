package com.maahee.callerid

import android.Manifest
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock

class PhoneSettingsActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    override fun onCreate(state:Bundle?){super.onCreate(state);val root=DialerUi.root(this);root.addBlock(DialerUi.button(this,"‹ Phone"){finish()});root.addBlock(DialerUi.text(this,"Settings",30f));body=DialerUi.scroll(root)}
    override fun onResume(){super.onResume();render()}
    private fun held()=getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_DIALER)==true
    private fun render(){body.removeAllViews();body.addBlock(DialerUi.text(this,"Phone setup",20f,true))
        body.addBlock(DialerUi.button(this,if(held()) "Default phone · enabled" else "Choose Maahee as default phone",!held()){val r=getSystemService(RoleManager::class.java);if(r?.isRoleAvailable(RoleManager.ROLE_DIALER)==true && !held())startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_DIALER),501)})
        val essential=mutableListOf(Manifest.permission.CALL_PHONE,Manifest.permission.READ_CALL_LOG,Manifest.permission.READ_PHONE_STATE);if(Build.VERSION.SDK_INT>=33)essential+=Manifest.permission.POST_NOTIFICATIONS
        val missing=essential.filter{!DialerData.allowed(this,it)}
        body.addBlock(DialerUi.button(this,if(missing.isEmpty())"Calling access · enabled" else "Grant calling permissions",missing.isNotEmpty()){if(!held())DialerUi.toast(this,"Choose default phone first")else if(missing.isNotEmpty())requestPermissions(missing.toTypedArray(),502)})
        body.addBlock(DialerUi.button(this,if(DialerData.allowed(this,Manifest.permission.READ_CONTACTS))"Contacts · enabled" else "Allow contacts"){if(!DialerData.allowed(this,Manifest.permission.READ_CONTACTS))requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS),503)})
        if(Build.VERSION.SDK_INT>=34){val granted=getSystemService(NotificationManager::class.java)?.canUseFullScreenIntent()==true;body.addBlock(DialerUi.button(this,if(granted)"Full-screen incoming calls · enabled" else "Allow full-screen incoming calls"){runCatching{startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:$packageName")))}})}
        body.addBlock(DialerUi.button(this,"Android app permissions"){startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))})
        body.addBlock(DialerUi.text(this,"Business tools",20f,true));body.addBlock(DialerUi.button(this,"POS connection & offline sync"){startActivity(Intent(this,MainActivity::class.java))});body.addBlock(DialerUi.button(this,"Customer lookup"){startActivity(Intent(this,CustomerLookupActivity::class.java))})
        body.addBlock(DialerUi.text(this,"Call recording",20f,true));body.addBlock(DialerUi.text(this,CallRecorder.status(this),15f));if(CallRecorder.privileged(this)&&!DialerData.allowed(this,Manifest.permission.RECORD_AUDIO))body.addBlock(DialerUi.button(this,"Allow recording microphone permission"){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),504)})
        body.addBlock(DialerUi.text(this,CallRecorder.diagnostic(this),13f))
        val auto=CallRecorder.autoEnabled(this)
        if(CallRecorder.supported(this)) body.addBlock(DialerUi.button(this,if(auto)"Automatic recording · On" else "Automatic recording · Off",auto){
            if(auto){CallRecorder.setAuto(this,false);render()}
            else androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Enable automatic call recording?").setMessage("Eligible single-party cellular calls will be recorded and saved locally. Inform callers and obtain any required consent before calls. Disable this setting whenever consent is not available. Emergency, private and unsupported calls are excluded.").setNegativeButton("Cancel",null).setPositiveButton("Enable"){_,_->CallRecorder.setAuto(this,true);render()}.show()
        })
        body.addBlock(DialerUi.button(this,"All saved recordings (${CallRecorder.allFiles(this).size})"){startActivity(Intent(this,RecordingLibraryActivity::class.java))})
        body.addBlock(DialerUi.text(this,"Maahee Phone 2.2.2",13f))
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);render()}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);render()}
}
