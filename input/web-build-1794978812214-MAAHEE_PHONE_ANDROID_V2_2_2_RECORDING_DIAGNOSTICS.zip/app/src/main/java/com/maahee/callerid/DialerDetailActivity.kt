package com.maahee.callerid

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual
import org.json.JSONObject

class DialerDetailActivity : AppCompatActivity() {
    companion object {
        fun intent(c: Context, number: String, date: Long = 0L) = Intent(c,DialerDetailActivity::class.java).putExtra("phone",number).putExtra("callTime",date)
    }
    private lateinit var phone: String
    private lateinit var title: TextView
    private lateinit var local: LinearLayout
    private lateinit var pos: LinearLayout
    private lateinit var history: LinearLayout
    private var serial=0
    private var historySerial=0
    private var player:android.media.MediaPlayer?=null
    private lateinit var recordings:LinearLayout
    private val audioPicker=registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null && ::phone.isInitialized) {
            val ctx=applicationContext; val number=phone
            Thread {
                val saved=CallRecorder.importAudio(ctx,number,uri)
                runOnUiThread { if(!isFinishing && !isDestroyed) { DialerUi.toast(this,if(saved) "Recording imported" else "Unable to import this audio file (maximum 250 MB)"); renderRecordings() } }
            }.start()
        }
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state); window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); phone=intent.getStringExtra("phone").orEmpty(); if(DialerIdentity.key(phone).isBlank()){finish();return}
        val root=DialerUi.root(this); root.addBlock(DialerUi.button(this,"‹ Phone history"){finish()}); title=DialerUi.text(this,phone,25f,true); root.addBlock(title); root.addBlock(DialerUi.text(this,phone,15f))
        val controls=DialerUi.row(this); controls.addEqual(DialerUi.button(this,"Dial",true){startActivity(Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",phone,null),this,DialerActivity::class.java))}); controls.addEqual(DialerUi.button(this,"Mark / add note"){edit(intent.getLongExtra("callTime",0L))}); controls.addEqual(DialerUi.button(this,"Message"){PhoneActions.message(this,phone)});root.addBlock(controls)
        root.addBlock(DialerUi.button(this,"Save to phone contacts") { runCatching { startActivity(Intent(Intent.ACTION_INSERT,android.provider.ContactsContract.Contacts.CONTENT_URI).putExtra(android.provider.ContactsContract.Intents.Insert.PHONE,phone).putExtra(android.provider.ContactsContract.Intents.Insert.NAME,title.text.toString().takeIf{it!=phone}.orEmpty())) }.onFailure { DialerUi.toast(this,"Contacts editor unavailable") } })
        val content=DialerUi.scroll(root)
        local=DialerUi.card(this); content.addBlock(local)
        content.addBlock(DialerUi.text(this,"Maahee POS · Store 03",20f,true)); pos=DialerUi.card(this); content.addBlock(pos)
        content.addBlock(DialerUi.button(this,"Refresh POS details"){loadPos()}); content.addBlock(DialerUi.text(this,"Call timeline",20f,true)); history=DialerUi.column(this); content.addBlock(history)
        recordings=DialerUi.column(this);content.addBlock(recordings);renderRecordings();renderLocal(); loadHistory(); loadPos()
    }
    override fun onResume(){super.onResume();if(::recordings.isInitialized)renderRecordings()}
    override fun onPause(){stopPlayback();super.onPause()}
    override fun onDestroy(){stopPlayback();serial++;historySerial++;super.onDestroy()}
    private fun stopPlayback(){runCatching{player?.release()};player=null}
    private fun renderRecordings(){recordings.removeAllViews();val files=CallRecorder.files(this,phone);recordings.addBlock(DialerUi.text(this,"Call recordings",20f,true));if(files.isEmpty()) recordings.addBlock(DialerUi.text(this,"No saved recordings for this number"));if(DialerIdentity.key(phone).matches(Regex("\\+?[0-9]{7,15}"))) recordings.addBlock(DialerUi.button(this,"Import existing recording") { androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Link recording to this caller?").setMessage("Choose an audio file you have permission to retain and confirm that it belongs to this number. A private copy will be saved in Maahee.").setNegativeButton("Cancel",null).setPositiveButton("Choose audio"){_,_->runCatching{audioPicker.launch(arrayOf("audio/*"))}.onFailure{DialerUi.toast(this,"File picker unavailable")}}.show() });files.forEach{f->val row=DialerUi.row(this);row.addEqual(DialerUi.button(this,"Play · ${if(f.extension=="audio") "Imported" else "Recorded"} · ${DialerUi.date(f.lastModified())}"){stopPlayback();runCatching{val m=android.media.MediaPlayer();player=m;m.setDataSource(f.absolutePath);m.prepare();m.setOnCompletionListener{stopPlayback()};m.start()}.onFailure{stopPlayback();DialerUi.toast(this,"Audio unavailable")}});row.addEqual(DialerUi.button(this,"Delete"){androidx.appcompat.app.AlertDialog.Builder(this).setMessage("Delete this recording?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->stopPlayback();if(f.delete())renderRecordings()else DialerUi.toast(this,"Could not delete")}.show()});recordings.addBlock(row)};if(files.isNotEmpty()) recordings.addBlock(DialerUi.button(this,"Stop playback"){stopPlayback()})}
    private fun edit(date:Long){DialerProfileEditor.show(this,phone,date){renderLocal();loadHistory()}}
    private fun renderLocal(){
        local.removeAllViews(); val p=runCatching{DialerNotes.profile(this,phone)}.getOrElse{local.addBlock(DialerUi.text(this,"Encrypted notes unavailable"));return}
        title.text=p.name.ifBlank{title.text.toString().ifBlank{phone}}; local.addBlock(DialerUi.text(this,"Caller profile",18f,true)); local.addBlock(DialerUi.text(this,listOf(p.tag.takeIf{it.isNotBlank()},"Favorite".takeIf{p.favorite}).filterNotNull().joinToString(" · ").ifBlank{"Unmarked caller"}))
        if(p.notes.isEmpty()) local.addBlock(DialerUi.text(this,"No staff notes yet.")); p.notes.asReversed().forEach { n ->
            local.addBlock(DialerUi.text(this,DialerUi.date(n.time)+(if(n.callTime>0) " · Call ${DialerUi.date(n.callTime)}" else ""),12f,true),2); local.addBlock(DialerUi.text(this,n.text),3)
            local.addBlock(DialerUi.button(this,"Edit or remove note") { editNote(n) })
        }
    }
    private fun editNote(n:DialerNotes.Note){val input=android.widget.EditText(this).apply{setText(n.text);minLines=3}; fun change(remove:Boolean){runCatching{val p=DialerNotes.profile(this,phone); val updated=p.notes.mapNotNull{if(it.id!=n.id) it else if(remove) null else it.copy(text=input.text.toString().trim().take(4000))}; DialerNotes.save(this,phone,p.copy(notes=updated)); renderLocal()}.onFailure{DialerUi.toast(this,"Note update failed")}}
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Staff note").setView(input).setNegativeButton("Cancel",null).setNeutralButton("Delete"){_,_-> androidx.appcompat.app.AlertDialog.Builder(this).setMessage("Delete this note?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->change(true)}.show()}.setPositiveButton("Save"){_,_->change(false)}.show()
    }
    private fun loadHistory(){ val r=++historySerial; history.removeAllViews(); history.addBlock(DialerUi.text(this,"Loading history…")); val c=applicationContext
        Thread{val result=runCatching{DialerData.logs(c,phone,500)}; runOnUiThread{if(r!=historySerial || isFinishing || isDestroyed)return@runOnUiThread; history.removeAllViews(); if(!DialerData.allowed(this,android.Manifest.permission.READ_CALL_LOG)){history.addBlock(DialerUi.text(this,"Call log permission required"));return@runOnUiThread}; val entries=result.getOrNull(); if(entries==null){history.addBlock(DialerUi.text(this,"History unavailable"));return@runOnUiThread}; if(entries.isEmpty()) history.addBlock(DialerUi.text(this,"No recorded calls")); val notes=runCatching { DialerNotes.profile(this,phone).notes }.getOrDefault(emptyList()); entries.forEach{l->val card=DialerUi.card(this);card.addBlock(DialerUi.text(this,l.typeLabel()+" · ${l.duration/60}m ${l.duration%60}s",16f,true),3);card.addBlock(DialerUi.text(this,DialerUi.date(l.date)),3);notes.filter{it.callTime>0 && kotlin.math.abs(it.callTime-l.date)<2000}.forEach{card.addBlock(DialerUi.text(this,it.text))};card.addBlock(DialerUi.button(this,"Add note to this call"){edit(l.date)},0);history.addBlock(card)} }}.start()
    }
    private fun loadPos(){val r=++serial;pos.removeAllViews();pos.addBlock(DialerUi.text(this,"Finding saved customer…",15f,true)); val number=DialerIdentity.posNumber(phone); if(number==null){pos.addBlock(DialerUi.text(this,"POS lookup is available for Indian mobile numbers."));return};val c=applicationContext
        Thread{ val cached=runCatching{OfflineCache.find(c,number)}.getOrNull(); runOnUiThread{if(r==serial && !isFinishing && !isDestroyed){if(cached!=null)renderPos(cached.payload,"OFFLINE · ${DialerUi.date(cached.timestamp)}\nChecking live POS…") else {pos.removeAllViews();pos.addBlock(DialerUi.text(this,"Checking live POS…"))}}}; val result=ApiClient.lookup(c,number); val root=result.json; val valid=result.ok && root!=null && root.has("found") && root.optInt("store_id",3)==3; if(valid && root!!.optBoolean("found")) runCatching{OfflineCache.remember(c,number,root)} else if(valid) runCatching{OfflineCache.forget(c,number)}
            runOnUiThread{if(r!=serial || isFinishing || isDestroyed)return@runOnUiThread; when{valid && root!!.optBoolean("found")->renderPos(root,"LIVE POS · STORE 03");valid->{pos.removeAllViews();pos.addBlock(DialerUi.text(this,"No matching Store 3 customer"))};cached!=null->renderPos(cached.payload,"SAVED OFFLINE · ${DialerUi.date(cached.timestamp)}\nLive POS unavailable");else->{pos.removeAllViews();pos.addBlock(DialerUi.text(this,"No saved match. ${result.error ?: "Live POS unavailable"}"))}} }
        }.start()
    }
    private fun renderPos(data:JSONObject,source:String){pos.removeAllViews();pos.addBlock(DialerUi.text(this,source,12f,true));pos.addBlock(DialerUi.text(this,CustomerPresentation.name(data),20f,true));pos.addBlock(DialerUi.text(this,CustomerPresentation.summary(data)));val name=runCatching{DialerNotes.profile(this,phone).name}.getOrDefault("");title.text=name.ifBlank{CustomerPresentation.name(data)}
        fun link(label:String,uri:Uri?){if(uri!=null)pos.addBlock(DialerUi.button(this,label){runCatching{startActivity(Intent(Intent.ACTION_VIEW,uri))}.onFailure{DialerUi.toast(this,"No browser available")}})}
        link("Customer in POS",CustomerPresentation.trustedPosUrl(data.optJSONObject("customer")?.optString("url").orEmpty()));link("Latest invoice",CustomerPresentation.trustedPosUrl(data.optString("latest_invoice_url")));link("Alteration tracker",CustomerPresentation.trackerUrl(CustomerPresentation.latestTicket(data)));pos.alpha=.7f;pos.animate().alpha(1f).setDuration(240).start()
    }
}
