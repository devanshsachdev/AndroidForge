package com.maahee.callerid

import android.Manifest
import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.net.Uri
import android.media.MediaMetadataRetriever
import java.util.UUID
import android.telecom.Call
import java.io.File

/** System-authorized telephony audio only. No microphone fallback or accessibility workaround. */
object CallRecorder {
    private var recorder:MediaRecorder?=null
    private var owner:Call?=null
    private var pending:File?=null
    private var destination:File?=null
    private var sessionContext:Context?=null
    private val attempted = mutableSetOf<Call>()
    private const val SETTINGS = "maahee_recording_settings"
    fun autoEnabled(c:Context) = c.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).getBoolean("auto_record",false)
    fun setAuto(c:Context,enabled:Boolean) { c.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).edit().putBoolean("auto_record",enabled).apply() }
    private fun savedFile(f:File)=f.isFile && f.extension in setOf("m4a","audio")
    fun allFiles(c:Context):List<File> = folder(c).listFiles()?.filter(::savedFile)?.sortedByDescending { it.lastModified() }.orEmpty()
    private fun outcome(c:Context,message:String) { c.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).edit().putString("last_result",message).putLong("last_result_at",System.currentTimeMillis()).apply() }
    fun diagnostic(c:Context):String {
        val prefs=c.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE)
        val last=prefs.getString("last_result",null)?.let { "\nLast recording event: $it · ${DialerUi.date(prefs.getLong("last_result_at",0L))}" }.orEmpty()
        return "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nSystem call audio: ${if(privileged(c)) "Granted" else "Not granted"}\nMicrophone permission: ${if(DialerData.allowed(c,Manifest.permission.RECORD_AUDIO)) "Granted" else "Not granted"}\nSaved recordings: ${allFiles(c).size}$last"
    }
    /** User-selected audio only, explicitly associated to a number; no scanning of other apps' files. */
    fun importAudio(c:Context,phone:String,uri:Uri):Boolean {
        if(!DialerIdentity.key(phone).matches(Regex("\\+?[0-9]{7,15}"))) return false
        val base=prefix(phone)+"_"+System.currentTimeMillis()+"_"+UUID.randomUUID().toString()
        val temp=File(folder(c),"$base.part"); val output=File(folder(c),"$base.audio")
        return try {
            val input=c.contentResolver.openInputStream(uri) ?: return false
            input.use { source -> temp.outputStream().use { dest ->
                val buffer=ByteArray(65536); var total=0L
                while(true) { val n=source.read(buffer); if(n<0) break; total+=n; require(total<=250L*1024*1024); dest.write(buffer,0,n) }
            } }
            val meta=MediaMetadataRetriever()
            try { meta.setDataSource(temp.absolutePath); require(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)=="yes"); require((meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)>0) } finally { runCatching { meta.release() } }
            temp.renameTo(output)
        } catch(e:Exception) { false } finally { if(temp.exists()) temp.delete() }
    }
    fun canRecordNumber(c:Context,phone:String):Boolean {
        if (!DialerIdentity.key(phone).matches(Regex("\\+?[0-9]{7,15}"))) return false
        return runCatching { c.getSystemService(android.telephony.TelephonyManager::class.java)?.isEmergencyNumber(phone)==false }.getOrDefault(false)
    }
    fun updateAuto(c:Context,calls:List<Call>,number:(Call)->String) {
        attempted.retainAll(calls.toSet())
        reconcile(calls)
        val call=calls.singleOrNull() ?: return
        if (!autoEnabled(c) || call.state!=Call.STATE_ACTIVE || recorder!=null || call in attempted) return
        if (!supported(c)) { attempted.add(call); outcome(c,"Automatic recording blocked: missing ${if(!privileged(c)) "system call audio access" else "microphone permission"}"); return }
        val phone=number(call)
        if (!canRecordNumber(c,phone)) return
        attempted.add(call)
        if (!start(c,call,phone)) DialerUi.toast(c,"Automatic call recording could not start")
    }
    fun privileged(c:Context)=DialerData.allowed(c,"android.permission.CAPTURE_AUDIO_OUTPUT")
    fun supported(c:Context)=privileged(c)&&DialerData.allowed(c,Manifest.permission.RECORD_AUDIO)
    fun status(c:Context)=when{!privileged(c)->"Unavailable on this installation: Android restricts cellular call audio to privileged system apps. The default dialer role and microphone permission cannot unlock it. You can import an existing recording from a customer profile.";!supported(c)->"System audio access available. Recording permission is required.";else->"Recording available for testing on this firmware. Automatic recording is optional; obtain consent before recording."}
    fun active(call:Call)=owner===call && recorder!=null
    private fun folder(c:Context)=File(c.filesDir,"call_recordings").apply{mkdirs()}
    private fun prefix(phone:String)=java.security.MessageDigest.getInstance("SHA-256").digest(DialerIdentity.key(phone).toByteArray()).joinToString(""){ "%02x".format(it.toInt() and 255) }
    fun files(c:Context,phone:String):List<File> = folder(c).listFiles()?.filter{it.name.startsWith(prefix(phone)+"_") && savedFile(it)}?.sortedByDescending{it.lastModified()}.orEmpty()
    @Suppress("DEPRECATION") fun start(c:Context,call:Call,phone:String):Boolean {
        if(!supported(c)) { outcome(c,"Recording blocked: required audio access missing"); return false }
        if(recorder!=null||call.state!=Call.STATE_ACTIVE||!canRecordNumber(c,phone))return false
        attempted.add(call)
        val base=prefix(phone)+"_"+System.currentTimeMillis();val temp=File(folder(c),"$base.part");val output=File(folder(c),"$base.m4a")
        var m:MediaRecorder?=null
        return try{val instance=if(Build.VERSION.SDK_INT>=31)MediaRecorder(c)else MediaRecorder();m=instance;instance.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);instance.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);instance.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);instance.setOutputFile(temp.absolutePath);instance.prepare();instance.start();recorder=instance;owner=call;pending=temp;destination=output;sessionContext=c.applicationContext;outcome(c,"Recording started");true}catch(e:Exception){runCatching{m?.release()};temp.delete();outcome(c,"Recording could not start (${e.javaClass.simpleName})");false}
    }
    fun stop():Boolean {val r=recorder?:return false;val temp=pending;val output=destination;recorder=null;owner=null;pending=null;destination=null;val ok=runCatching{r.stop()}.isSuccess;runCatching{r.release()};val saved=ok && temp!=null && output!=null && temp.length()>0 && temp.renameTo(output);if(!saved)temp?.delete();sessionContext?.let{outcome(it,if(saved)"Recording saved" else "Recording could not be saved")};sessionContext=null;return saved}
    fun reconcile(calls:List<Call>){val call=owner?:return;if(calls.size!=1 || call !in calls || call.state!=Call.STATE_ACTIVE)stop()}
}
