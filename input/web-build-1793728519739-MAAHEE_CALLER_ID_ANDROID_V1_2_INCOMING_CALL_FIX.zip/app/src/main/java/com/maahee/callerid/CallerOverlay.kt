package com.maahee.callerid

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

object CallerOverlay {
    private var currentView: View? = null
    private var wm: WindowManager? = null
    private val main = Handler(Looper.getMainLooper())

    fun showAndLookup(context: Context, rawPhone: String) {
        val appContext = context.applicationContext
        val masked = CallDiagnostics.mask(rawPhone)
        if (!Settings.canDrawOverlays(appContext)) {
            CallDiagnostics.event(appContext, "Popup permission missing")
            if (Prefs.backupNotification(appContext)) CallNotification.show(appContext, masked)
            return
        }
        main.post {
            try {
                remove()
                val manager = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val v = LayoutInflater.from(appContext).inflate(R.layout.caller_overlay, null)
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = 90
                }
                var downY = 0f
                var startY = 0
                v.setOnTouchListener { _, e ->
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downY = e.rawY
                            startY = params.y
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params.y = startY + (e.rawY - downY).toInt()
                            runCatching { manager.updateViewLayout(v, params) }
                            true
                        }
                        else -> false
                    }
                }
                v.findViewById<TextView>(R.id.phone).text = rawPhone
                v.findViewById<TextView>(R.id.close).setOnClickListener { remove() }
                manager.addView(v, params)
                wm = manager
                currentView = v
                CallDiagnostics.event(appContext, "Overlay view added successfully")
                if (Prefs.backupNotification(appContext)) CallNotification.show(appContext, masked)
                Thread {
                    val result = ApiClient.lookup(appContext, rawPhone)
                    main.post { update(appContext, v, result) }
                }.start()
                main.postDelayed({ if (currentView === v) remove() }, 45000)
            } catch (error: Exception) {
                CallDiagnostics.event(appContext, "Overlay could not open (${error.javaClass.simpleName})")
                if (Prefs.backupNotification(appContext)) CallNotification.show(appContext, masked)
            }
        }
    }

    private fun update(context:Context, v:View, result:ApiClient.Result){
        if (currentView !== v) return
        v.findViewById<ProgressBar>(R.id.progress).visibility = View.GONE
        val title=v.findViewById<TextView>(R.id.title)
        val body=v.findViewById<TextView>(R.id.body)
        if (!result.ok || result.json==null){
            title.text="Maahee Caller"
            body.text="POS lookup failed\n${result.error ?: "Unknown error"}"
            return
        }
        val root=result.json
        if (!root.optBoolean("found",false)){
            title.text="New / Unknown Caller"
            body.text="No Store 3 customer or recent sale found in Maahee POS."
            return
        }
        val customer=root.optJSONObject("customer") ?: JSONObject()
        title.text=customer.optString("name","Maahee Customer")
        val sales=root.optJSONArray("recent_sales")
        val sb=StringBuilder()
        if (sales==null || sales.length()==0) sb.append("Customer found • No Store 3 sales")
        else {
            for(i in 0 until sales.length()){
                val s=sales.getJSONObject(i)
                if(i>0) sb.append("\n\n")
                sb.append(i+1).append(". ").append(s.optString("date_display",s.optString("date")))
                sb.append("  •  ").append(s.optString("invoice_no","#"+s.optInt("sale_id")))
                sb.append("\n₹").append(String.format(Locale.US,"%.2f",s.optDouble("grand_total",0.0)))
                val bal=s.optDouble("balance",0.0)
                sb.append(if(bal>0.005) "  • Balance ₹${String.format(Locale.US,"%.2f",bal)}" else "  • PAID")
                val a=s.optJSONObject("alteration")
                if(a!=null && a.optBoolean("has_alteration",false)){
                    sb.append("\n✂ ").append(a.optString("ticket_no","Alteration"))
                    sb.append(" • ").append(a.optString("status","Pending"))
                    val due=a.optString("delivery_date_display","")
                    if(due.isNotBlank()) sb.append(" • ").append(due)
                }
            }
        }
        body.text=sb.toString()
        val customerUrl=customer.optString("url","")
        val latest=root.optString("latest_invoice_url","")
        val tracker=root.optString("tracker_url","")
        bindButton(context,v.findViewById(R.id.openCustomer),customerUrl)
        bindButton(context,v.findViewById(R.id.openInvoice),latest)
        bindButton(context,v.findViewById(R.id.openTracker),tracker)
    }

    private fun bindButton(context:Context, button:Button, url:String){
        if(url.isBlank()) return
        button.visibility=View.VISIBLE
        button.setOnClickListener{
            val i=Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching{context.startActivity(i)}
        }
    }

    fun remove(){
        val v=currentView ?: return
        runCatching{wm?.removeView(v)}
        currentView=null
    }
}
