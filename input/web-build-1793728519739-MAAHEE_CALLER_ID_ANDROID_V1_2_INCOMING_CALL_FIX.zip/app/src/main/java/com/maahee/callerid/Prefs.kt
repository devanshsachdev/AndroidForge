package com.maahee.callerid

import android.content.Context

object Prefs {
    private const val FILE = "maahee_caller"
    fun apiUrl(c: Context) = c.getSharedPreferences(FILE,0).getString("api_url", BuildConfig.DEFAULT_API_URL) ?: BuildConfig.DEFAULT_API_URL
    fun token(c: Context) = c.getSharedPreferences(FILE,0).getString("token", BuildConfig.DEFAULT_API_TOKEN) ?: BuildConfig.DEFAULT_API_TOKEN
    fun backupNotification(c: Context) = c.getSharedPreferences(FILE,0).getBoolean("backup_call_notification", false)
    fun saveBackupNotification(c: Context, enabled: Boolean) = c.getSharedPreferences(FILE,0).edit().putBoolean("backup_call_notification", enabled).apply()
    fun save(c: Context, url:String, token:String) = c.getSharedPreferences(FILE,0).edit().putString("api_url",url.trim()).putString("token",token.trim()).apply()
}
