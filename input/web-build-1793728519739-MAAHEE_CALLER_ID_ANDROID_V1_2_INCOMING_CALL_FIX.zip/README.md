# Maahee Caller ID V1.2 — incoming call diagnosis + Samsung fallback

Native Kotlin Android 10+ caller lookup, existing app ID `com.maahee.callerid`.
Version code 2, so install over V1.1 without clearing app data; existing API settings/token are preserved.

## What changed from V1.1
- A dedicated **Last incoming callback** timestamp. If it never changes after a real cellular call, the system did not invoke the screening service.
- A second diagnostic line tells whether the overlay was queued/added or failed. Logs are stored locally only and show only the final 4 digits of a caller number.
- On an incoming call, enqueues the popup **before the short-lived call-screening service finishes responding**, without waiting for network requests. Calls always remain allowed and response is immediate.
- Added optional **READ_CONTACTS** permission: Android can also send calls from saved contact numbers when this permission is granted. The app does not read or upload the address book. Only the incoming number is used for POS lookup.
- Added optional notification backup (`POST_NOTIFICATIONS` on Android 13+). Turn on **Show call notification as popup backup**. Samsung may put the dialer above third-party overlay windows; notifications can help but are not guaranteed to appear over the call UI.
- Better error diagnostics if `WindowManager.addView` fails.
- Existing working manual POS lookup remains unchanged.

## Install / use
1. Build this Android ZIP in AndroidForge; do NOT upload the PHP API ZIP.
2. Install V1.2 **over the current app**, retaining app storage. Do not uninstall or clear storage; that would remove your saved token.
3. Open Maahee Caller ID and verify Call Screening=ENABLED and Display over apps=ALLOWED.
4. Tap **Allow Saved Contacts** only if you want saved numbers to trigger; this requests Android Contacts permission.
5. Optionally allow backup notifications, then check **Show call notification as popup backup**.
6. On Samsung Settings > Apps > Maahee Caller ID > Battery, choose **Unrestricted** if available. Also confirm **Caller ID & spam app / Call screening** defaults to Maahee where the setting exists. Settings labels vary by model.
7. Make a REAL incoming cellular call (not WhatsApp) from an unsaved phone number with the Samsung screen unlocked.
8. Return to the app and tap **Refresh Incoming Call Diagnostics**.
   - "No incoming call callback recorded yet" = Android did not invoke the screening service; check role, default caller ID app, saved contacts, Samsung/carrier limitations.
   - "Incoming call callback received" but no "Overlay view added successfully" = popup permission or OS window restriction; use optional notification backup.
   - "Overlay view added successfully" but visually nothing during ringing = the phone's system call screen is covering third-party overlays. This is a platform restriction; use notification backup and do not expect an overlay to appear over every device's dialer.

## Server
No POS API changes. Uses `https://pos.maahee.co.in/api/caller/lookup` with bearer token configured through the app. Token is intentionally NOT embedded in ZIP. Do not publish your POS token.

## Security and Android limitations
- Does not ask for READ_CALL_LOG, does not block/reject calls, and does not start an always-on service.
- Android's CallScreeningService receives only eligible regular phone calls. Saved contacts need explicit READ_CONTACTS permission; hidden/withheld numbers, some devices/phone accounts and third-party voice calls may not trigger.
- TYPE_APPLICATION_OVERLAY is drawn above normal apps but underneath system/critical UI. Samsung can hide it while the phone screen is active. A notification backup does not bypass that restriction.
- Diagnostic history is local only and contains no complete phone numbers.

## Build
Gradle project files (`settings.gradle.kts`, `build.gradle.kts`, `app/`) are at ZIP root. Requires Android SDK 35, Gradle 8.9, Java 17, Google Maven repositories.
