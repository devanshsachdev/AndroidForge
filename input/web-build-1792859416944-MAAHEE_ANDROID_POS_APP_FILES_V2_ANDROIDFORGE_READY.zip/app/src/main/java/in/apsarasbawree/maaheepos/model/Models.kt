package in.apsarasbawree.maaheepos.model

data class DashboardTile(val title: String, val subtitle: String, val route: String)
data class TrackerOrder(val invoice: String, val customer: String, val status: String, val delivery: String, val pieces: Int)
data class PurchaseDraft(val supplier: String = "", val invoice: String = "", val items: Int = 0, val total: Double = 0.0)
data class BarcodeBatch(val title: String, val labels: Int, val size: String = "48 × 30 mm")
