package in.apsarasbawree.maaheepos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import in.apsarasbawree.maaheepos.model.*
import in.apsarasbawree.maaheepos.ui.theme.MaaheeTheme

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaaheeTheme { MaaheeApp() } }
    }
}

@Composable
fun MaaheeApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("pos") { ModuleScreen("Native POS", listOf("Scan/Search product", "Customer + loyalty", "Cart", "Discount", "Split payment", "Credit Note", "Tailoring", "Checkout")) }
        composable("sales") { ModuleScreen("Sales", listOf("Sales history", "Invoice view", "Add payment", "Credit Note reversal", "PDF / WhatsApp share")) }
        composable("tracker") { TrackerScreen() }
        composable("purchases") { PurchasesScreen(nav) }
        composable("barcodes") { BarcodeScreen() }
        composable("customers") { ModuleScreen("Customers", listOf("Search/Add customer", "Address", "Ledger", "Rewards", "Pending invoices")) }
        composable("credit_notes") { ModuleScreen("Credit Notes", listOf("Scan/Lookup", "Partial redemption", "Balance", "Ledger", "Admin reversal")) }
        composable("reports") { ModuleScreen("Reports", listOf("Supplier performance", "Buying intelligence", "Size sell-through", "Dead stock", "Reorder", "Margin leakage")) }
        composable("settings") { ModuleScreen("Settings", listOf("API connection", "Store", "Printer", "Staff permissions", "Barcode defaults")) }
    }
}

@Composable
private fun HomeScreen(nav: NavHostController) {
    val tiles = listOf(
        DashboardTile("POS", "Billing & checkout", "pos"),
        DashboardTile("Sales", "Invoices & payments", "sales"),
        DashboardTile("Tailoring Tracker", "Pending → Delivered", "tracker"),
        DashboardTile("Purchases", "Fast stock receiving", "purchases"),
        DashboardTile("Barcode Center", "48×30 labels / PDF / print", "barcodes"),
        DashboardTile("Customers", "Ledger & rewards", "customers"),
        DashboardTile("Credit Notes", "Redeem & ledger", "credit_notes"),
        DashboardTile("Reports", "Business intelligence", "reports"),
        DashboardTile("Settings", "Store & devices", "settings")
    )
    Scaffold(topBar = { TopAppBar(title = { Text("Maahee POS", fontWeight = FontWeight.Bold) }) }) { pad ->
        LazyColumn(contentPadding = PaddingValues(16.dp), modifier = Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tiles) { tile ->
                Card(onClick = { nav.navigate(tile.route) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text(tile.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text(tile.subtitle, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackerScreen() {
    val columns = listOf("Pending", "Cutting", "Stitching", "Ready", "Delivered")
    var selected by remember { mutableStateOf("Pending") }
    val sample = listOf(
        TrackerOrder("261024-101", "Customer A", "Pending", "Today 6:00 PM", 2),
        TrackerOrder("261024-102", "Customer B", "Pending", "Tomorrow 1:00 PM", 1)
    )
    Scaffold(topBar = { TopAppBar(title = { Text("Tailoring Tracker") }) }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            ScrollableTabRow(selectedTabIndex = columns.indexOf(selected)) {
                columns.forEach { s -> Tab(selected = selected == s, onClick = { selected = s }, text = { Text(s) }) }
            }
            Spacer(Modifier.height(12.dp))
            if (selected == "Pending") sample.forEach { o ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("#${o.invoice} • ${o.customer}", fontWeight = FontWeight.Bold)
                        Text("${o.pieces} alteration pcs • ${o.delivery}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                            AssistChip(onClick = {}, label = { Text("Move to Cutting") })
                            AssistChip(onClick = {}, label = { Text("Open Invoice") })
                        }
                    }
                }
            } else Text("Native $selected tracker column — API wiring next.")
        }
    }
}

@Composable
private fun PurchasesScreen(nav: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Quick Purchase") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Supplier") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Supplier Invoice No.") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add / Scan Product") }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text("Fast tools", fontWeight = FontWeight.Bold); Text("Copy last row • Size presets • Image • GST • Cost • Price • Qty") } }
            Button(onClick = { nav.navigate("barcodes") }, modifier = Modifier.fillMaxWidth()) { Text("Save Purchase & Generate Barcodes") }
        }
    }
}

@Composable
private fun BarcodeScreen() {
    val batches = listOf(BarcodeBatch("Latest Purchase", 42), BarcodeBatch("Supplier Invoice #1251", 18))
    Scaffold(topBar = { TopAppBar(title = { Text("Barcode Center") }) }) { pad ->
        LazyColumn(modifier = Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                    Text("Barcode defaults", fontWeight = FontWeight.Bold)
                    Text("48 × 30 mm • Classic Box • Code128")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Button(onClick = {}) { Text("Export PDF") }
                        OutlinedButton(onClick = {}) { Text("Bluetooth Print") }
                    }
                }}
            }
            items(batches) { b ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(b.title, fontWeight = FontWeight.Bold); Text("${b.labels} labels • ${b.size}") }
                    Icon(Icons.Default.QrCode2, contentDescription = null)
                }}
            }
        }
    }
}

@Composable
private fun ModuleScreen(title: String, items: List<String>) {
    Scaffold(topBar = { TopAppBar(title = { Text(title) }) }) { pad ->
        LazyColumn(modifier = Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { s -> Card(Modifier.fillMaxWidth()) { Text(s, Modifier.padding(16.dp), fontWeight = FontWeight.Medium) } }
        }
    }
}
