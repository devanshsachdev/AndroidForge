package com.maahee.callerid

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypted, app-private Store 3 directory.
 * One decrypted snapshot and one lightweight search index are reused per process,
 * so an incoming call does not repeatedly decrypt and parse the entire directory.
 * No contacts, call logs or search history are uploaded or saved here.
 */
object OfflineCache {
    data class Entry(val payload: JSONObject, val timestamp: Long)
    data class Stats(val count: Int, val lastSync: Long, val lastPartial: Long)
    data class Match(val phone: String, val name: String, val entry: Entry)
    private data class Indexed(val number: String, val name: String, val lowerName: String, val timestamp: Long)

    private const val KEY_ALIAS = "maahee_store3_directory_v14" // Keep same key/file for V1.6 upgrades.
    private const val FILE_NAME = "maahee_store3_directory.aes"
    private const val MAX_BYTES = 25 * 1024 * 1024
    private val lock = Any()
    private var loadedPath: String? = null
    private var snapshot: JSONObject? = null
    private var index: List<Indexed>? = null

    fun normalize(phone: String): String = PhoneNumbers.normalize(phone)

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun directory(context: Context) = File(context.filesDir, FILE_NAME)

    private fun readDisk(context: Context): JSONObject {
        val file = directory(context)
        if (!file.isFile || file.length() < 30 || file.length() > MAX_BYTES) return JSONObject()
        return try {
            val all = file.readBytes()
            if (all[0].toInt() != 1) return JSONObject()
            val nonce = all.copyOfRange(1, 13)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, nonce))
            val plain = cipher.doFinal(all.copyOfRange(13, all.size))
            JSONObject(String(plain, Charsets.UTF_8))
        } catch (_: Exception) {
            // Cannot recover a missing Keystore key; do not expose corrupted data.
            JSONObject()
        }
    }

    private fun read(context: Context): JSONObject {
        val path = directory(context).absolutePath
        if (loadedPath != path || snapshot == null) {
            snapshot = readDisk(context)
            loadedPath = path
            index = null
        }
        return snapshot!!
    }

    private fun write(context: Context, container: JSONObject) {
        val bytes = container.toString().toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_BYTES - 128) { "Offline directory exceeds encrypted cache limit" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(bytes)
        val target = directory(context)
        val tmp = File(context.filesDir, "$FILE_NAME.tmp")
        try {
            FileOutputStream(tmp).use { output ->
                output.write(byteArrayOf(1))
                output.write(cipher.iv)
                output.write(encrypted)
                output.fd.sync()
            }
            if (!tmp.renameTo(target)) throw IllegalStateException("Could not replace encrypted offline file")
            snapshot = container
            loadedPath = target.absolutePath
            index = null
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    fun find(context: Context, phone: String): Entry? = synchronized(lock) {
        val normalized = normalize(phone)
        if (normalized.isEmpty()) return@synchronized null
        val record = read(context).optJSONObject("records")?.optJSONObject(normalized)
            ?: return@synchronized null
        val payload = record.optJSONObject("payload") ?: return@synchronized null
        Entry(JSONObject(payload.toString()), record.optLong("timestamp", 0L))
    }

    /**
     * Searches already-synced numbers AND customer names offline. Search is called
     * on a worker thread; only the first [limit] matches are materialized.
     */
    fun search(context: Context, query: String, limit: Int = 30): List<Match> = synchronized(lock) {
        val input = query.trim()
        if (input.length < 2) return@synchronized emptyList()
        val records = read(context).optJSONObject("records") ?: return@synchronized emptyList()
        val digits = PhoneNumbers.digits(input)
        val byNumber = digits.length >= 2 && input.any { Character.digit(it, 10) >= 0 }
        val needle = input.lowercase(Locale.ROOT)
        if (index == null) {
            val entries = ArrayList<Indexed>(records.length())
            val keys = records.keys()
            while (keys.hasNext()) {
                val number = keys.next()
                val record = records.optJSONObject(number) ?: continue
                val payload = record.optJSONObject("payload") ?: continue
                val name = payload.optJSONObject("customer")?.optString("name", "")?.trim().orEmpty()
                entries.add(Indexed(number, name, name.lowercase(Locale.ROOT), record.optLong("timestamp", 0L)))
            }
            index = entries
        }
        val matches = ArrayList<Pair<Int, Indexed>>()
        for (item in index.orEmpty()) {
            val score = if (byNumber) when {
                item.number == normalize(input) && digits.length >= 10 -> 0
                item.number.startsWith(digits) -> 1
                item.number.contains(digits) -> 2
                else -> -1
            } else when {
                item.lowerName == needle -> 0
                item.lowerName.startsWith(needle) -> 1
                item.lowerName.contains(needle) -> 2
                else -> -1
            }
            if (score >= 0) matches.add(score to item)
        }
        matches.sortWith(compareBy<Pair<Int, Indexed>> { it.first }
            .thenBy { it.second.name.lowercase(Locale.ROOT) }
            .thenBy { it.second.number })
        matches.take(limit.coerceIn(1, 100)).mapNotNull { (_, item) ->
            val stored = records.optJSONObject(item.number) ?: return@mapNotNull null
            val payload = stored.optJSONObject("payload") ?: return@mapNotNull null
            Match(item.number, item.name.ifBlank { "Maahee customer" },
                Entry(JSONObject(payload.toString()), item.timestamp))
        }
    }

    fun remember(context: Context, phone: String, payload: JSONObject) = synchronized(lock) {
        val number = normalize(phone)
        if (number.isEmpty() || !payload.optBoolean("found", false) ||
            payload.optInt("store_id", 3) != 3) return@synchronized
        val root = JSONObject(read(context).toString())
        val records = root.optJSONObject("records") ?: JSONObject()
        records.put(number, JSONObject()
            .put("timestamp", System.currentTimeMillis())
            .put("payload", payload))
        root.put("records", records)
        write(context, root)
    }

    fun forget(context: Context, phone: String) = synchronized(lock) {
        val number = normalize(phone)
        if (number.isEmpty()) return@synchronized
        val root = JSONObject(read(context).toString())
        val records = root.optJSONObject("records") ?: return@synchronized
        if (records.has(number)) {
            records.remove(number)
            write(context, root)
        }
    }

    /**
     * Failed syncs keep existing full-directory entries intact. Partial pages add
     * missing phones, while the complete new snapshot replaces all data atomically.
     */
    fun mergePartialDirectory(context: Context, downloaded: JSONObject) = synchronized(lock) {
        if (downloaded.length() == 0) return@synchronized
        val root = JSONObject(read(context).toString())
        val records = root.optJSONObject("records") ?: JSONObject()
        val hasFullSnapshot = root.optLong("last_full_sync", 0L) > 0L
        val keys = downloaded.keys()
        while (keys.hasNext()) {
            val number = keys.next()
            if (normalize(number) != number) continue
            val entry = downloaded.optJSONObject(number) ?: continue
            if (!hasFullSnapshot || !records.has(number)) records.put(number, entry)
        }
        root.put("records", records)
        root.put("last_partial_sync", System.currentTimeMillis())
        write(context, root)
    }

    fun replaceDirectory(context: Context, newRecords: JSONObject) = synchronized(lock) {
        val now = System.currentTimeMillis()
        write(context, JSONObject().put("records", newRecords).put("last_full_sync", now))
    }

    fun stats(context: Context): Stats = synchronized(lock) {
        val root = read(context)
        Stats(root.optJSONObject("records")?.length() ?: 0,
            root.optLong("last_full_sync", 0L), root.optLong("last_partial_sync", 0L))
    }

    fun clear(context: Context) = synchronized(lock) {
        val file = directory(context)
        if (file.exists() && !file.delete()) throw IllegalStateException("Could not erase directory")
        snapshot = JSONObject()
        loadedPath = file.absolutePath
        index = null
    }
}
