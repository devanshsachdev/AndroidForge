package com.maahee.callerid

import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/** Shared safe formatting and POS-only navigation used by the dedicated lookup page. */
object CustomerPresentation {
    fun name(root: JSONObject): String =
        root.optJSONObject("customer")?.optString("name", "")?.trim()?.takeIf { it.isNotEmpty() }
            ?: "Maahee customer"

    fun summary(root: JSONObject): String {
        val sales = root.optJSONArray("recent_sales")
        val details = StringBuilder()
        if (sales == null || sales.length() == 0) {
            details.append("Customer found. No recent Store 3 sales available.")
        } else {
            for (i in 0 until sales.length()) {
                val sale = sales.optJSONObject(i) ?: continue
                if (details.isNotEmpty()) details.append("\n\n")
                details.append("PURCHASE ").append(i + 1).append("   ")
                    .append(sale.optString("date_display", sale.optString("date")))
                    .append("\n")
                    .append(sale.optString("invoice_no", "Invoice #${sale.optInt("sale_id")}"))
                    .append("   •   ₹")
                    .append(String.format(Locale.getDefault(), "%,.2f", sale.optDouble("grand_total", 0.0)))
                val balance = sale.optDouble("balance", 0.0)
                details.append(if (balance > 0.005) "\nBalance ₹${String.format(Locale.getDefault(), "%,.2f", balance)}" else "\nPaid")
                val alteration = sale.optJSONObject("alteration")
                if (alteration?.optBoolean("has_alteration", false) == true) {
                    details.append("\nAlteration: ")
                        .append(alteration.optString("ticket_no", "Ticket"))
                        .append("   •   ").append(alteration.optString("status", "Pending"))
                    alteration.optString("delivery_date_display", "").takeIf { it.isNotBlank() }
                        ?.let { details.append("\nDue ").append(it) }
                }
            }
        }
        val ticket = latestTicket(root)
        if (ticket.isNotBlank() && !details.contains(ticket)) {
            details.append("\n\nLatest alteration ticket: ").append(ticket)
        }
        return details.toString()
    }

    fun latestTicket(root: JSONObject): String {
        fun clean(value: String) = value.trim().takeIf { it.matches(Regex("[A-Za-z0-9_-]{2,32}")) } ?: ""
        clean(root.optString("latest_ticket_id", "")).takeIf { it.isNotEmpty() }?.let { return it }
        val sales = root.optJSONArray("recent_sales") ?: return ""
        for (i in 0 until sales.length()) {
            val alteration = sales.optJSONObject(i)?.optJSONObject("alteration") ?: continue
            clean(alteration.optString("ticket_no", "")).takeIf { it.isNotEmpty() }?.let { return it }
        }
        return ""
    }

    /** Never open arbitrary links sent in API JSON. */
    fun trustedPosUrl(raw: String): Uri? {
        return runCatching { Uri.parse(raw) }.getOrNull()?.takeIf {
            it.scheme == "https" && it.host.equals("pos.maahee.co.in", ignoreCase = true)
        }
    }

    fun trackerUrl(ticket: String): Uri? {
        if (ticket.isBlank() || !ticket.matches(Regex("[A-Za-z0-9_-]{2,32}"))) return null
        val zone = TimeZone.getTimeZone("Asia/Kolkata")
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = zone }
        val cal = Calendar.getInstance(zone)
        val end = formatter.format(cal.time)
        cal.add(Calendar.MONTH, -3)
        val start = formatter.format(cal.time)
        return Uri.Builder().scheme("https").authority("pos.maahee.co.in")
            .appendPath("tracker")
            .appendQueryParameter("start_date", start)
            .appendQueryParameter("end_date", end)
            .appendQueryParameter("search", ticket)
            .build()
    }
}
