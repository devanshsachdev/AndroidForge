package com.maahee.callerid

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/** Lightweight radar/pulse animation; no external library, images or network. */
class LookupPulseView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val brush = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accent = Color.rgb(166, 105, 121)
    private val gold = Color.rgb(211, 171, 119)
    private var phase = 0f
    private var animator: ValueAnimator? = null

    fun setSearching(searching: Boolean) {
        if (!searching) {
            animator?.cancel()
            animator = null
            phase = 0f
            visibility = GONE
            return
        }
        visibility = VISIBLE
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) * 0.42f
        for (i in 0..2) {
            val p = (phase + i / 3f) % 1f
            brush.style = Paint.Style.STROKE
            brush.strokeWidth = 2.5f * resources.displayMetrics.density
            brush.color = accent
            brush.alpha = ((1f - p) * 110).toInt().coerceIn(0, 255)
            canvas.drawCircle(cx, cy, radius * (0.22f + p * 0.77f), brush)
        }
        brush.style = Paint.Style.FILL
        brush.color = gold
        brush.alpha = 255
        canvas.drawCircle(cx, cy, radius * (0.17f + 0.02f * phase), brush)
        brush.color = Color.WHITE
        canvas.drawCircle(cx, cy, radius * 0.065f, brush)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }
}
