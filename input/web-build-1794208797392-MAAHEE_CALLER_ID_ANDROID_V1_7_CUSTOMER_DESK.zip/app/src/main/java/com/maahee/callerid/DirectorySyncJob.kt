package com.maahee.callerid

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/** Daily Wi-Fi automatic update. Android decides the actual execution time. */
class DirectorySyncJob : JobService() {
    @Volatile private var stopped = false
    @Volatile private var worker: Thread? = null

    override fun onStartJob(params: JobParameters): Boolean {
        stopped = false
        worker = Thread {
            val outcome = DirectorySync.sync(applicationContext) { }
            if (!stopped) {
                CallDiagnostics.event(applicationContext,
                    if (outcome.ok) "Offline directory synced: ${outcome.count} numbers"
                    else "Offline directory sync failed: ${outcome.message.take(100)}")
                jobFinished(params, !outcome.ok)
            }
        }.apply { name = "MaaheeHourlySync"; start() }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        stopped = true
        worker?.interrupt()
        return true
    }

    companion object {
        private const val ID = 463820
        private const val HOUR = 60L * 60L * 1000L
        fun schedule(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            // Do not reset the clock every time the user opens the app.
            if (scheduler.getPendingJob(ID)?.intervalMillis == HOUR) return
            val job = JobInfo.Builder(ID, ComponentName(context, DirectorySyncJob::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(HOUR, 15L * 60L * 1000L)
                .setPersisted(true)
                .build()
            scheduler.schedule(job)
        }
        fun cancel(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            scheduler.cancel(ID)
        }
    }
}
