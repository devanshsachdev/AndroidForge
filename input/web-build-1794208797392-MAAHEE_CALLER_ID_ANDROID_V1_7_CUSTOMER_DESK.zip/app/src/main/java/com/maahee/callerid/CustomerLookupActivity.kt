package com.maahee.callerid

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Real customer lookup, separate from incoming-call testing. */
class CustomerLookupActivity : AppCompatActivity() {
    companion object { const val EXTRA_PHONE = "com.maahee.callerid.lookup.PHONE" }

    @Volatile private var requestSerial = 0
    private lateinit var queryInput: EditText
    private lateinit var feedback: TextView
    private lateinit var pulse: LookupPulseView
    private lateinit var scanPanel: View
    private lateinit var scanStage: TextView
    private lateinit var resultPanel: View
    private lateinit var matchesPanel: View
    private lateinit var matchesList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_lookup)
        queryInput = findViewById(R.id.lookupQuery)
        feedback = findViewById(R.id.lookupFeedback)
        pulse = findViewById(R.id.lookupPulse)
        scanPanel = findViewById(R.id.searchProgressPanel)
        scanStage = findViewById(R.id.lookupStage)
        resultPanel = findViewById(R.id.customerResult)
        matchesPanel = findViewById(R.id.matchesPanel)
        matchesList = findViewById(R.id.matchesList)

        findViewById<TextView>(R.id.lookupBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.lookupSearch).setOnClickListener { search() }
        queryInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                search()
                true
            } else false
        }

        val initial = savedInstanceState?.getString("lookup_text")
            ?: intent.getStringExtra(EXTRA_PHONE).orEmpty()
        if (initial.isNotBlank()) {
            queryInput.setText(initial)
            if (savedInstanceState == null) search()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("lookup_text", queryInput.text.toString())
        super.onSaveInstanceState(outState)
    }

    private fun search() {
        val term = queryInput.text.toString().trim()
        if (term.length < 2) {
            feedback.text = "Enter at least 2 letters or digits."
            queryInput.requestFocus()
            return
        }
        val serial = ++requestSerial
        resultPanel.visibility = View.GONE
        matchesPanel.visibility = View.GONE
        setScanning(true, "Finding saved customers…")
        feedback.text = "Searching the encrypted Store 3 directory on this device…"
        val app = applicationContext
        Thread {
            val matches = runCatching { OfflineCache.search(app, term, 30) }.getOrElse { emptyList() }
            val phone = OfflineCache.normalize(term)
            val fullNumber = phone.isNotBlank() && PhoneNumbers.hasFullNumber(term)
            val exact = if (fullNumber) runCatching { OfflineCache.find(app, phone) }.getOrNull() else null
            val localName = if (fullNumber) LocalContacts.name(app, term) else null
            runOnUiThread {
                if (!current(serial)) return@runOnUiThread
                showMatches(matches, fullNumber)
                if (exact != null) {
                    showCustomer(phone, exact.payload, true, exact.timestamp)
                    feedback.text = "Saved customer found instantly • checking for live POS changes…"
                } else if (fullNumber && !localName.isNullOrBlank()) {
                    showContactOnly(phone, localName)
                    feedback.text = "Saved phone contact found • looking for Store 3 history…"
                } else if (!fullNumber) {
                    setScanning(false)
                    feedback.text = if (matches.isEmpty())
                        "No saved matches. Try a different name or sync the Store 3 directory."
                    else "${matches.size}${if (matches.size == 30) "+" else ""} saved match(es). Tap a customer to view details."
                    if (matches.size == 1) {
                        val one = matches.first()
                        showCustomer(one.phone, one.entry.payload, true, one.entry.timestamp)
                    }
                }
                if (fullNumber) liveLookup(phone, serial, exact != null, localName)
            }
        }.apply { name = "MaaheeCustomerOfflineSearch"; start() }
    }

    private fun liveLookup(phone: String, serial: Int, hadCached: Boolean, localContact: String?) {
        if (!current(serial)) return
        setScanning(true, "Checking the live POS…")
        Thread {
            val result = ApiClient.lookupWithRetry(applicationContext, phone,
                { current(serial) },
                { attempt, max, _ ->
                    runOnUiThread {
                        if (current(serial)) scanStage.text = "POS connection • attempt $attempt of $max"
                    }
                }
            )
            if (!current(serial)) return@Thread
            val root = result.json
            val valid = result.ok && root != null && root.has("found") &&
                root.optInt("store_id", 3) == 3
            if (valid && root!!.optBoolean("found", false)) {
                runCatching { OfflineCache.remember(applicationContext, phone, root) }
            } else if (valid && !root!!.optBoolean("found", false)) {
                runCatching { OfflineCache.forget(applicationContext, phone) }
            }
            runOnUiThread {
                if (!current(serial)) return@runOnUiThread
                setScanning(false)
                when {
                    valid && root!!.optBoolean("found", false) -> {
                        showCustomer(phone, root, false, System.currentTimeMillis())
                        feedback.text = "Customer verified with the live POS • saved for offline calls."
                    }
                    valid -> {
                        if (!localContact.isNullOrBlank()) showContactOnly(phone, localContact)
                        else resultPanel.visibility = View.GONE
                        feedback.text = "No matching Store 3 customer. This number can still be saved in your phone's contacts."
                    }
                    hadCached -> {
                        feedback.text = "POS unavailable • showing the saved offline customer. ${result.error.orEmpty().take(120)}"
                    }
                    !localContact.isNullOrBlank() -> {
                        showContactOnly(phone, localContact)
                        feedback.text = "POS unavailable • saved phone contact shown. ${result.error.orEmpty().take(120)}"
                    }
                    else -> feedback.text = "No saved match. Live POS unavailable: ${result.error ?: "Unexpected response"}"
                }
            }
        }.apply { name = "MaaheeCustomerLiveLookup"; start() }
    }

    private fun showMatches(matches: List<OfflineCache.Match>, fullNumber: Boolean) {
        matchesList.removeAllViews()
        if (matches.isEmpty() || (fullNumber && matches.size == 1)) {
            matchesPanel.visibility = View.GONE
            return
        }
        matchesPanel.visibility = View.VISIBLE
        findViewById<TextView>(R.id.matchesTitle).text =
            "Saved matches (${matches.size}${if (matches.size == 30) "+" else ""})"
        for (match in matches) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(17), dp(13), dp(17), dp(13))
                setBackgroundResource(R.drawable.bg_surface)
                isClickable = true
                isFocusable = true
                contentDescription = "Open ${match.name}, ${match.phone}"
            }
            item.addView(TextView(this).apply {
                text = match.name
                textSize = 15f
                setTextColor(getColor(R.color.maahee_ink))
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            item.addView(TextView(this).apply {
                text = match.phone + "   •   SAVED OFFLINE"
                textSize = 12f
                setTextColor(getColor(R.color.maahee_muted))
            })
            item.setOnClickListener {
                showCustomer(match.phone, match.entry.payload, true, match.entry.timestamp)
                feedback.text = "Showing ${match.name} from the offline directory."
            }
            matchesList.addView(item, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(9) })
        }
        matchesPanel.alpha = 0f
        matchesPanel.animate().alpha(1f).setDuration(260L).start()
    }

    private fun showCustomer(phone: String, root: JSONObject, offline: Boolean, timestamp: Long) {
        resultPanel.visibility = View.VISIBLE
        findViewById<TextView>(R.id.customerSource).text =
            if (offline) "SAVED OFFLINE" else "LIVE POS • STORE 03"
        findViewById<TextView>(R.id.customerName).text = CustomerPresentation.name(root)
        findViewById<TextView>(R.id.customerPhone).text = phone
        val notice = if (offline) {
            val whenSaved = if (timestamp > 0L)
                SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date(timestamp))
            else "earlier sync"
            "Offline copy from $whenSaved\nMay be outdated until refreshed.\n\n"
        } else ""
        findViewById<TextView>(R.id.customerSummary).text = notice + CustomerPresentation.summary(root)
        bindUrl(R.id.customerPos, CustomerPresentation.trustedPosUrl(
            root.optJSONObject("customer")?.optString("url", "").orEmpty()))
        bindUrl(R.id.invoicePos, CustomerPresentation.trustedPosUrl(root.optString("latest_invoice_url", "")))
        bindUrl(R.id.trackerPos, CustomerPresentation.trackerUrl(CustomerPresentation.latestTicket(root)))
        val refresh = findViewById<Button>(R.id.lookupRefresh)
        refresh.visibility = View.VISIBLE
        refresh.setOnClickListener {
            val serial = ++requestSerial
            liveLookup(phone, serial, true, null)
        }
        revealResult()
    }

    private fun showContactOnly(phone: String, name: String) {
        resultPanel.visibility = View.VISIBLE
        findViewById<TextView>(R.id.customerSource).text = "PHONE CONTACT • NOT POS VERIFIED"
        findViewById<TextView>(R.id.customerName).text = name
        findViewById<TextView>(R.id.customerPhone).text = phone
        findViewById<TextView>(R.id.customerSummary).text =
            "This name is saved on this phone. No Store 3 purchase details are available in the offline directory."
        bindUrl(R.id.customerPos, null)
        bindUrl(R.id.invoicePos, null)
        bindUrl(R.id.trackerPos, null)
        findViewById<Button>(R.id.lookupRefresh).apply {
            visibility = View.VISIBLE
            setOnClickListener {
                val serial = ++requestSerial
                liveLookup(phone, serial, false, name)
            }
        }
        revealResult()
    }

    private fun bindUrl(buttonId: Int, uri: Uri?) {
        findViewById<Button>(buttonId).apply {
            visibility = if (uri == null) View.GONE else View.VISIBLE
            setOnClickListener {
                if (uri != null) try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                    Toast.makeText(this@CustomerLookupActivity, "Unable to open POS link", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setScanning(active: Boolean, label: String = "") {
        scanPanel.visibility = if (active) View.VISIBLE else View.GONE
        pulse.setSearching(active)
        if (active) scanStage.text = label
    }

    private fun revealResult() {
        resultPanel.alpha = 0f
        resultPanel.translationY = dp(12).toFloat()
        resultPanel.animate().alpha(1f).translationY(0f).setDuration(280L).start()
    }

    private fun current(serial: Int): Boolean = serial == requestSerial && !isFinishing && !isDestroyed
    private fun dp(number: Int): Int = (number * resources.displayMetrics.density + 0.5f).toInt()

    override fun onDestroy() {
        requestSerial++
        pulse.setSearching(false)
        super.onDestroy()
    }
}
