package com.maahee.callerid

/** Consistent, locale-independent matching for Indian 10-digit numbers. */
object PhoneNumbers {
    fun digits(raw: String): String = buildString {
        for (char in raw) {
            val value = Character.digit(char, 10)
            if (value in 0..9) append(('0'.code + value).toChar())
        }
    }

    /** Accept +91/91/0 prefixes and punctuation, storing only the final 10 digits. */
    fun normalize(raw: String): String {
        val value = digits(raw)
        return if (value.length >= 10) value.takeLast(10) else ""
    }

    fun hasFullNumber(raw: String): Boolean = digits(raw).length >= 10
}
