# Maahee Caller ID v1.7 — Customer Desk

A refreshed Android app for Maahee Store 3 (Nashik), built on the existing v1.6 incoming-call screening and hourly Store 3 POS sync.

## What's new in v1.7

- **Customer Lookup is a real, dedicated page**, accessible from the dashboard and the caller popup. It is not a simulated test dialog.
- Search synced Store 3 customers **offline by name, full phone number or partial phone number**, and select a customer from matching results.
- A complete phone-number lookup shows encrypted cached details immediately, then attempts to refresh from the live Store 3 POS lookup API. New successful results are securely saved for future offline calls.
- The page displays the latest Store 3 sales, balances, alteration ticket, and trusted links to POS customer/invoice/tracker when provided by the server.
- Animated radar/pulse and stage text show customer matching in progress; animated result reveal; upgraded loading stages in the incoming caller popup.
- Optional `READ_CONTACTS` permission is used to label exact saved **device contacts** even if no Store 3 data is found. Contact matching is **read-only and local**; the address book is never uploaded.
- New boutique-inspired dashboard with a dedicated customer-search action, offline count, freshness indication, simplified configuration sections, and collapsible diagnostics.
- Encrypted offline directory reuses an in-memory decoded snapshot and search index while the app is running, avoiding repeated full-file decrypt/parse work on every incoming call.
- Failed sync checkpoints **do not overwrite existing fully synced records**. Newly encountered numbers can still be added offline as partial data. A full download atomically replaces the directory.
- Phone number matching supports formatted Indian 10-digit numbers and +91 / 0 prefixes, including Unicode decimal digits. Last 10 digits are used for matching as in v1.6.
- Keeps **the same app ID, encrypted file, Android Keystore alias, and saved preferences**, so an in-place upgrade with the same signing key can retain existing data.

## Build/install

This ZIP contains an **Android source project, not an APK**. Use AndroidForge or Android Studio with Android SDK 35, Kotlin Android Gradle plugin compatible with the project, and JDK 17. The ZIP intentionally does not contain an API token or private signing key.

1. Use the same signing key and **install over v1.6 without uninstalling**, or your old encrypted directory and API preferences will be lost. A different signature cannot be installed as an update.
2. Open the app and check that your saved HTTPS POS lookup URL and API token remain configured. The default URL is `https://pos.maahee.co.in/api/caller/lookup`.
3. Enable Call Screening, caller overlay permission, and optional Contacts permission on the store phone. Optional notification permission helps fallback alerts.
4. Tap **Sync Store 3 directory** with an internet connection and verify that a number count appears. The hourly auto-sync remains Android best-effort, not a continuously running service.
5. Tap **Find a customer**. Search a saved name, 2+ number digits, or a full 10-digit number. The first two use the encrypted local directory; the latter also requests live POS data when a network is available.
6. During an incoming call, tap **Open Customer Lookup** in the caller popup to open the same feature prefilled with the calling number.

## Privacy, behavior, limitations

- The encrypted directory contains Store 3 customers, last 3 bill summaries and the latest alteration fields returned by the POS API. The app does not store call logs or search history.
- The name search only covers **customers already available in the local Store 3 cache**; the existing POS endpoint supports online lookup by phone, not online name search.
- The phone's **saved contacts** are optional and separate from Store 3 customer records; a saved contact is explicitly labelled *PHONE CONTACT • NOT POS VERIFIED* when no POS match is available.
- A live POS `found=false` result for a valid Store 3 lookup removes a stale exact offline number; network failure never deletes the cached record.
- Readable API token is only shown in a password input; keep the token confidential. The POS endpoint must remain HTTPS and protected by a bearer token. Never publish token/screenshots of sensitive data.
- POS links are restricted to HTTPS URLs on `pos.maahee.co.in` to avoid navigating to untrusted URLs from API responses.
- Sync still uses the existing Store 3 `/api/caller/sync` response format; this update **does not need a new POS API implementation** if your v1.6 sync already works.
- Android can defer hourly jobs due to idle/battery saving, and overlays may not display on some phone/lock-screen combinations. The call screening service never blocks a phone call for a network request.

## Tests and build verification

- `tests/PhoneNumbersTest.kt` contains normalization regression cases, including formatted +91 numbers and Unicode digits.
- Source XML layout/resource parsing, all `R.id` references, and Kotlin phone-number normalization tests were validated in the packaging environment.
- **An Android SDK/Gradle toolchain was not available here, so a full Android compile, installation, POS integration test and on-device UI test have not been performed.** Build and test on your store phone before production use.
