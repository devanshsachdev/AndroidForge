import com.maahee.callerid.PhoneNumbers
fun main() {
    val cases = mapOf(
        "9876543210" to "9876543210",
        "+91 98765 43210" to "9876543210",
        "0091-98765-43210" to "9876543210",
        "0 9876543210" to "9876543210",
        "९८७६५४३२१०" to "9876543210",
        "98765" to ""
    )
    cases.forEach { (raw, expected) ->
        check(PhoneNumbers.normalize(raw) == expected) { "Failed $raw" }
    }
    check(PhoneNumbers.hasFullNumber("+91 (98765) 43210"))
    check(!PhoneNumbers.hasFullNumber("987654"))
    check(PhoneNumbers.digits("+91 98765") == "9198765")
    println("Passed ${cases.size + 3} phone parsing regression checks")
}
