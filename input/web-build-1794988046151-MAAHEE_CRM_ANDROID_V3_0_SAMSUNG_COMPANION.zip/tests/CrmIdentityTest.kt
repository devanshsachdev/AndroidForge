import com.maahee.callerid.DialerIdentity
fun main(){
 val valid=mapOf("9876543210" to "9876543210","+91 98765 43210" to "9876543210","0091 9876543210" to "9876543210","09876543210" to "9876543210","919876543210" to "9876543210","९८७६५४३२१०" to "9876543210")
 valid.forEach{(raw,expected)->check(DialerIdentity.posNumber(raw)==expected)}
 val invalid=listOf("+44 9876543210","+1 9876543210","+9198765432100","987654321","123","Private","-1","*123#","9876543210 ext 12","customer 9876543210","")
 invalid.forEach{check(DialerIdentity.posNumber(it)==null){"Incorrect POS match: $it"}}
 println("Passed ${valid.size+invalid.size} strict CRM POS identity checks")
}
