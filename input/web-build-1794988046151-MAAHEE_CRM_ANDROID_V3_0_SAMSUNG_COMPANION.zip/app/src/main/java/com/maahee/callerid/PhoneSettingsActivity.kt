package com.maahee.callerid

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock

class PhoneSettingsActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    override fun onCreate(state: Bundle?) {super.onCreate(state);val root=DialerUi.root(this);root.addBlock(DialerUi.button(this,"‹ Customer desk"){finish()});root.addBlock(DialerUi.text(this,"Settings",30f));body=DialerUi.scroll(root)}
    override fun onResume(){super.onResume();render()}
    private fun render(){
        body.removeAllViews();body.addBlock(DialerUi.text(this,"Samsung Phone integration",20f,true))
        body.addBlock(DialerUi.text(this,"Keep Samsung Phone as the default phone app. Maahee uses the separate caller ID role."))
        body.addBlock(DialerUi.button(this,"Android default apps"){runCatching{startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))}.onFailure{DialerUi.toast(this,"Open Settings > Apps > Choose default apps")}})
        body.addBlock(DialerUi.button(this,"POS, caller ID, overlay & sync",true){startActivity(Intent(this,MainActivity::class.java))})
        val allowed=DialerData.allowed(this,Manifest.permission.READ_CALL_LOG)
        body.addBlock(DialerUi.text(this,if(allowed) "System call history access granted" else "Observed calls only. Android may restrict full call history access."))
        if(!allowed)body.addBlock(DialerUi.button(this,"Request call history access"){requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG),601)})
        body.addBlock(DialerUi.text(this,"Recording centre",20f,true))
        body.addBlock(DialerUi.text(this,"Use Samsung Phone's native recording if available. Import recordings from a customer profile. Maahee does not record calls itself."))
        body.addBlock(DialerUi.button(this,"Saved recordings"){startActivity(Intent(this,RecordingLibraryActivity::class.java))})
        body.addBlock(DialerUi.button(this,"App permissions & battery"){startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))})
        body.addBlock(DialerUi.text(this,"Maahee CRM 3.0.0 · Local notes and follow-ups",13f))
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);render()}
}
