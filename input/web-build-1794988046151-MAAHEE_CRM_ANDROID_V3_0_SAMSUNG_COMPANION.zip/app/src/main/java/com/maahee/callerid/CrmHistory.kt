package com.maahee.callerid

import android.content.Context
import android.provider.CallLog
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec

/** Only screening callbacks; never implies a call was answered or missed. */
object CrmHistory {
    private fun file(c: Context) = AtomicFile(File(c.filesDir,"maahee_observed_calls_v3.enc"))
    private fun read(c: Context): JSONArray {
        val f=file(c); if(!f.baseFile.exists()) return JSONArray()
        val b=f.readFully(); require(b.size>29 && b[0]==1.toByte())
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,DialerNotes.key(),GCMParameterSpec(128,b.copyOfRange(1,13)))
        return JSONArray(String(cipher.doFinal(b.copyOfRange(13,b.size)),Charsets.UTF_8))
    }
    @Synchronized fun record(c: Context, raw: String, incoming: Boolean, date: Long) {
        val number=DialerIdentity.key(raw); if(!number.matches(Regex("\\+?[0-9]{7,15}"))) return
        val old=read(c); val next=JSONArray()
        next.put(JSONObject().put("number",number).put("date",date).put("incoming",incoming))
        for(i in 0 until minOf(old.length(),999)) next.put(old.getJSONObject(i))
        val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,DialerNotes.key())
        val bytes=byteArrayOf(1)+cipher.iv+cipher.doFinal(next.toString().toByteArray(Charsets.UTF_8))
        val f=file(c);val out=f.startWrite();try{out.write(bytes);f.finishWrite(out)}catch(e:Exception){f.failWrite(out);throw e}
    }
    @Synchronized fun observed(c: Context, number: String?=null, limit: Int=500): List<DialerData.Log> {
        val a=read(c); val key=number?.let(DialerIdentity::key)
        return (0 until a.length()).asSequence().map{a.getJSONObject(it)}.filter{key==null || it.optString("number")==key}.take(limit).map {
            val date=it.optLong("date"); DialerData.Log(date,it.optString("number"),"",date,-1,if(it.optBoolean("incoming")) 101 else 102)
        }.toList()
    }
    fun logs(c: Context, number: String?=null, limit: Int=500): List<DialerData.Log> {
        if(DialerData.allowed(c,android.Manifest.permission.READ_CALL_LOG)) {
            val system=runCatching { DialerData.logs(c,number,limit) }.getOrNull()
            if(system!=null) return system
        }
        return observed(c,number,limit)
    }
}
