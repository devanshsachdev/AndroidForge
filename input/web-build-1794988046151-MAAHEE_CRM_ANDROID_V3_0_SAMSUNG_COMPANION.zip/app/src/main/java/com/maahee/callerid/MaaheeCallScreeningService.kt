package com.maahee.callerid

import android.telecom.Call
import android.telecom.CallScreeningService

/** Samsung remains responsible for calls. Never blocks, silences or delays a call for POS. */
class MaaheeCallScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        val incoming=details.callDirection==Call.Details.DIRECTION_INCOMING
        if(incoming) respondToCall(details,CallResponse.Builder().setDisallowCall(false).build())
        val handle=details.handle
        val phone=if(handle?.scheme=="tel") handle.schemeSpecificPart.orEmpty() else ""
        if(!DialerIdentity.key(phone).matches(Regex("\\+?[0-9]{7,15}"))) return
        val app=applicationContext
        if(incoming) {
            CallDiagnostics.incoming(app,CallDiagnostics.mask(phone))
            runCatching { CallerOverlay.showAndLookup(app,phone) }.onFailure { CallDiagnostics.event(app,"Caller card unavailable") }
        }
        val date=System.currentTimeMillis()
        Thread { runCatching { CrmHistory.record(app,phone,incoming,date) }.onFailure { CallDiagnostics.event(app,"Observed call history unavailable") } }.start()
    }
}
