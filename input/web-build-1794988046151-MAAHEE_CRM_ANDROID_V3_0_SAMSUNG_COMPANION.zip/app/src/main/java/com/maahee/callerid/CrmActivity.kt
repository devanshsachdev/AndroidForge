package com.maahee.callerid

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual
import java.util.concurrent.Executors

/** Recycled rows; all provider, encrypted-directory and history reads on one worker. */
class CrmActivity : AppCompatActivity() {
    private data class Item(val number:String,val title:String,val subtitle:String,val date:Long=0L)
    private data class Result(val items:List<Item>,val status:String)
    private lateinit var query: EditText
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var nav:LinearLayout
    private lateinit var list:ListView
    private lateinit var adapter:Rows
    private lateinit var actions:LinearLayout
    private var tab="Calls"
    private var missed=false
    private var favoritesOnly=false
    private var generation=0
    private val worker=Executors.newSingleThreadExecutor()
    private var pending:java.util.concurrent.Future<*>?=null
    private val handler=Handler(Looper.getMainLooper())
    private val refreshTask=Runnable{refresh()}
    override fun onCreate(state:Bundle?) {
        super.onCreate(state)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        tab=state?.getString("tab") ?: "Calls"
        val root=DialerUi.root(this).apply{isFocusableInTouchMode=true;requestFocus()}
        val top=DialerUi.row(this);val brand=DialerUi.column(this)
        brand.addBlock(DialerUi.text(this,"MAAHEE  /  CUSTOMER DESK",12f,true),2)
        brand.addBlock(DialerUi.text(this,"Customer CRM",29f,true),0)
        top.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        top.addView(DialerUi.icon(this,"more","Menu"){anchor->menu(anchor)})
        root.addBlock(top,14)
        query=EditText(this).apply{hint="Search customer or mobile";setSingleLine(true);textSize=16f;val p=DialerUi.dp(this@CrmActivity,15);setPadding(p,p,p,p);background=DialerUi.round(this@CrmActivity,0xffeef1f7.toInt(),24)}
        root.addBlock(query,12)
        title=DialerUi.text(this,"",23f,true);root.addBlock(title,4)
        status=DialerUi.text(this,"",13f);root.addBlock(status,8)
        actions=DialerUi.row(this);root.addBlock(actions,4)
        list=ListView(this).apply{divider=null;dividerHeight=0;clipToPadding=false;isVerticalScrollBarEnabled=false}
        adapter=Rows();list.adapter=adapter;root.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        list.setOnItemClickListener{_,_,position,_->val item=adapter.getItem(position);if(DialerIdentity.key(item.number).isNotBlank())startActivity(DialerDetailActivity.intent(this,item.number,item.date))}
        nav=DialerUi.row(this);root.addBlock(nav,0)
        query.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){generation++;pending?.cancel(true);handler.removeCallbacks(refreshTask);handler.postDelayed(refreshTask,180L)};override fun afterTextChanged(s:Editable?){} })
        showTab(tab)
        if(Prefs.autoSync(this))DirectorySyncJob.schedule(applicationContext)
    }
    override fun onResume(){super.onResume();if(::list.isInitialized)refresh()}
    override fun onSaveInstanceState(outState:Bundle){outState.putString("tab",tab);super.onSaveInstanceState(outState)}
    override fun onDestroy(){generation++;pending?.cancel(true);handler.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy()}
    private fun menu(anchor:View){PopupMenu(this,anchor).apply{
        menu.add("Settings & setup").setOnMenuItemClickListener{startActivity(Intent(this@CrmActivity,PhoneSettingsActivity::class.java));true}
        menu.add("Recording centre").setOnMenuItemClickListener{startActivity(Intent(this@CrmActivity,RecordingLibraryActivity::class.java));true}
        menu.add("Open phone keypad").setOnMenuItemClickListener{runCatching{startActivity(Intent(Intent.ACTION_DIAL))};true}
        show()
    }}
    private fun showTab(value:String){
        tab=value;title.text=when(value){"Customers"->"Find a customer";"Follow-ups"->"Follow-up queue";else->"Recent calls"}
        nav.removeAllViews();listOf("Calls" to "history","Customers" to "person","Follow-ups" to "star").forEach{(label,icon)->nav.addView(DialerUi.nav(this,label,icon,tab==label){showTab(label)},LinearLayout.LayoutParams(0,-2,1f))}
        actions.removeAllViews()
        if(tab=="Calls"){
            actions.addEqual(DialerUi.pill(this,"All",!missed){missed=false;showTab(tab)})
            actions.addEqual(DialerUi.pill(this,"Missed",missed){missed=true;showTab(tab)})
            actions.addEqual(DialerUi.pill(this,"Refresh",false){refresh()})
        }else if(tab=="Customers"){
            actions.addEqual(DialerUi.pill(this,if(favoritesOnly) "Favorites ✓" else "Favorites",favoritesOnly){favoritesOnly=!favoritesOnly;showTab(tab)})
            actions.addEqual(DialerUi.pill(this,"Open number",true){val raw=query.text.toString().trim();if(DialerIdentity.key(raw).matches(Regex("\\+?[0-9]{7,15}")))startActivity(DialerDetailActivity.intent(this,raw))else DialerUi.toast(this,"Enter a complete phone number")})
            actions.addEqual(DialerUi.pill(this,"Live POS",false){startActivity(Intent(this,CustomerLookupActivity::class.java).putExtra(CustomerLookupActivity.EXTRA_PHONE,query.text.toString()))})
        }else actions.addEqual(DialerUi.pill(this,"Mark a caller",true){val input=EditText(this).apply{hint="Mobile number";inputType=android.text.InputType.TYPE_CLASS_PHONE};androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Add follow-up").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Open profile"){_,_->val raw=input.text.toString();if(DialerIdentity.key(raw).matches(Regex("\\+?[0-9]{7,15}")))startActivity(DialerDetailActivity.intent(this,raw))else DialerUi.toast(this,"Enter a valid phone number")}.show()})
        adapter.replace(emptyList());refresh()
    }
    private fun refresh(){
        if(!::list.isInitialized || worker.isShutdown)return
        val serial=++generation;val section=tab;val term=query.text.toString().trim();val onlyMissed=missed;val onlyFavorites=favoritesOnly;val app=applicationContext
        pending?.cancel(true);status.text="Finding ${if(section=="Customers") "customers" else "records"}…"
        pending=worker.submit {
            val result=runCatching {
                val profiles=DialerNotes.all(app)
                fun matching(number:String,name:String,extra:String=""):Boolean {
                    if(term.isBlank())return true
                    val digits=PhoneNumbers.digits(term)
                    return name.contains(term,true)||extra.contains(term,true)||number.contains(term,true)||(digits.isNotEmpty()&&term.none{it.isLetter()}&&PhoneNumbers.digits(number).contains(digits))
                }
                fun label(number:String,fallback:String=""):String = profiles[DialerIdentity.key(number)]?.name?.takeIf{it.isNotBlank()} ?: DialerIdentity.posNumber(number)?.let{OfflineCache.find(app,it)}?.let{CustomerPresentation.name(it.payload)} ?: fallback.ifBlank{number}
                fun note(number:String):String=profiles[DialerIdentity.key(number)]?.notes?.maxByOrNull{it.time}?.text?.replace(Regex("\\s+")," ")?.take(90).orEmpty()
                when(section){
                    "Customers"->{
                        val local=linkedMapOf<String,Item>()
                        if(term.length>=2 && !onlyFavorites)OfflineCache.search(app,term,100).forEach{m->val k=DialerIdentity.key(m.phone);local[k]=Item(m.phone,label(m.phone,m.name),"${m.phone} · Saved POS")}
                        profiles.forEach{(n,p)->if((!onlyFavorites || p.favorite) && matching(n,p.name,p.tag+" "+note(n)))local.putIfAbsent(n,Item(n,label(n),listOf(n,p.tag,note(n)).filter{it.isNotBlank()}.joinToString(" · ")))}
                        if(term.length>=2 && !onlyFavorites) DialerData.contacts(app).filter{matching(it.number,it.name)}.take(100).forEach{c->val k=DialerIdentity.key(c.number);if(k.isNotBlank())local.putIfAbsent(k,Item(c.number,c.name,"${c.number} · Phone contact"))}
                        val stats=OfflineCache.stats(app)
                        Result(local.values.take(150),if(onlyFavorites) "${local.size} favorites" else if(term.length<2) "${stats.count} customers saved offline · Type 2 or more characters" else "${local.size} matches · Saved data; open a profile to refresh")
                    }
                    "Follow-ups"->{val rows=profiles.filterValues{it.followUpAt>0 || it.tag=="Follow up"}.entries.sortedBy{if(it.value.followUpAt>0)it.value.followUpAt else Long.MAX_VALUE}.filter{matching(it.key,it.value.name,it.value.tag+" "+note(it.key))}.map{(n,p)->Item(n,label(n),(if(p.followUpAt>0) (if(p.followUpAt<=System.currentTimeMillis())"Due · " else "Scheduled · ")+DialerUi.date(p.followUpAt) else "No due date")+"\n"+note(n))};Result(rows,"${rows.size} pending · Open a profile to schedule or complete")}
                    else->{val canRead=DialerData.allowed(app,android.Manifest.permission.READ_CALL_LOG);val logs=CrmHistory.logs(app);val observed=!canRead||logs.any{it.duration<0};val rows=logs.filter{!onlyMissed||it.type==android.provider.CallLog.Calls.MISSED_TYPE}.filter{DialerIdentity.key(it.number).isNotBlank()}.groupBy{DialerIdentity.key(it.number)}.values.mapNotNull{g->val l=g.first();val name=label(l.number,l.name);val n=note(l.number);if(!matching(l.number,name,n))null else Item(l.number,name,"${l.typeLabel()} · ${DialerUi.date(l.date)} · ${g.size} calls"+(if(n.isBlank())"" else "\n$n"),l.date)};Result(rows,if(onlyMissed&&observed)"Missed status unavailable without system call log access" else if(observed)"Observed calls only · Full history remains in Samsung Phone" else "${rows.size} callers · System call history")}
                }
            }
            runOnUiThread{if(serial!=generation||isFinishing||isDestroyed)return@runOnUiThread;result.onSuccess{r->status.text=r.status;adapter.replace(r.items);list.alpha=.65f;list.animate().alpha(1f).setDuration(170L).start()}.onFailure{status.text="Could not read local data. Try again in the menu or refresh.";adapter.replace(emptyList())}}
        }
    }
    private inner class Rows:BaseAdapter(){
        private var items:List<Item> = emptyList()
        fun replace(next:List<Item>){items=next;notifyDataSetChanged()}
        override fun getCount()=items.size
        override fun getItem(position:Int)=items[position]
        override fun getItemId(position:Int)=position.toLong()
        override fun getView(position:Int,convertView:View?,parent:ViewGroup?):View{
            val row=convertView as? LinearLayout ?: DialerUi.row(this@CrmActivity).apply{
                val c=this@CrmActivity;val pad=DialerUi.dp(c,10);setPadding(0,pad,0,pad)
                addView(DialerUi.avatar(c,"?"),LinearLayout.LayoutParams(DialerUi.dp(c,44),DialerUi.dp(c,44)).apply{marginEnd=DialerUi.dp(c,12)})
                val info=DialerUi.column(c);info.addBlock(DialerUi.text(c,"",17f,true),4);info.addBlock(DialerUi.text(c,"",13f),0);addView(info,LinearLayout.LayoutParams(0,-2,1f))
                addView(DialerUi.icon(c,"phone","Call number"){})
            }
            val item=getItem(position);(row.getChildAt(0) as TextView).text=item.title.firstOrNull()?.uppercaseChar()?.toString()?:"?";val info=row.getChildAt(1) as LinearLayout;(info.getChildAt(0) as TextView).text=item.title;(info.getChildAt(1) as TextView).text=item.subtitle
            row.getChildAt(2).setOnClickListener{runCatching{startActivity(Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",item.number,null)))}.onFailure{DialerUi.toast(this@CrmActivity,"Phone app unavailable")}};row.getChildAt(2).isFocusable=false;row.descendantFocusability=ViewGroup.FOCUS_BLOCK_DESCENDANTS
            return row
        }
    }
}
