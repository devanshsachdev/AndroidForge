package com.maahee.callerid

import android.content.Context
import android.net.Uri
import android.media.MediaMetadataRetriever
import java.util.UUID
import java.io.File

/** Only user-authorized imports; existing saved recordings preserved. */
object CallRecorder {
    private fun savedFile(f:File)=f.isFile && f.extension in setOf("m4a","audio")
    fun allFiles(c:Context):List<File> = folder(c).listFiles()?.filter(::savedFile)?.sortedByDescending { it.lastModified() }.orEmpty()
    /** User-selected audio only, explicitly associated to a number; no scanning of other apps' files. */
    fun importAudio(c:Context,phone:String,uri:Uri):Boolean {
        if(!DialerIdentity.key(phone).matches(Regex("\\+?[0-9]{7,15}"))) return false
        val base=prefix(phone)+"_"+System.currentTimeMillis()+"_"+UUID.randomUUID().toString()
        val temp=File(folder(c),"$base.part"); val output=File(folder(c),"$base.audio")
        return try {
            val input=c.contentResolver.openInputStream(uri) ?: return false
            input.use { source -> temp.outputStream().use { dest ->
                val buffer=ByteArray(65536); var total=0L
                while(true) { val n=source.read(buffer); if(n<0) break; total+=n; require(total<=250L*1024*1024); dest.write(buffer,0,n) }
            } }
            val meta=MediaMetadataRetriever()
            try { meta.setDataSource(temp.absolutePath); require(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)=="yes"); require((meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)>0) } finally { runCatching { meta.release() } }
            temp.renameTo(output)
        } catch(e:Exception) { false } finally { if(temp.exists()) temp.delete() }
    }
    private fun folder(c:Context)=File(c.filesDir,"call_recordings").apply{mkdirs()}
    private fun prefix(phone:String)=java.security.MessageDigest.getInstance("SHA-256").digest(DialerIdentity.key(phone).toByteArray()).joinToString(""){ "%02x".format(it.toInt() and 255) }
    fun files(c:Context,phone:String):List<File> = folder(c).listFiles()?.filter{it.name.startsWith(prefix(phone)+"_") && savedFile(it)}?.sortedByDescending{it.lastModified()}.orEmpty()
}
