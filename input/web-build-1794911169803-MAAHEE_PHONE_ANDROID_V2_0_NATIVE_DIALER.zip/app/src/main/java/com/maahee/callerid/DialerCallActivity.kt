package com.maahee.callerid

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual

@Suppress("DEPRECATION")
class DialerCallActivity: AppCompatActivity(){
    private lateinit var body: LinearLayout
    private lateinit var clock: TextView
    private lateinit var customer: LinearLayout
    private var service: MaaheeInCallService?=null
    private var selected:Call?=null
    private var lastPhone=""
    private var lastCallTime=0L
    private var lastSerial=0
    private var showKeys=false
    private var ready=false
    private var lastLocked=true
    private fun locked() = getSystemService(android.app.KeyguardManager::class.java)?.isDeviceLocked != false
    private val handler=Handler(Looper.getMainLooper())
    private val listener:()->Unit={render()}
    private val ticker=object:Runnable{override fun run(){if(!isDestroyed){if(lastLocked!=locked()){lastLocked=locked();render()};val c=selected;val start=c?.details?.connectTimeMillis?:0L; if(::clock.isInitialized && start>0){val sec=((System.currentTimeMillis()-start)/1000).coerceAtLeast(0);clock.text="%02d:%02d".format(sec/60,sec%60)};handler.postDelayed(this,1000)}}}
    override fun onCreate(state:Bundle?){super.onCreate(state);setShowWhenLocked(true);setTurnScreenOn(true);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SECURE);val root=DialerUi.root(this);root.addBlock(DialerUi.text(this,"MAAHEE  /  PHONE",13f,true));body=DialerUi.scroll(root);ready=true;attach();render();handler.post(ticker)}
    private fun attach(){val s=MaaheeInCallService.current();if(s!==service){service?.unlisten(listener);service=s;s?.listen(listener)}}
    override fun onResume(){super.onResume();if(ready){attach();render()}}
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);attach();render()}
    override fun onDestroy(){lastSerial++;service?.unlisten(listener);handler.removeCallbacksAndMessages(null);super.onDestroy()}
    private fun render(){if(!ready || isFinishing || isDestroyed)return;val s=service;val calls=s?.all().orEmpty();val c=calls.firstOrNull{it.state==Call.STATE_RINGING}?:selected?.takeIf{it in calls}?:s?.primary();selected=c;body.removeAllViews();if(c==null || s==null){body.addBlock(DialerUi.text(this,"Call ended",27f,true));if(lastPhone.isNotBlank() && !locked())body.addBlock(DialerUi.button(this,"Add note / view customer",true){startActivity(DialerDetailActivity.intent(this,lastPhone,lastCallTime));finish()});body.addBlock(DialerUi.button(this,"Back to Phone"){finish()});return}
        val phone=s.number(c);lastPhone=phone;lastCallTime=c.details.creationTimeMillis;val ringing=c.state==Call.STATE_RINGING;val active=c.state==Call.STATE_ACTIVE;val held=c.state==Call.STATE_HOLDING
        body.addBlock(DialerUi.text(this,when(c.state){Call.STATE_RINGING->"INCOMING CALL";Call.STATE_ACTIVE->"CONNECTED";Call.STATE_HOLDING->"ON HOLD";Call.STATE_DIALING,Call.STATE_CONNECTING->"CALLING";else->"PHONE CALL"},14f,true));body.addBlock(DialerUi.text(this,phone.ifBlank{"Private number"},28f,true));clock=DialerUi.text(this,"",18f);body.addBlock(clock)
        if(c.state==Call.STATE_SELECT_PHONE_ACCOUNT){
            body.addBlock(DialerUi.text(this,"Choose a SIM / phone account",18f,true));val manager=getSystemService(android.telecom.TelecomManager::class.java)
            val accounts = c.details.extras?.getParcelableArrayList<android.telecom.PhoneAccountHandle>(Call.AVAILABLE_PHONE_ACCOUNTS).orEmpty().ifEmpty { runCatching { manager?.callCapablePhoneAccounts.orEmpty() }.getOrDefault(emptyList()) }
            accounts.forEachIndexed { index, account -> val label=runCatching { manager?.getPhoneAccount(account)?.label?.toString() }.getOrNull() ?: "SIM ${index+1}"; body.addBlock(DialerUi.button(this,label,true){c.phoneAccountSelected(account,false)}) };body.addBlock(DialerUi.button(this,"Cancel call"){c.disconnect()});return
        }
        val buttons=DialerUi.row(this);if(ringing){buttons.addEqual(DialerUi.button(this,"Answer",true){c.answer(VideoProfile.STATE_AUDIO_ONLY)});buttons.addEqual(DialerUi.button(this,"Decline"){c.reject(false,null)})}else{buttons.addEqual(DialerUi.button(this,"End call",true){c.disconnect()});buttons.addEqual(DialerUi.button(this,if(held)"Resume" else "Hold"){if(held)c.unhold()else c.hold()}.apply{isEnabled=held || c.details.can(Call.Details.CAPABILITY_HOLD)})};body.addBlock(buttons)
        if(!ringing){val row=DialerUi.row(this);row.addEqual(DialerUi.button(this,if(s.isMutedNow())"Unmute" else "Mute"){s.mute()});row.addEqual(DialerUi.button(this,"Audio route"){routes(s)});row.addEqual(DialerUi.button(this,"Keypad"){showKeys=!showKeys; render()});body.addBlock(row);if(showKeys){listOf("123","456","789","*0#").forEach{digits->val r=DialerUi.row(this);digits.forEach{d->r.addEqual(DialerUi.button(this,d.toString()){c.playDtmfTone(d);handler.postDelayed({runCatching{c.stopDtmfTone()}},150)})};body.addBlock(r)}}
            val extra=DialerUi.row(this);extra.addEqual(DialerUi.button(this,"Add call"){startActivity(Intent(Intent.ACTION_DIAL,null,this,DialerActivity::class.java))}.apply{isEnabled=s.canAddCall()});extra.addEqual(DialerUi.button(this,"Merge"){c.conferenceableCalls.firstOrNull()?.let{c.conference(it)} ?: run {if(c.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE)) c.mergeConference()}}.apply{isEnabled=c.conferenceableCalls.isNotEmpty()||c.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE)});body.addBlock(extra)
        }
        if(calls.size>1){body.addBlock(DialerUi.text(this,"Other calls",14f,true));calls.filter{it!==c}.forEach{other->body.addBlock(DialerUi.button(this,"${s.number(other)} · ${if(other.state==Call.STATE_HOLDING)"Held" else "Select"}"){selected=other;render()})}}
        val actions=DialerUi.row(this); actions.addEqual(DialerUi.button(this,"Mark / note"){DialerProfileEditor.show(this,phone,c.details.creationTimeMillis){cachedText=null; pendingPhone=""; lastSerial++; render()}}.apply{isEnabled=DialerIdentity.key(phone).isNotBlank()});actions.addEqual(DialerUi.button(this,"Full history"){startActivity(DialerDetailActivity.intent(this,phone,c.details.creationTimeMillis))}.apply{isEnabled=DialerIdentity.key(phone).isNotBlank()});body.addBlock(actions)
        val locked=locked()
        if(locked){actions.visibility=android.view.View.GONE;body.addBlock(DialerUi.text(this,"Unlock device to view private customer details and notes."));return}
        customer=DialerUi.card(this);body.addBlock(customer);customer.addBlock(DialerUi.text(this,"Finding customer…",18f,true)); if(cachedText==null || cachedPhone!=phone) { val pulse=LookupPulseView(this); customer.addView(pulse,LinearLayout.LayoutParams(-1,DialerUi.dp(this,76)));pulse.setSearching(true) };lookup(phone)
    }
    private var cachedPhone="";private var cachedText:String?=null;private var pendingPhone=""
    private fun lookup(phone:String){if(phone!=cachedPhone){cachedText=null;cachedPhone=phone;pendingPhone="";lastSerial++};cachedText?.let{customer.removeAllViews();customer.addBlock(DialerUi.text(this,it));return};if(phone.isBlank()){customer.removeAllViews();customer.addBlock(DialerUi.text(this,"No number available"));return};if(phone==pendingPhone)return;pendingPhone=phone;val serial=++lastSerial;val ctx=applicationContext;val n=DialerIdentity.posNumber(phone)
        Thread{val label=DialerData.name(ctx,phone);val saved=n?.let{runCatching{OfflineCache.find(ctx,it)}.getOrNull()};val local="$label\n"+(saved?.let{"OFFLINE · ${DialerUi.date(it.timestamp)}\n\n${CustomerPresentation.summary(it.payload)}"}?:"No saved POS record")
            runOnUiThread{if(serial==lastSerial && selected?.let{service?.number(it)}==phone && !isDestroyed && !isFinishing && ::customer.isInitialized && !locked()){customer.removeAllViews();customer.addBlock(DialerUi.text(this,local+"\n\nChecking live POS…"))}}
            val result=n?.let{ApiClient.lookup(ctx,it)};val root=result?.json;val valid=result?.ok==true && root!=null && root.has("found") && root.optInt("store_id",3)==3;val text=if(valid && root!!.optBoolean("found")){runCatching{OfflineCache.remember(ctx,n!!,root)};"$label\nLIVE POS · ${CustomerPresentation.name(root)}\n\n${CustomerPresentation.summary(root)}"}else if(valid) { n?.let { runCatching{OfflineCache.forget(ctx,it)} }; "$label\nNo matching Store 3 customer" } else local
            runOnUiThread{if(serial!=lastSerial || isDestroyed || isFinishing)return@runOnUiThread;pendingPhone="";cachedText=text;if(selected?.let{service?.number(it)}==phone && ::customer.isInitialized && !locked()){customer.removeAllViews();customer.addBlock(DialerUi.text(this,text));customer.alpha=.5f;customer.animate().alpha(1f).setDuration(240).start()}}
        }.start()
    }
    private fun routes(s:MaaheeInCallService){val options=s.audioOptions();if(options.isEmpty()){DialerUi.toast(this,"Audio output unavailable");return};androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Audio output").setItems(options.map{it.label}.toTypedArray()){_,i->options[i].choose()}.show()}
}
