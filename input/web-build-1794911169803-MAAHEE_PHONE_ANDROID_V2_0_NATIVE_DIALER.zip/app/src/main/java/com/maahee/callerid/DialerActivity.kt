package com.maahee.callerid

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual

class DialerActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private lateinit var callStatus: TextView
    private lateinit var live: Button
    private var tab = "Recents"
    private var request = 0
    private val delayedSearch = Runnable { refresh() }
    private var observing = false
    private val handler = Handler(Looper.getMainLooper())
    private val observer = object : ContentObserver(handler) { override fun onChange(selfChange: Boolean) { if(tab == "Recents") refresh() } }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = DialerUi.root(this)
        val bar = DialerUi.row(this); bar.addView(DialerUi.text(this,"MAAHEE\nPhone",24f,true),LinearLayout.LayoutParams(0,-2,1f)); bar.addView(DialerUi.button(this,"Settings") { startActivity(Intent(this,MainActivity::class.java)) }); root.addBlock(bar)
        callStatus = DialerUi.text(this,"",12f); root.addBlock(callStatus)
        if(android.os.Build.VERSION.SDK_INT >= 34 && getSystemService(android.app.NotificationManager::class.java)?.canUseFullScreenIntent() == false) root.addBlock(DialerUi.button(this,"Allow full-screen incoming calls") { runCatching { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:$packageName"))) } })
        live = DialerUi.button(this,"Return to active call",true) { startActivity(Intent(this,DialerCallActivity::class.java)) }; root.addBlock(live)
        val nav = DialerUi.row(this); listOf("Recents","Contacts","Favorites","Keypad").forEach { item -> nav.addEqual(DialerUi.button(this,item) { changeTab(item) }) }; root.addBlock(nav)
        root.addBlock(DialerUi.button(this,"Customer Lookup · POS & offline directory",true) { startActivity(Intent(this,CustomerLookupActivity::class.java)) })
        search = EditText(this).apply { hint = "Search name or number"; setSingleLine(true); textSize = 16f }; root.addBlock(search)
        body = DialerUi.scroll(root)
        search.addTextChangedListener(object: TextWatcher { override fun beforeTextChanged(s: CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){ if(tab != "Keypad") { request++; handler.removeCallbacks(delayedSearch); handler.postDelayed(delayedSearch, 220L) } }; override fun afterTextChanged(s:Editable?){} })
        changeTab(state?.getString("tab") ?: if(intent.action == Intent.ACTION_DIAL) "Keypad" else "Recents")
        if(intent.action == Intent.ACTION_DIAL) applyDialIntent(intent)
        if(Prefs.autoSync(this)) DirectorySyncJob.schedule(applicationContext)
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); if(intent.action == Intent.ACTION_DIAL) applyDialIntent(intent) }
    override fun onSaveInstanceState(outState: Bundle) { outState.putString("tab",tab); super.onSaveInstanceState(outState) }
    private fun applyDialIntent(i: Intent) { changeTab("Keypad"); if(i.data?.scheme == "tel") keypadInput?.setText(i.data?.schemeSpecificPart.orEmpty()) }
    override fun onResume() { super.onResume(); updateRole(); live.visibility = if(MaaheeInCallService.current()?.primary() != null) View.VISIBLE else View.GONE; if(DialerData.allowed(this,Manifest.permission.READ_CALL_LOG) && !observing) { runCatching { contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI,true,observer); observing = true } }; if(tab != "Keypad") refresh() }
    override fun onPause() { if(observing){ contentResolver.unregisterContentObserver(observer); observing=false }; super.onPause() }
    override fun onDestroy(){ request++; handler.removeCallbacksAndMessages(null); super.onDestroy() }
    private fun roleHeld() = getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_DIALER) == true
    private fun updateRole(){ callStatus.text = if(roleHeld()) "DEFAULT PHONE · ${if(DialerData.allowed(this,Manifest.permission.READ_CALL_LOG)) "History enabled" else "History permission required"}" else "Setup required · Choose Maahee as your default phone"; callStatus.setOnClickListener { setup() } }
    private fun setup(){ val r = getSystemService(RoleManager::class.java) ?: return; if(!roleHeld()) { if(r.isRoleAvailable(RoleManager.ROLE_DIALER)) startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_DIALER),501); else DialerUi.toast(this,"Default phone role unavailable"); return }; permissions() }
    private fun permissions(){ val wanted = mutableListOf(Manifest.permission.READ_CALL_LOG,Manifest.permission.CALL_PHONE,Manifest.permission.READ_CONTACTS,Manifest.permission.READ_PHONE_STATE); if(android.os.Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS; val missing = wanted.filter { !DialerData.allowed(this,it) }; if(missing.isNotEmpty()) requestPermissions(missing.toTypedArray(),502); else DialerUi.toast(this,"Calling permissions enabled") }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode == 501 && roleHeld()) permissions() }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){ super.onRequestPermissionsResult(requestCode,permissions,grantResults); updateRole(); if(tab != "Keypad") refresh() }
    private fun changeTab(value:String){ tab=value; search.visibility=if(value=="Keypad") View.GONE else View.VISIBLE; request++; if(value=="Keypad") keypad() else refresh() }
    private data class Row(val number:String,val title:String,val description:String,val date:Long=0L,val tag:String="")
    private fun refresh(){
        if(!::body.isInitialized || tab=="Keypad") return
        val serial=++request; val selected=tab; val term=search.text.toString().trim(); val c=applicationContext
        body.removeAllViews(); if(!roleHeld() || !DialerData.allowed(this,Manifest.permission.READ_CALL_LOG)) body.addBlock(DialerUi.button(this,"Enable default phone & permissions",true){setup()})
        if(selected=="Contacts" && !DialerData.allowed(this,Manifest.permission.READ_CONTACTS)) body.addBlock(DialerUi.button(this,"Allow contacts") { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS),503) })
        body.addBlock(DialerUi.text(this,"Loading $selected…"))
        Thread {
            val result=runCatching {
                val profiles=runCatching { DialerNotes.all(c) }.getOrDefault(emptyMap())
                val rows=when(selected){
                    "Contacts" -> DialerData.contacts(c).map { val p=profiles[DialerIdentity.key(it.number)]; Row(it.number,p?.name?.takeIf{ n->n.isNotBlank() } ?: it.name,it.number,tag=p?.tag.orEmpty()) }
                    "Favorites" -> profiles.filterValues{it.favorite}.map{(n,p)-> Row(n,DialerData.name(c,n),n,tag=p.tag)}
                    else -> DialerData.logs(c).groupBy{ DialerIdentity.key(it.number).ifBlank { "private-${it.id}" } }.values.map{ group-> val l=group.first(); val p=profiles[DialerIdentity.key(l.number)]; Row(l.number,DialerData.name(c,l.number,l.name),"${l.typeLabel()} · ${DialerUi.date(l.date)} · ${group.size} in recent log",l.date,p?.tag.orEmpty()) }
                }; rows.filter { term.isBlank() || it.title.contains(term,true) || it.number.contains(term,true) || it.tag.contains(term,true) || (PhoneNumbers.digits(term).isNotEmpty() && PhoneNumbers.digits(it.number).contains(PhoneNumbers.digits(term))) }.take(200)
            }
            runOnUiThread { if(serial != request || isFinishing || isDestroyed) return@runOnUiThread
                body.removeAllViews(); if(!roleHeld() || !DialerData.allowed(this,Manifest.permission.READ_CALL_LOG)) body.addBlock(DialerUi.button(this,"Enable default phone & permissions",true){setup()})
                if(selected=="Contacts" && !DialerData.allowed(this,Manifest.permission.READ_CONTACTS)) body.addBlock(DialerUi.button(this,"Allow contacts") { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS),503) })
                result.onFailure { body.addBlock(DialerUi.text(this,"Could not load $selected. Check permissions or encrypted storage.")) }
                result.getOrNull()?.let { rows -> if(rows.isEmpty()) body.addBlock(DialerUi.text(this,"No matching $selected")); rows.forEach { item ->
                    val card=DialerUi.card(this); val line=DialerUi.row(this); val info=DialerUi.column(this); info.addBlock(DialerUi.text(this,item.title.ifBlank{"Private number"},17f,true),3); info.addBlock(DialerUi.text(this,item.description,12f),3); if(item.tag.isNotBlank()) info.addBlock(DialerUi.text(this,item.tag,12f,true),0)
                    line.addView(info,LinearLayout.LayoutParams(0,-2,1f)); if(DialerIdentity.key(item.number).isNotBlank()) line.addView(DialerUi.button(this,"Call"){ place(item.number) }); card.addBlock(line,0); info.setOnClickListener { if(DialerIdentity.key(item.number).isNotBlank()) startActivity(DialerDetailActivity.intent(this,item.number,item.date)) else DialerUi.toast(this,"Number withheld") }; card.setOnClickListener { info.performClick() }; body.addBlock(card)
                } }
            }
        }.start()
    }
    private var keypadInput: EditText?=null
    private fun keypad(){ body.removeAllViews(); val input=EditText(this).apply{ inputType=android.text.InputType.TYPE_CLASS_PHONE; textSize=28f; gravity=android.view.Gravity.CENTER; showSoftInputOnFocus=false; setSingleLine(true); hint="Enter number" }; keypadInput=input; body.addBlock(input)
        listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("*","0","#")).forEach{ keys-> val row=DialerUi.row(this); keys.forEach{ k-> val btn=DialerUi.button(this,k){input.append(k)}; btn.textSize=24f; if(k=="0") btn.setOnLongClickListener{input.append("+");true}; row.addEqual(btn)};body.addBlock(row) }
        val controls=DialerUi.row(this); controls.addEqual(DialerUi.button(this,"+ "){input.append("+")}); controls.addEqual(DialerUi.button(this,"Delete"){if(input.length()>0) input.text.delete(input.length()-1,input.length())}); body.addBlock(controls)
        body.addBlock(DialerUi.button(this,"Call",true){place(input.text.toString())}); body.addBlock(DialerUi.button(this,"Open number details"){ if(DialerIdentity.key(input.text.toString()).isNotBlank()) startActivity(DialerDetailActivity.intent(this,input.text.toString())) })
    }
    private fun place(number:String){ if(number.isBlank() || DialerIdentity.key(number).isBlank()) return; if(!roleHeld()){setup();return}; if(!DialerData.allowed(this,Manifest.permission.CALL_PHONE)){permissions();return}; runCatching { requireNotNull(getSystemService(TelecomManager::class.java)).placeCall(Uri.fromParts("tel",number,null),Bundle()) }.onFailure { DialerUi.toast(this,"Unable to place call") } }
}
