package com.maahee.callerid

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DialerUi {
    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density + .5f).toInt()
    fun column(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
    fun row(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
    fun text(c: Context, value: String, size: Float = 14f, bold: Boolean = false) = TextView(c).apply {
        text = value; textSize = size; setTextColor(c.getColor(R.color.maahee_ink)); if (bold) setTypeface(null, Typeface.BOLD)
    }
    fun button(c: Context, label: String, primary: Boolean = false, action: () -> Unit) = Button(c).apply {
        text = label; isAllCaps = false; textSize = 14f; minHeight = dp(c, 48); minimumHeight = dp(c, 48)
        setBackgroundResource(if (primary) R.drawable.bg_plum_button else R.drawable.bg_outline_button)
        setTextColor(c.getColor(if (primary) R.color.maahee_surface else R.color.maahee_plum)); setOnClickListener { action() }
    }
    fun LinearLayout.addBlock(view: View, gap: Int = 8) { addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(context, gap) }) }
    fun LinearLayout.addEqual(view: View) { addView(view, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(context, 4) }) }
    fun card(c: Context) = column(c).apply { setBackgroundResource(R.drawable.bg_surface); val p = dp(c, 14); setPadding(p,p,p,p) }
    fun root(a: Activity): LinearLayout = column(a).apply {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(a.window, false); setBackgroundColor(a.getColor(R.color.maahee_canvas)); val p = dp(a, 14)
        setPadding(p,p,p,p); ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime())
            v.setPadding(p + bars.left,p + bars.top,p + bars.right,p + bars.bottom); insets
        }; a.setContentView(this); ViewCompat.requestApplyInsets(this)
    }
    fun scroll(parent: LinearLayout): LinearLayout { val c = parent.context; val content = column(c); val sv = ScrollView(c).apply { isFillViewport = true; addView(content) }; parent.addView(sv, LinearLayout.LayoutParams(-1,0,1f)); return content }
    fun date(timestamp: Long) = SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.getDefault()).format(Date(timestamp))
    fun toast(c: Context, s: String) = Toast.makeText(c,s,Toast.LENGTH_SHORT).show()
}
