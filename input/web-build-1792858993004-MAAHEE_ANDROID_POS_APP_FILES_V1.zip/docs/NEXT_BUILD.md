# Next implementation package

1. Authentication against existing POS users and roles.
2. Product/customer search APIs.
3. Native cart and authoritative server total calculation.
4. Cash/Card/UPI/Split/Credit Note payment endpoints.
5. Tailoring tracker update endpoint.
6. Native purchase create/edit endpoint preserving stock/cost behavior.
7. Purchase -> Barcode queue endpoint using existing barcode tables.
8. 48x30 native PDF export and Bluetooth printing.
9. Offline Room cache for catalog/customers/draft carts only.
10. Keep Credit Note/loyalty redemption online-only.
