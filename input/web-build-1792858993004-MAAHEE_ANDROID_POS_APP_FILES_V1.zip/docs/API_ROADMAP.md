# Maahee Native Android POS — API Roadmap

Base: `https://pos.apsarasbawree.in/api/v1/`

## Authentication
- POST auth/login
- POST auth/logout
- GET auth/me
- Server-enforced Admin/Staff permissions. Never rely only on hidden Android buttons.

## POS
- GET products/search?q=
- GET products/{id}
- GET customers/search?q=
- POST customers
- POST sales/quote
- POST sales/create
- GET sales/{id}
- POST sales/{id}/payment
- POST sales/{id}/tailoring

## Credit Notes
- GET credit-notes/lookup?term=
- POST credit-notes/redeem
- POST credit-notes/{payment_id}/reverse (Admin only)

Redemption must always call the existing atomic `Sales_model::redeemCreditNote()` path so payment + used_amount + balance + status + ledger update together.

## Tailoring Tracker
- GET tailoring?status=Pending
- POST tailoring/{sale_id}/status
- POST tailoring/{sale_id}/details
- GET tailoring/{sale_id}

Native columns: Pending, Cutting, Stitching, Ready, Delivered.

## Purchases
- GET suppliers/search?q=
- POST purchases
- PUT purchases/{id}
- GET purchases/{id}
- POST purchases/{id}/payment
- POST purchases/{id}/barcode-batch

Quick purchase UX keeps your size ranges, copy-last, product image, GST, cost, price and quantity flow.

## Barcode Center
- GET barcode-batches
- POST barcode-batches/from-purchase/{purchase_id}
- GET barcode-batches/{id}
- POST barcode-batches/{id}/pdf

Label standard: 48 × 30 mm, Code128, current Classic Box/default layout. Android can also generate/print natively later.

## Reports
- Supplier Performance
- Buying Intelligence
- Size-wise Sell-through
- Dead Stock
- Smart Reorder
- Margin Leakage
- Customer / Loyalty / Finance reports
