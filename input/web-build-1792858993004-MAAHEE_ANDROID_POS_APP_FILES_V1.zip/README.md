# Maahee POS Native Android V1 Foundation

This is a **native Kotlin + Jetpack Compose** project foundation. It is not a WebView wrapper and does not put MySQL credentials inside the APK.

## Included native modules
- POS
- Sales / invoices / payments
- Tailoring Tracker
- Quick Purchases
- Barcode Center
- Customers
- Credit Notes
- Reports
- Settings

## Purchase → Barcode workflow
1. Select supplier and invoice.
2. Scan/add products, quantities, costs, prices and sizes.
3. Save purchase through HTTPS API.
4. Tap **Save Purchase & Generate Barcodes**.
5. Barcode Center creates a saved batch.
6. Export 48×30 PDF or print to a Bluetooth printer.

## Tailoring Tracker
Native Kanban flow: Pending → Cutting → Stitching → Ready → Delivered.

## Security architecture
Android → HTTPS API → existing CodeIgniter business logic → MySQL.
Never Android → MySQL directly.

## Build environment
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17
- compile/target SDK 37
- Compose BOM 2026.09.00

The Android source is an architecture/UI foundation; production API wiring must be completed against the exact latest live controllers/models before deployment.
