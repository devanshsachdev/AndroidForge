package com.apsarasbawree.maaheepos.data

import java.net.HttpURLConnection
import java.net.URL

/**
 * Native HTTPS API client foundation.
 * Do NOT connect the APK directly to MySQL. All writes go through the POS backend API.
 */
object ApiClient {
    var baseUrl: String = "https://pos.apsarasbawree.in/api/v1/"
    var bearerToken: String? = null

    fun get(path: String): String {
        val conn = URL(baseUrl + path.trimStart('/')).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        conn.setRequestProperty("Accept", "application/json")
        bearerToken?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        return conn.inputStream.bufferedReader().use { it.readText() }
    }
}
