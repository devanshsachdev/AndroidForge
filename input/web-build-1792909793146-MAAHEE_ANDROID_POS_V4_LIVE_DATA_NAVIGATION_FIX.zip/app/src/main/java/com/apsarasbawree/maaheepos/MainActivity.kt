@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.apsarasbawree.maaheepos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.apsarasbawree.maaheepos.data.ApiClient
import com.apsarasbawree.maaheepos.model.*
import com.apsarasbawree.maaheepos.ui.theme.MaaheeTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApiClient.load(this)
        setContent { MaaheeTheme { MaaheeApp() } }
    }
}

@Composable
fun MaaheeApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("pos") { PosScreen(nav) }
        composable("sales") { SalesScreen(nav) }
        composable("tracker") { TrackerScreen(nav) }
        composable("purchases") { PurchasesScreen(nav) }
        composable("barcodes") { BarcodeScreen(nav) }
        composable("customers") { CustomersScreen(nav) }
        composable("credit_notes") { CreditNotesScreen(nav) }
        composable("reports") { ReportsScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
    }
}

@Composable
private fun AppBar(title: String, nav: NavHostController? = null) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (nav != null) IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
        }
    )
}

@Composable
private fun HomeScreen(nav: NavHostController) {
    val tiles = listOf(
        DashboardTile("POS", "Billing & checkout", "pos"),
        DashboardTile("Sales", "Live invoices & payments", "sales"),
        DashboardTile("Tailoring Tracker", "Live Pending → Delivered", "tracker"),
        DashboardTile("Purchases", "Live purchases + quick receiving", "purchases"),
        DashboardTile("Barcode Center", "Live barcode queue / 48×30", "barcodes"),
        DashboardTile("Customers", "Search ledger & rewards", "customers"),
        DashboardTile("Credit Notes", "Live lookup & balance", "credit_notes"),
        DashboardTile("Reports", "Live dashboard totals", "reports"),
        DashboardTile("Settings", "API connection", "settings")
    )
    Scaffold(topBar = { AppBar("Maahee POS") }) { pad ->
        LazyColumn(contentPadding = PaddingValues(16.dp), modifier = Modifier.padding(pad), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tiles) { tile ->
                Card(onClick = { nav.navigate(tile.route) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text(tile.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp)); Text(tile.subtitle)
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionHint() {
    if (ApiClient.bearerToken.isBlank()) {
        Text("API token is not configured. Open Settings and enter your token before loading live POS data.", color = MaterialTheme.colorScheme.error)
    }
}

private fun dataArray(body: String): JSONArray {
    val root = JSONObject(body)
    if (!root.optBoolean("success", false)) throw IllegalStateException(root.optString("message", "API request failed"))
    val d = root.opt("data")
    return when (d) { is JSONArray -> d; null -> JSONArray(); else -> JSONArray().put(d) }
}

private fun invoiceOf(o: JSONObject): String = o.optString("invoice_no").ifBlank { o.optString("ser_no").ifBlank { o.optString("custom_id").ifBlank { o.optInt("id").toString() } } }

@Composable
private fun PosScreen(nav: NavHostController) {
    var term by remember { mutableStateOf("") }
    var products by remember { mutableStateOf<List<ProductRow>>(emptyList()) }
    var cart by remember { mutableStateOf<List<CartRow>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun search() {
        if (term.isBlank()) return
        loading = true; message = null
        scope.launch {
            val r = withContext(Dispatchers.IO) { ApiClient.get("products", mapOf("term" to term)) }
            try {
                if (!r.ok) throw IllegalStateException(r.error ?: "Connection failed")
                val a = dataArray(r.body); val list = mutableListOf<ProductRow>()
                for (i in 0 until a.length()) { val o=a.getJSONObject(i); list += ProductRow(o.optInt("id"),o.optString("code"),o.optString("name"),o.optDouble("price"),o.optDouble("quantity")) }
                products=list; if(list.isEmpty()) message="No matching live products found."
            } catch(e:Exception){ message=e.message }
            loading=false
        }
    }

    Scaffold(topBar = { AppBar("Native POS", nav) }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { ConnectionHint() }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(term,{term=it},label={Text("Scan / search product")},modifier=Modifier.weight(1f),singleLine=true)
                    Spacer(Modifier.width(8.dp)); Button(onClick={search()},enabled=!loading){ Icon(Icons.Default.Search,null) }
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            message?.let { m -> item { Text(m, color=MaterialTheme.colorScheme.error) } }
            items(products) { p ->
                Card(onClick={ cart = cart + CartRow(p); message="Added ${p.name}" }, modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)){ Text(p.name,fontWeight=FontWeight.Bold); Text("${p.code} • Stock ${p.quantity}") }
                        Text("₹%.2f".format(p.price),fontWeight=FontWeight.Bold)
                    }
                }
            }
            item { Text("Cart",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold) }
            if(cart.isEmpty()) item { Text("Cart is empty.") }
            items(cart) { c -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp)){ Text("${c.qty} × ${c.product.name}",Modifier.weight(1f)); Text("₹%.2f".format(c.product.price*c.qty)) } } }
            if(cart.isNotEmpty()) item {
                val total=cart.sumOf{it.product.price*it.qty}
                Button(onClick={message="Cart total ₹%.2f. Sale-write API is intentionally not enabled until your existing POS sale transaction is mapped exactly.".format(total)},modifier=Modifier.fillMaxWidth()){Text("Checkout ₹%.2f".format(total))}
            }
        }
    }
}

@Composable
private fun SalesScreen(nav: NavHostController) {
    var rows by remember { mutableStateOf<List<SaleRow>>(emptyList()) }; var loading by remember { mutableStateOf(true) }; var msg by remember { mutableStateOf<String?>(null) }; val scope=rememberCoroutineScope()
    fun load(){ loading=true; msg=null; scope.launch { val r=withContext(Dispatchers.IO){ApiClient.get("sales",mapOf("limit" to "50"))}; try{ if(!r.ok) throw IllegalStateException(r.error?:"Connection failed"); val a=dataArray(r.body); val l=mutableListOf<SaleRow>(); for(i in 0 until a.length()){val o=a.getJSONObject(i);l+=SaleRow(o.optInt("id"),invoiceOf(o),o.optString("customer_name"),o.optString("date"),o.optDouble("grand_total"),o.optDouble("paid"),o.optString("status"))};rows=l;if(l.isEmpty())msg="No sales returned by POS."}catch(e:Exception){msg=e.message};loading=false } }
    LaunchedEffect(Unit){load()}
    Scaffold(topBar={AppBar("Sales",nav)}){pad->LazyColumn(Modifier.padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ConnectionHint();Row{Button(onClick={load()}){Text("Refresh")}}};if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())};msg?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}};items(rows){s->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("#${s.invoice} • ${s.customer}",fontWeight=FontWeight.Bold);Text(s.date);Text("₹%.2f  Paid ₹%.2f  ${s.status}".format(s.total,s.paid))}}}}}
}

@Composable
private fun TrackerScreen(nav: NavHostController) {
    val statuses=listOf("Pending","Cutting","Stitching","Ready","Delivered"); var selected by remember{mutableStateOf("Pending")}; var rows by remember{mutableStateOf<List<TrackerOrder>>(emptyList())}; var loading by remember{mutableStateOf(false)}; var msg by remember{mutableStateOf<String?>(null)}; val scope=rememberCoroutineScope()
    fun load(){loading=true;msg=null;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("tracker",mapOf("status" to selected))};try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);val l=mutableListOf<TrackerOrder>();for(i in 0 until a.length()){val o=a.getJSONObject(i);l+=TrackerOrder(o.optInt("id"),invoiceOf(o),o.optString("customer_name"),o.optString("tailoring_status").ifBlank{selected},o.optString("delivery_date"),o.optInt("tailoring_items"),o.optDouble("grand_total"),o.optDouble("paid"))};rows=l;if(l.isEmpty())msg="No live $selected tailoring orders."}catch(e:Exception){msg=e.message};loading=false}}
    fun move(o:TrackerOrder,next:String){loading=true;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.post("tracker_status",mapOf("sale_id" to o.id.toString(),"status" to next))};if(!r.ok)msg=r.error?:"Update failed" else load();loading=false}}
    LaunchedEffect(selected){load()}
    Scaffold(topBar={AppBar("Tailoring Tracker",nav)}){pad->Column(Modifier.padding(pad)){ScrollableTabRow(selectedTabIndex=statuses.indexOf(selected)){statuses.forEach{s->Tab(selected=selected==s,onClick={selected=s},text={Text(s)})}};LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ConnectionHint()};if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())};msg?.let{item{Text(it,color=if(it.startsWith("No live")) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)}};items(rows){o->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("#${o.invoice} • ${o.customer}",fontWeight=FontWeight.Bold);Text("${o.pieces} alteration pcs • ${o.delivery}");Text("Balance ₹%.2f".format((o.grandTotal-o.paid).coerceAtLeast(0.0)));val idx=statuses.indexOf(o.status);if(idx in 0 until statuses.lastIndex) Button(onClick={move(o,statuses[idx+1])},modifier=Modifier.padding(top=8.dp)){Text("Move to ${statuses[idx+1]}")}}}}}}}
}

@Composable
private fun PurchasesScreen(nav: NavHostController) {
    var rows by remember{mutableStateOf<List<PurchaseRow>>(emptyList())};var loading by remember{mutableStateOf(true)};var msg by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope()
    fun load(){loading=true;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("purchases")};try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);val l=mutableListOf<PurchaseRow>();for(i in 0 until a.length()){val o=a.getJSONObject(i);l+=PurchaseRow(o.optInt("id"),o.optString("date"),o.optString("reference"),o.optString("supplier_name"),o.optDouble("grand_total"),o.optDouble("paid"),o.optString("status"))};rows=l;if(l.isEmpty())msg="No live purchases returned." else msg=null}catch(e:Exception){msg=e.message};loading=false}}
    LaunchedEffect(Unit){load()}
    Scaffold(topBar={AppBar("Purchases",nav)}){pad->LazyColumn(Modifier.padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ConnectionHint();Button(onClick={load()}){Text("Refresh purchases")}};if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())};msg?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}};items(rows){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("#${p.id} ${p.reference}",fontWeight=FontWeight.Bold);Text("${p.supplier} • ${p.date}");Text("₹%.2f • ${p.status}".format(p.total))}}};item{OutlinedButton(onClick={msg="Native purchase creation needs the exact current Purchases controller/model transaction mapped before it is allowed to write stock."},modifier=Modifier.fillMaxWidth()){Text("New Purchase")}}}}
}

@Composable
private fun BarcodeScreen(nav: NavHostController) {
    var text by remember{mutableStateOf("Loading live barcode queue…")};var loading by remember{mutableStateOf(true)};val scope=rememberCoroutineScope();fun load(){loading=true;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("barcode_queue")};text=try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);if(a.length()==0)"Barcode queue is empty." else "${a.length()} live barcode queue rows loaded. 48×30 PDF export will use your existing barcode layout once the write/export endpoint is enabled."}catch(e:Exception){e.message?:"Error"};loading=false}};LaunchedEffect(Unit){load()}
    Scaffold(topBar={AppBar("Barcode Center",nav)}){pad->Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){ConnectionHint();if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());Text(text);Button(onClick={load()}){Text("Refresh queue")};OutlinedButton(onClick={text="No dummy PDF is generated. Native PDF export will be enabled against the real queue after the exact current print_new/barcode payload is mapped."}){Text("Export 48×30 PDF")}}}
}

@Composable
private fun CustomersScreen(nav: NavHostController) {
    var term by remember{mutableStateOf("")};var rows by remember{mutableStateOf<List<CustomerRow>>(emptyList())};var msg by remember{mutableStateOf<String?>(null)};var loading by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();fun search(){if(term.isBlank())return;loading=true;msg=null;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("customers",mapOf("term" to term))};try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);val l=mutableListOf<CustomerRow>();for(i in 0 until a.length()){val o=a.getJSONObject(i);l+=CustomerRow(o.optInt("id"),o.optString("name"),o.optString("phone"),o.optDouble("total_points"))};rows=l;if(l.isEmpty())msg="No matching customers."}catch(e:Exception){msg=e.message};loading=false}}
    Scaffold(topBar={AppBar("Customers",nav)}){pad->LazyColumn(Modifier.padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ConnectionHint();OutlinedTextField(term,{term=it},label={Text("Name / mobile")},modifier=Modifier.fillMaxWidth());Button(onClick={search()},modifier=Modifier.fillMaxWidth()){Text("Search live customers")}};if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())};msg?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}};items(rows){c->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(c.phone);Text("Points ${c.points}")}}}}}
}

@Composable
private fun CreditNotesScreen(nav: NavHostController) {
    var term by remember{mutableStateOf("")};var rows by remember{mutableStateOf<List<CreditNoteRow>>(emptyList())};var msg by remember{mutableStateOf<String?>(null)};var loading by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();fun lookup(){if(term.isBlank())return;loading=true;msg=null;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("credit_note_lookup",mapOf("term" to term))};try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);val l=mutableListOf<CreditNoteRow>();for(i in 0 until a.length()){val o=a.getJSONObject(i);l+=CreditNoteRow(o.optInt("id"),o.optString("credit_note_no"),o.optString("source_invoice_no"),o.optDouble("original_amount"),o.optDouble("used_amount"),o.optDouble("balance"),o.optString("status"),o.optString("expiry_date"))};rows=l;if(l.isEmpty())msg="Credit Note not found or not usable."}catch(e:Exception){msg=e.message};loading=false}}
    Scaffold(topBar={AppBar("Credit Notes",nav)}){pad->LazyColumn(Modifier.padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{ConnectionHint();OutlinedTextField(term,{term=it},label={Text("Scan / enter Credit Note")},modifier=Modifier.fillMaxWidth());Button(onClick={lookup()},modifier=Modifier.fillMaxWidth()){Text("Verify")}};if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())};msg?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}};items(rows){c->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(c.no,fontWeight=FontWeight.Bold);Text("Source ${c.sourceInvoice}");Text("Original ₹%.2f • Used ₹%.2f".format(c.original,c.used));Text("Available ₹%.2f • ${c.status}".format(c.balance),fontWeight=FontWeight.Bold);Text("Expiry ${c.expiry}")}}}}}
}

@Composable
private fun ReportsScreen(nav: NavHostController) {
    var text by remember{mutableStateOf("Loading…")};var loading by remember{mutableStateOf(true)};val scope=rememberCoroutineScope();fun load(){loading=true;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("dashboard")};text=try{if(!r.ok)throw IllegalStateException(r.error?:"Connection failed");val a=dataArray(r.body);val o=a.optJSONObject(0)?:JSONObject();"Today: ${o.optInt("today_sales")} sales\nSales total: ₹%.2f\nPaid: ₹%.2f".format(o.optDouble("today_total"),o.optDouble("today_paid"))}catch(e:Exception){e.message?:"Error"};loading=false}};LaunchedEffect(Unit){load()}
    Scaffold(topBar={AppBar("Reports",nav)}){pad->Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){ConnectionHint();if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());Card(Modifier.fillMaxWidth()){Text(text,Modifier.padding(18.dp),style=MaterialTheme.typography.titleMedium)};Button(onClick={load()}){Text("Refresh")}}}
}

@Composable
private fun SettingsScreen(nav: NavHostController) {
    val context=LocalContext.current;var base by remember{mutableStateOf(ApiClient.baseUrl)};var token by remember{mutableStateOf(ApiClient.bearerToken)};var result by remember{mutableStateOf("Not tested")};var loading by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
    Scaffold(topBar={AppBar("API Settings",nav)}){pad->Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){OutlinedTextField(base,{base=it},label={Text("API base URL")},modifier=Modifier.fillMaxWidth());OutlinedTextField(token,{token=it},label={Text("Bearer token")},modifier=Modifier.fillMaxWidth(),singleLine=true);Button(onClick={ApiClient.save(context,base,token);result="Saved"},modifier=Modifier.fillMaxWidth()){Text("Save")};OutlinedButton(onClick={ApiClient.save(context,base,token);loading=true;scope.launch{val r=withContext(Dispatchers.IO){ApiClient.get("ping",auth=false)};result=if(r.ok)"Connected: ${r.body}" else "Failed: ${r.error ?: r.code}";loading=false}},modifier=Modifier.fillMaxWidth()){Text("Test Connection")};if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());Text(result);Text("Live-data endpoints require a non-empty bearer token. V4 never displays invented tracker/sales/purchase/barcode data.")}}
}
