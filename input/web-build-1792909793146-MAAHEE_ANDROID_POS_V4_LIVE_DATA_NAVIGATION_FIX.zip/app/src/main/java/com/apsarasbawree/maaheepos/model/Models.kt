package com.apsarasbawree.maaheepos.model

data class DashboardTile(val title: String, val subtitle: String, val route: String)
data class ProductRow(val id: Int, val code: String, val name: String, val price: Double, val quantity: Double)
data class CartRow(val product: ProductRow, val qty: Int = 1)
data class TrackerOrder(
    val id: Int,
    val invoice: String,
    val customer: String,
    val status: String,
    val delivery: String,
    val pieces: Int,
    val grandTotal: Double,
    val paid: Double
)
data class SaleRow(val id: Int, val invoice: String, val customer: String, val date: String, val total: Double, val paid: Double, val status: String)
data class CustomerRow(val id: Int, val name: String, val phone: String, val points: Double)
data class PurchaseRow(val id: Int, val date: String, val reference: String, val supplier: String, val total: Double, val paid: Double, val status: String)
data class CreditNoteRow(val id: Int, val no: String, val sourceInvoice: String, val original: Double, val used: Double, val balance: Double, val status: String, val expiry: String)
data class ApiResult(val ok: Boolean, val body: String, val code: Int, val error: String? = null)
