package com.apsarasbawree.maaheepos.data

import android.content.Context
import com.apsarasbawree.maaheepos.model.ApiResult
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object ApiClient {
    var baseUrl: String = "https://pos.apsarasbawree.in/api/v1/"
    var bearerToken: String = "maahee-v4-internal"

    fun load(context: Context) {
        val p = context.getSharedPreferences("maahee_api", Context.MODE_PRIVATE)
        baseUrl = normalizeBase(p.getString("base_url", baseUrl) ?: baseUrl)
        bearerToken = p.getString("token", bearerToken) ?: bearerToken
    }

    fun save(context: Context, base: String, token: String) {
        baseUrl = normalizeBase(base)
        bearerToken = token.trim()
        context.getSharedPreferences("maahee_api", Context.MODE_PRIVATE).edit()
            .putString("base_url", baseUrl)
            .putString("token", bearerToken)
            .apply()
    }

    private fun normalizeBase(v: String): String {
        val s = v.trim()
        return if (s.endsWith('/')) s else "$s/"
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    fun get(path: String, query: Map<String, String> = emptyMap(), auth: Boolean = true): ApiResult {
        val suffix = if (query.isEmpty()) "" else query.entries.joinToString("&", prefix = "?") { "${enc(it.key)}=${enc(it.value)}" }
        return request("GET", path + suffix, null, auth)
    }

    fun post(path: String, form: Map<String, String>, auth: Boolean = true): ApiResult {
        val body = form.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        return request("POST", path, body, auth)
    }

    private fun request(method: String, path: String, body: String?, auth: Boolean): ApiResult {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(baseUrl + path.trimStart('/')).openConnection() as HttpURLConnection
            conn.requestMethod = method
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            if (auth && bearerToken.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $bearerToken")
            if (method == "POST") {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                conn.outputStream.use { it.write((body ?: "").toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            ApiResult(code in 200..299, text, code, if (code in 200..299) null else "HTTP $code")
        } catch (e: Exception) {
            ApiResult(false, "", 0, e.message ?: e.javaClass.simpleName)
        } finally {
            conn?.disconnect()
        }
    }
}
