MAAHEE ANDROID POS V4 - LIVE DATA NAVIGATION FIX
=================================================

WHAT V4 FIXES
-------------
1. Removes all dummy tracker records (Customer A / Customer B etc.).
2. All home modules now open real native screens.
3. Tracker reads only live POS API data.
4. Tracker status can move Pending -> Cutting -> Stitching -> Ready -> Delivered.
5. Sales loads live invoices.
6. POS product search loads live products and lets you add them to a native local cart.
7. Customers searches live POS customers.
8. Credit Notes verifies live Credit Note balance/status.
9. Purchases loads live purchase history.
10. Barcode Center reads the live barcode queue.
11. Reports loads today's live sales totals.
12. Settings can save API URL/token and test connection.

IMPORTANT
---------
This is NOT a WebView. All screens above are native Jetpack Compose screens.

The sale-write/checkout, purchase-write, Bluetooth printing and native PDF write actions remain deliberately blocked until their exact production business transactions are mapped. V4 will show a message instead of silently doing nothing or inserting incorrect data.

API BASE
--------
https://pos.apsarasbawree.in/api/v1/

V4 ships with a non-empty internal test bearer value because the companion API bridge currently accepts any non-empty bearer. Replace this with real token validation before public deployment.

BACKEND REQUIRED
----------------
Upload the companion backend V2 files to YOUR POS paths:

app/controllers/api/V1.php
app/libraries/Maahee_api_auth.php

Do not use application/ on your installation.
