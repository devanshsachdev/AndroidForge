package com.maahee.callerid

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var diagnostic: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        diagnostic = findViewById(R.id.diagnosticText)

        val api = findViewById<EditText>(R.id.apiUrl)
        val token = findViewById<EditText>(R.id.apiToken)
        api.setText(Prefs.apiUrl(this))
        token.setText(Prefs.token(this))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.save(this, api.text.toString(), token.text.toString())
            Toast.makeText(this, "API settings saved", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnScreening).setOnClickListener { requestScreeningRole() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        findViewById<Button>(R.id.btnContacts).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 201)
            } else {
                Toast.makeText(this, "Saved-contact call detection is enabled", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnNotifications).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 202)
            } else {
                Toast.makeText(this, "Notification permission is available", Toast.LENGTH_SHORT).show()
            }
        }
        val bubbleChoice = findViewById<CheckBox>(R.id.startAsBubble)
        bubbleChoice.isChecked = Prefs.startAsBubble(this)
        bubbleChoice.setOnCheckedChangeListener { _, checked ->
            Prefs.saveStartAsBubble(this, checked)
        }
        val notificationSwitch = findViewById<CheckBox>(R.id.backupNotification)
        notificationSwitch.isChecked = Prefs.backupNotification(this)
        notificationSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.saveBackupNotification(this, checked)
        }
        findViewById<Button>(R.id.btnRefreshDiagnostics).setOnClickListener { updateStatus() }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            Prefs.save(this, api.text.toString(), token.text.toString())
            val phone = findViewById<EditText>(R.id.testPhone).text.toString().trim()
            if (phone.isBlank()) Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show()
            else CallerOverlay.showAndLookup(applicationContext, phone)
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }

    @Suppress("DEPRECATION")
    private fun requestScreeningRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 101)
        } else updateStatus()
    }

    private fun updateStatus() {
        if (!::status.isInitialized || !::diagnostic.isInitialized) return
        val roleManager = getSystemService(RoleManager::class.java)
        val screening = roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        val overlay = Settings.canDrawOverlays(this)
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val notices = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "Call Screening: ${if (screening) "ENABLED" else "NOT ENABLED"}\n" +
            "Display over apps: ${if (overlay) "ALLOWED" else "NOT ALLOWED"}\n" +
            "Saved contacts: ${if (contacts) "ALLOWED" else "NOT ALLOWED"}\n" +
            "Notification fallback: ${if (notices) "ALLOWED" else "PERMISSION NEEDED"}\n" +
            "API: ${Prefs.apiUrl(this)}"
        diagnostic.text = "Last incoming callback:\n${CallDiagnostics.lastIncoming(this)}\n\n" +
            "Latest diagnostic event:\n${CallDiagnostics.lastEvent(this)}"
    }
}
