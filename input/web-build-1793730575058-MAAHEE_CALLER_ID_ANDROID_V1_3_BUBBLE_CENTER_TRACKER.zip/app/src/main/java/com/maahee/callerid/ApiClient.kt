package com.maahee.callerid

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.SSLException

/**
 * HTTPS POS lookups only. Does not hold up the CallScreeningService response.
 * Temporary DNS/mobile-data interruptions during ringing are retried in a worker thread.
 */
object ApiClient {
    data class Result(
        val ok: Boolean,
        val json: JSONObject? = null,
        val error: String? = null,
        val retryable: Boolean = false
    )

    fun lookup(context: Context, phone: String): Result {
        var connection: HttpURLConnection? = null
        return try {
            val base = Prefs.apiUrl(context).trim()
            val sep = if (base.contains("?")) "&" else "?"
            val url = URL(base + sep + "phone=" + URLEncoder.encode(phone, "UTF-8"))
            if (!url.protocol.equals("https", true)) {
                return Result(false, error = "Only HTTPS POS API URLs are allowed.")
            }

            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3000
                readTimeout = 3500
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${Prefs.token(context)}")
                setRequestProperty("X-Maahee-Caller", "android-v1.3")
                useCaches = false
            }
            connection = conn
            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val payload = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (status in 200..299) {
                Result(true, JSONObject(payload))
            } else when (status) {
                401, 403 -> Result(false, error = "API token rejected (HTTP $status). Check API settings.")
                429, 500, 502, 503, 504 -> Result(
                    false, error = "POS server temporarily unavailable (HTTP $status).", retryable = true
                )
                else -> Result(false, error = "POS returned HTTP $status: ${payload.take(120)}")
            }
        } catch (e: UnknownHostException) {
            Result(false, error = "DNS unavailable during the call (${NetworkInspector.describe(context)}).", retryable = true)
        } catch (e: SocketTimeoutException) {
            Result(false, error = "POS connection timed out during this call.", retryable = true)
        } catch (e: SSLException) {
            Result(false, error = "Secure connection failed. Check device date/network.")
        } catch (e: IOException) {
            Result(false, error = "Mobile data/Wi-Fi interrupted (${NetworkInspector.describe(context)}).", retryable = true)
        } catch (e: Exception) {
            Result(false, error = e.message?.take(140) ?: e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    fun lookupWithRetry(
        context: Context,
        phone: String,
        isStillNeeded: () -> Boolean,
        onRetry: (attempt: Int, max: Int, reason: String) -> Unit
    ): Result {
        val max = 4
        val delays = longArrayOf(1400L, 2600L, 4200L)
        var last = Result(false, error = "Lookup cancelled.")
        for (attempt in 1..max) {
            if (!isStillNeeded()) return last
            last = lookup(context, phone)
            if (last.ok || !last.retryable || attempt == max) return last
            onRetry(attempt + 1, max, last.error ?: "Waiting for internet")
            try {
                Thread.sleep(delays[attempt - 1])
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return last
            }
        }
        return last
    }
}
