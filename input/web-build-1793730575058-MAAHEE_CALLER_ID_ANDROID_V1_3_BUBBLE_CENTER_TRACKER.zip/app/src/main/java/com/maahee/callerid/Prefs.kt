package com.maahee.callerid

import android.content.Context

object Prefs {
    private const val FILE = "maahee_caller"
    fun apiUrl(c: Context) = c.getSharedPreferences(FILE,0).getString("api_url", BuildConfig.DEFAULT_API_URL) ?: BuildConfig.DEFAULT_API_URL
    fun token(c: Context) = c.getSharedPreferences(FILE,0).getString("token", BuildConfig.DEFAULT_API_TOKEN) ?: BuildConfig.DEFAULT_API_TOKEN
    fun startAsBubble(c: Context) = c.getSharedPreferences(FILE,0).getBoolean("start_as_bubble", false)
    fun saveStartAsBubble(c: Context, enabled: Boolean) = c.getSharedPreferences(FILE,0).edit().putBoolean("start_as_bubble", enabled).apply()
    fun bubbleX(c: Context) = c.getSharedPreferences(FILE,0).getInt("bubble_x", -1)
    fun bubbleY(c: Context) = c.getSharedPreferences(FILE,0).getInt("bubble_y", -1)
    fun saveBubblePosition(c: Context, x: Int, y: Int) =
        c.getSharedPreferences(FILE,0).edit().putInt("bubble_x",x).putInt("bubble_y",y).apply()
    fun backupNotification(c: Context) = c.getSharedPreferences(FILE,0).getBoolean("backup_call_notification", false)
    fun saveBackupNotification(c: Context, enabled: Boolean) = c.getSharedPreferences(FILE,0).edit().putBoolean("backup_call_notification", enabled).apply()
    fun save(c: Context, url:String, token:String) = c.getSharedPreferences(FILE,0).edit().putString("api_url",url.trim()).putString("token",token.trim()).apply()
}
