# Maahee Caller ID — Android V1.3
Native Android Kotlin project (AndroidForge / Android Studio)
Package: com.maahee.callerid | versionCode 3 | minSdk 29 | Store 3 POS

## Changes from V1.2
- Incoming calls open a centered/upper-middle popup by default (like the supplied Samsung screenshot).
- Immediately shows animated "Finding customer..." plus a progress spinner, before POS returns.
- `−` collapses to a draggable Maahee `M` bubble. Tap bubble to reopen centered card.
- Optional "Open as small draggable bubble first" checkbox in the app's main screen.
- Retries transient DNS/network failures four times in a background thread; never delays call screening.
- Displays a clear network error and manual Retry button if the phone loses data while ringing.
- Network diagnostic distinguishes Wi-Fi/mobile data and validated internet.
- Tracker action uses the latest ticket ID (`latest_ticket_id` from API V1.3, or fallback from last 3 sale alterations).
- Tracker dates: three calendar months before NOW through today's date, in Asia/Kolkata timezone.
- Store 3 only and last 3 purchases shown; never reads the whole call log.
- Saved POS API URL and API token remain in existing app preferences when installed as an UPDATE.

## Build via AndroidForge
Upload THIS ZIP (Android code), not the POS API PHP ZIP.
Its top level contains settings.gradle.kts, build.gradle.kts and app/.
Build a debug APK. Install as an update over the existing app to preserve API settings.
If Android says signatures do not match, first copy your API URL/token to a SAFE place,
then uninstall/reinstall and re-enter them. Do not publish the token or ZIP to public GitHub
if you have put tokens into source code (we did not).

## POS API update (separate package)
Upload only the updated:
  app/controllers/api/Caller.php
Keep the installed app/config/caller_api.php AS IS, including its private secret.
New response includes latest_ticket_id and a tracker_url that filters
Store 3 ticket and rolling date range even if the ticket was on an older purchase.

## Tracker URL
If today's date is 2026-11-03 in Asia/Kolkata and latest ticket is D700:
https://pos.maahee.co.in/tracker?start_date=2026-08-03&end_date=2026-11-03&search=D700
Dates update automatically each day.

## Testing
1) Install over V1.2 and keep Call Screening role, Display Over Apps and saved API token.
2) Manual test a customer mobile number with an alteration ticket and tap Tracker.
3) Verify Tracker opens searched ticket with dates.
4) Call the phone normally: the centered popup should appear and animate immediately.
5) Tap `−` to minimize; drag the bubble; tap bubble to expand.
6) Test "Open as small draggable bubble first" if desired.
7) If DNS errors occur only during incoming calls, try Wi-Fi and ensure VoLTE/4G calling
   stays enabled for your SIM. Some mobile networks suspend mobile data while ringing.
   Retries cannot create internet where none exists. Press Retry when available.
8) Android overlay windows cannot be guaranteed above every manufacturer system UI/lock screen.

This package was source/Android XML validated and the PHP controller was PHP-linted.
It was NOT compiled into an APK in this container (Android SDK/Gradle unavailable).
