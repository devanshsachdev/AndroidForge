<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Caller extends CI_Controller
{
    private $store_id = 3;

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper(array('url'));
        $this->config->load('caller_api', TRUE);
        $cfg = $this->config->item('caller_api');
        if (is_array($cfg) && !empty($cfg['caller_api_store_id'])) {
            $this->store_id = (int)$cfg['caller_api_store_id'];
        }
    }

    private function json($data, $status = 200)
    {
        $this->output->set_status_header($status)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    private function bearerToken()
    {
        $header = $this->input->get_request_header('Authorization', TRUE);
        if (!$header && isset($_SERVER['HTTP_AUTHORIZATION'])) $header = $_SERVER['HTTP_AUTHORIZATION'];
        if (preg_match('/Bearer\s+(.*)$/i', (string)$header, $m)) return trim($m[1]);
        return '';
    }

    private function authorized()
    {
        $cfg = $this->config->item('caller_api');
        $expected = is_array($cfg) ? (string)($cfg['caller_api_token'] ?? '') : '';
        $got = $this->bearerToken();
        return $expected !== '' && $got !== '' && hash_equals($expected, $got);
    }

    private function phoneDigits($value)
    {
        $digits = preg_replace('/\D+/', '', (string)$value);
        return strlen($digits) > 10 ? substr($digits, -10) : $digits;
    }

    public function lookup()
    {
        if (!$this->authorized()) return $this->json(array('error'=>'unauthorized'), 401);

        $phone = $this->phoneDigits($this->input->get('phone', TRUE));
        if (strlen($phone) < 7) return $this->json(array('error'=>'invalid_phone'), 400);

        // Find the customer by primary/secondary phone. We compare the last digits
        // so +91 / spaces / dashes do not break a lookup.
        $this->db->select('id,name,phone,phone2,cf1,store_id');
        $this->db->from('customers');
        $this->db->group_start();
        $this->db->like('phone', $phone, 'before');
        if ($this->db->field_exists('phone2', $this->db->dbprefix('customers'))) $this->db->or_like('phone2', $phone, 'before');
        if ($this->db->field_exists('cf1', $this->db->dbprefix('customers'))) $this->db->or_like('cf1', $phone, 'before');
        $this->db->group_end();
        $this->db->limit(10);
        $q = $this->db->get();
        $customer = NULL;
        if ($q && $q->num_rows()) {
            foreach ($q->result() as $row) {
                foreach (array($row->phone ?? '', $row->phone2 ?? '', $row->cf1 ?? '') as $candidate) {
                    if ($this->phoneDigits($candidate) === $phone) { $customer = $row; break 2; }
                }
            }
        }

        // If customer master is not matched, still search Store 3 sales by customer phone join.
        if (!$customer) {
            $this->db->select('customers.id,customers.name,customers.phone,customers.phone2,customers.cf1,customers.store_id');
            $this->db->from('sales');
            $this->db->join('customers','customers.id=sales.customer_id','left');
            $this->db->where('sales.store_id',$this->store_id);
            $this->db->like('customers.phone',$phone,'before');
            $this->db->order_by('sales.id','DESC');
            $this->db->limit(1);
            $qq=$this->db->get();
            if($qq && $qq->num_rows()) $customer=$qq->row();
        }

        if (!$customer) return $this->json(array('found'=>false,'phone'=>$phone,'store_id'=>$this->store_id));

        $this->db->select('sales.id,sales.date,sales.invoice_no,sales.ser_no,sales.grand_total,sales.paid,sales.status,sales.delivery_date,sales.custom_id,sales.tailoring_items,sales.tailoring_status,sales.tailor_top,sales.tailor_pant,sales.tailor_dup,sales.tailor_skirt,sales.tailor_jacket');
        $this->db->from('sales');
        $this->db->where('sales.customer_id',(int)$customer->id);
        $this->db->where('sales.store_id',$this->store_id);
        $this->db->order_by('sales.date','DESC');
        $this->db->order_by('sales.id','DESC');
        $this->db->limit(3);
        $sq=$this->db->get();
        $sales=array();
        if($sq && $sq->num_rows()) {
            foreach($sq->result() as $s) {
                $balance=max(0,(float)$s->grand_total-(float)$s->paid);
                $invoice_no=!empty($s->invoice_no)?$s->invoice_no:(!empty($s->ser_no)?$s->ser_no:(string)$s->id);
                $hasAlter=(int)$s->tailoring_items>0 || !empty($s->custom_id);
                $ticket=!empty($s->custom_id)?$s->custom_id:'';
                $sales[]=array(
                    'sale_id'=>(int)$s->id,
                    'invoice_no'=>(string)$invoice_no,
                    'date'=>$s->date,
                    'date_display'=>$s->date?date('d M Y',strtotime($s->date)):'',
                    'grand_total'=>(float)$s->grand_total,
                    'paid'=>(float)$s->paid,
                    'balance'=>$balance,
                    'payment_status'=>(string)$s->status,
                    'invoice_url'=>site_url('pos/view/'.$s->id),
                    'alteration'=>array(
                        'has_alteration'=>$hasAlter,
                        'ticket_no'=>$ticket,
                        'status'=>$hasAlter?((string)$s->tailoring_status ?: 'Pending'):'',
                        'delivery_date'=>$s->delivery_date,
                        'delivery_date_display'=>($s->delivery_date && $s->delivery_date!='0000-00-00 00:00:00')?date('D, d M Y',strtotime($s->delivery_date)):'',
                        'top'=>(int)$s->tailor_top,
                        'pant'=>(int)$s->tailor_pant,
                        'dupatta'=>(int)$s->tailor_dup,
                        'skirt'=>(int)$s->tailor_skirt,
                        'jacket'=>(int)$s->tailor_jacket
                    )
                );
            }
        }

        $this->json(array(
            'found'=>true,
            'store_id'=>$this->store_id,
            'customer'=>array(
                'id'=>(int)$customer->id,
                'name'=>(string)$customer->name,
                'phone'=>(string)$customer->phone,
                'url'=>site_url('customers/view/'.$customer->id)
            ),
            'recent_sales'=>$sales,
            'latest_invoice_url'=>!empty($sales)?$sales[0]['invoice_url']:'',
            'tracker_url'=>site_url('tracker')
        ));
    }
}
