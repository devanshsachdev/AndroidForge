<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['caller_api_token'] = 'mci_z1feGBoROOWaax5L6rAdKqTkFs_1M5o7TQghvj-D9r0';
$config['caller_api_store_id'] = 3;
