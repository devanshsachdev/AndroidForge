package com.maahee.callerid

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Store dashboard and configuration. Real customer search lives on its own page. */
class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var diagnostic: TextView
    private lateinit var cacheStatus: TextView
    private lateinit var syncDiagnostics: TextView
    private lateinit var api: EditText
    private lateinit var token: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        diagnostic = findViewById(R.id.diagnosticText)
        cacheStatus = findViewById(R.id.cacheStatus)
        syncDiagnostics = findViewById(R.id.syncDiagnostics)
        api = findViewById(R.id.apiUrl)
        token = findViewById(R.id.apiToken)
        api.setText(Prefs.apiUrl(this))
        token.setText(Prefs.token(this))
        syncDiagnostics.text = DirectorySync.diagnostic(this)

        findViewById<Button>(R.id.btnCustomerLookup).setOnClickListener {
            startActivity(Intent(this, CustomerLookupActivity::class.java))
        }
        findViewById<View>(R.id.heroPanel).apply {
            alpha = 0f
            translationY = 18f * resources.displayMetrics.density
            animate().alpha(1f).translationY(0f).setDuration(380L).start()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener { saveConnection() }
        findViewById<Button>(R.id.btnScreening).setOnClickListener { requestScreeningRole() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Caller popup permission is already enabled", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnContacts).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 201)
            else Toast.makeText(this, "Saved phone-contact matching is enabled", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnNotifications).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 202)
            else Toast.makeText(this, "Notification permission is available", Toast.LENGTH_SHORT).show()
        }

        findViewById<CheckBox>(R.id.startAsBubble).apply {
            isChecked = Prefs.startAsBubble(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> Prefs.saveStartAsBubble(this@MainActivity, checked) }
        }
        findViewById<CheckBox>(R.id.backupNotification).apply {
            isChecked = Prefs.backupNotification(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> Prefs.saveBackupNotification(this@MainActivity, checked) }
        }
        findViewById<CheckBox>(R.id.autoWifiSync).apply {
            isChecked = Prefs.autoSync(this@MainActivity)
            if (isChecked) DirectorySyncJob.schedule(applicationContext)
            setOnCheckedChangeListener { _, checked ->
                Prefs.saveAutoSync(this@MainActivity, checked)
                if (checked) DirectorySyncJob.schedule(applicationContext)
                else DirectorySyncJob.cancel(applicationContext)
            }
        }
        findViewById<Button>(R.id.btnProbeSync).setOnClickListener { button ->
            saveConnection(silent = true)
            button.isEnabled = false
            syncDiagnostics.text = "Checking POS sync endpoint…"
            Thread {
                val outcome = DirectorySync.probe(applicationContext)
                runOnUiThread {
                    button.isEnabled = true
                    syncDiagnostics.text = DirectorySync.diagnostic(this)
                    Toast.makeText(this, outcome.message.take(110), Toast.LENGTH_LONG).show()
                }
            }.apply { name = "MaaheeProbe"; start() }
        }
        findViewById<Button>(R.id.btnSyncNow).setOnClickListener { button ->
            saveConnection(silent = true)
            button.isEnabled = false
            cacheStatus.text = "Downloading Store 3 directory…"
            Thread {
                val outcome = DirectorySync.sync(applicationContext) { progress ->
                    runOnUiThread { cacheStatus.text = progress }
                }
                runOnUiThread {
                    button.isEnabled = true
                    syncDiagnostics.text = DirectorySync.diagnostic(this)
                    Toast.makeText(this, outcome.message.take(160), Toast.LENGTH_LONG).show()
                    refreshCacheStatus()
                }
            }.apply { name = "MaaheeManualSync"; start() }
        }
        findViewById<Button>(R.id.btnBatterySettings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Apps > Maahee Caller ID > Battery > Unrestricted", Toast.LENGTH_LONG).show()
            }
        }
        findViewById<Button>(R.id.btnClearCache).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Erase offline customer directory?")
                .setMessage("Saved Store 3 customer numbers, purchase summaries and alteration details will be deleted from this phone. Sync to restore them.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase") { _, _ ->
                    Thread {
                        val error = runCatching { OfflineCache.clear(applicationContext) }.exceptionOrNull()
                        runOnUiThread {
                            refreshCacheStatus()
                            if (error != null) Toast.makeText(this, "Erase failed: ${error.message}", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                }.show()
        }
        val diagnosticsToggleButton = findViewById<Button>(R.id.btnToggleDiagnostics)
        diagnosticsToggleButton.setOnClickListener {
            val panel = findViewById<View>(R.id.diagnosticsPanel)
            val opening = panel.visibility != View.VISIBLE
            panel.visibility = if (opening) View.VISIBLE else View.GONE
            diagnosticsToggleButton.text = if (opening) "Hide call diagnostics" else "Show call diagnostics"
            if (opening) updateStatus()
        }
        findViewById<Button>(R.id.btnRefreshDiagnostics).setOnClickListener { updateStatus() }
        refreshCacheStatus()
        updateStatus()
    }

    private fun saveConnection(silent: Boolean = false) {
        Prefs.save(this, api.text.toString(), token.text.toString())
        if (!silent) Toast.makeText(this, "POS connection settings saved", Toast.LENGTH_SHORT).show()
    }

    private fun refreshCacheStatus() {
        Thread {
            val stats = runCatching { OfflineCache.stats(applicationContext) }.getOrNull()
            val dateFormat = SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault())
            runOnUiThread {
                if (stats == null) {
                    cacheStatus.text = "Could not read offline directory"
                    return@runOnUiThread
                }
                findViewById<TextView>(R.id.countText).text = stats.count.toString()
                findViewById<TextView>(R.id.lastSyncText).text = when {
                    stats.lastSync > 0L -> dateFormat.format(Date(stats.lastSync))
                    stats.lastPartial > 0L -> "Partial copy"
                    else -> "Not synced"
                }
                cacheStatus.text = when {
                    stats.lastSync > 0L -> "${stats.count} saved numbers • Last complete sync ${dateFormat.format(Date(stats.lastSync))}"
                    stats.lastPartial > 0L -> "${stats.count} saved numbers • Last partial download ${dateFormat.format(Date(stats.lastPartial))}"
                    else -> "${stats.count} saved numbers. Sync Store 3 to make search available offline."
                }
            }
        }.apply { name = "MaaheeCacheStatus"; start() }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            updateStatus()
            syncDiagnostics.text = DirectorySync.diagnostic(this)
            refreshCacheStatus()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }

    @Suppress("DEPRECATION")
    private fun requestScreeningRole() {
        val role = getSystemService(RoleManager::class.java)
        if (role.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !role.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            startActivityForResult(role.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 101)
        } else updateStatus()
    }

    private fun updateStatus() {
        if (!::status.isInitialized || !::diagnostic.isInitialized) return
        val role = getSystemService(RoleManager::class.java)
        val enabled = role.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            role.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        val overlay = Settings.canDrawOverlays(this)
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "${if (enabled) "✓" else "○"}  Incoming call identification   ${if (enabled) "Ready" else "Setup needed"}\n" +
            "${if (overlay) "✓" else "○"}  Caller popup permission   ${if (overlay) "Ready" else "Setup needed"}\n" +
            "${if (contacts) "✓" else "○"}  Phone contacts   ${if (contacts) "Allowed" else "Optional"}\n" +
            "${if (notifications) "✓" else "○"}  Backup notifications   ${if (notifications) "Allowed" else "Optional"}"
        diagnostic.text = "Last incoming callback:\n${CallDiagnostics.lastIncoming(this)}\n\n" +
            "Latest diagnostic event:\n${CallDiagnostics.lastEvent(this)}"
    }
}
