# Maahee Caller ID V1

Native Android 10+ caller lookup app for Maahee POS.

## What it does
- Requests Android Call Screening role.
- Requests Display Over Other Apps permission.
- On incoming screened call, immediately allows the call and shows a floating Maahee card.
- Calls `https://pos.maahee.co.in/api/caller/lookup?phone=...`.
- Shows customer + last 3 Store 3 purchases + balance + alteration ticket/status/delivery date.
- Buttons open Customer, latest Invoice and Tracker in the POS.
- No READ_CALL_LOG permission.

## API token setup (important security step)
AndroidForge commits uploaded ZIPs to GitHub. To avoid disclosing your POS API token,
this Android project has an EMPTY default token. After installing the APK:
1. Open the app.
2. Under **API Token**, enter a freshly rotated token from the POS server config
   `app/config/caller_api.php` (the token must match the server).
3. Tap **Save API Settings**.
4. Tap **Test POS Lookup Popup** with a known customer phone number.

If the older Android ZIP with a prefilled token was ever uploaded to GitHub,
rotate that token on the POS server immediately. The old value may remain in commit history.
Never post API tokens in screenshots or public build logs.

## AndroidForge import
Upload the ZIP itself (not the PHP POS API ZIP) to AndroidForge. The Gradle files
are directly at the ZIP root:
`settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`.
The build requires Android SDK 35, Gradle 8.9, JDK 17 and access to Maven/Google dependencies.

## Android limitation
Android's official CallScreeningService documentation says screening callbacks are for numbers not in the user's contacts list. For a guaranteed popup on *all saved contacts too*, a later version would need a more invasive default Phone/Dialer design.

## Build
Open this folder in Android Studio with JDK 17, sync Gradle, then Build > Build APK(s).

## First run
1. Enable Call Screening.
2. Allow Display Over Other Apps.
3. Confirm API URL/token.
4. Use Test POS Lookup Popup with a known customer phone.
5. Make a real incoming call from a number not stored in Contacts.
