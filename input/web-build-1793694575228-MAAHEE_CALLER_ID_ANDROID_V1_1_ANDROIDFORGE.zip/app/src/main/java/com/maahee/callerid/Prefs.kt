package com.maahee.callerid

import android.content.Context

object Prefs {
    private const val FILE = "maahee_caller"
    fun apiUrl(c: Context) = c.getSharedPreferences(FILE,0).getString("api_url", BuildConfig.DEFAULT_API_URL) ?: BuildConfig.DEFAULT_API_URL
    fun token(c: Context) = c.getSharedPreferences(FILE,0).getString("token", BuildConfig.DEFAULT_API_TOKEN) ?: BuildConfig.DEFAULT_API_TOKEN
    fun save(c: Context, url:String, token:String) = c.getSharedPreferences(FILE,0).edit().putString("api_url",url.trim()).putString("token",token.trim()).apply()
}
