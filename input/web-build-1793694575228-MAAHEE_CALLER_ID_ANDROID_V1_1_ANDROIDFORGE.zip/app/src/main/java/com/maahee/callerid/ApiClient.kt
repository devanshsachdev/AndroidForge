package com.maahee.callerid

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object ApiClient {
    data class Result(val ok:Boolean, val json:JSONObject?, val error:String?)
    fun lookup(context: Context, phone:String): Result {
        return try {
            val sep = if (Prefs.apiUrl(context).contains("?")) "&" else "?"
            val url = URL(Prefs.apiUrl(context) + sep + "phone=" + URLEncoder.encode(phone, "UTF-8"))
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2200
                readTimeout = 2600
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${Prefs.token(context)}")
                setRequestProperty("X-Maahee-Caller", "android-v1")
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code in 200..299) Result(true, JSONObject(text), null)
            else Result(false, null, "HTTP $code: ${text.take(180)}")
        } catch (e:Exception) {
            Result(false, null, e.message ?: e.javaClass.simpleName)
        }
    }
}
