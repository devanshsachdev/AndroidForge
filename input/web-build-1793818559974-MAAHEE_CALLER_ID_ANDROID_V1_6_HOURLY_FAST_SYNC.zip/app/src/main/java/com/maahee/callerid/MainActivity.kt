package com.maahee.callerid

import android.Manifest
import android.app.role.RoleManager
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var diagnostic: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        diagnostic = findViewById(R.id.diagnosticText)

        val api = findViewById<EditText>(R.id.apiUrl)
        val token = findViewById<EditText>(R.id.apiToken)
        api.setText(Prefs.apiUrl(this))
        token.setText(Prefs.token(this))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.save(this, api.text.toString(), token.text.toString())
            Toast.makeText(this, "API settings saved", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnScreening).setOnClickListener { requestScreeningRole() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        findViewById<Button>(R.id.btnContacts).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 201)
            } else {
                Toast.makeText(this, "Saved-contact call detection is enabled", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnNotifications).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 202)
            } else {
                Toast.makeText(this, "Notification permission is available", Toast.LENGTH_SHORT).show()
            }
        }
        val bubbleChoice = findViewById<CheckBox>(R.id.startAsBubble)
        bubbleChoice.isChecked = Prefs.startAsBubble(this)
        bubbleChoice.setOnCheckedChangeListener { _, checked ->
            Prefs.saveStartAsBubble(this, checked)
        }
        val notificationSwitch = findViewById<CheckBox>(R.id.backupNotification)
        notificationSwitch.isChecked = Prefs.backupNotification(this)
        notificationSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.saveBackupNotification(this, checked)
        }
        findViewById<Button>(R.id.btnRefreshDiagnostics).setOnClickListener { updateStatus() }
        val cacheStatus = findViewById<TextView>(R.id.cacheStatus)
        fun refreshCacheStatus() {
            Thread {
                val stats = OfflineCache.stats(applicationContext)
                val statusText = if (stats.lastSync > 0L) {
                    val whenSynced = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                        .format(Date(stats.lastSync))
                    "Saved ${stats.count} phone numbers • Last full sync $whenSynced"
                } else if (stats.lastPartial > 0L) {
                    "${stats.count} saved phone numbers • Partial sync ${SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(stats.lastPartial))}"
                } else "No completed directory sync yet • ${stats.count} saved phone numbers"
                runOnUiThread { cacheStatus.text = statusText }
            }.start()
        }
        val syncDiagnostics = findViewById<TextView>(R.id.syncDiagnostics)
        syncDiagnostics.text = DirectorySync.diagnostic(this)
        findViewById<Button>(R.id.btnProbeSync).setOnClickListener { view ->
            (view as Button).isEnabled = false
            Prefs.save(this, api.text.toString(), token.text.toString())
            syncDiagnostics.text = "Checking sync endpoint..."
            Thread {
                val outcome = DirectorySync.probe(applicationContext)
                runOnUiThread {
                    syncDiagnostics.text = DirectorySync.diagnostic(this)
                    view.isEnabled = true
                    Toast.makeText(this, outcome.message.take(100), Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        findViewById<Button>(R.id.btnSaveOne).setOnClickListener { view ->
            Prefs.save(this, api.text.toString(), token.text.toString())
            val phone = findViewById<EditText>(R.id.testPhone).text.toString().trim()
            if (OfflineCache.normalize(phone).isBlank()) {
                Toast.makeText(this, "Enter a valid 10-digit phone", Toast.LENGTH_SHORT).show()
            } else {
                (view as Button).isEnabled = false
                syncDiagnostics.text = "Saving test customer to offline cache..."
                Thread {
                    val result = ApiClient.lookup(applicationContext, phone)
                    val message = when {
                        result.ok && result.json?.optBoolean("found", false) == true -> {
                            try {
                                OfflineCache.remember(applicationContext, phone, result.json!!)
                                "Saved this customer securely for offline incoming calls."
                            } catch (e: Exception) {
                                "Cache write failed: ${e.javaClass.simpleName}: ${e.message}"
                            }
                        }
                        result.ok -> "POS does not have this number in Store 3; no record saved."
                        else -> "POS lookup failed: ${result.error}"
                    }
                    runOnUiThread {
                        syncDiagnostics.text = message
                        view.isEnabled = true
                        refreshCacheStatus()
                    }
                }.start()
            }
        }
        findViewById<Button>(R.id.btnBatterySettings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Settings > Apps > Maahee Caller ID > Battery > Unrestricted", Toast.LENGTH_LONG).show()
            }
        }
        val wifiAuto = findViewById<CheckBox>(R.id.autoWifiSync)
        wifiAuto.isChecked = Prefs.autoSync(this)
        if (Prefs.autoSync(this)) DirectorySyncJob.schedule(applicationContext)
        wifiAuto.setOnCheckedChangeListener { _, enabled ->
            Prefs.saveAutoSync(this, enabled)
            if (enabled) DirectorySyncJob.schedule(applicationContext)
            else DirectorySyncJob.cancel(applicationContext)
        }
        findViewById<Button>(R.id.btnSyncNow).setOnClickListener { button ->
            Prefs.save(this, api.text.toString(), token.text.toString())
            (button as Button).isEnabled = false
            cacheStatus.text = "Connecting to POS for Store 3 directory sync…"
            Thread {
                val outcome = DirectorySync.sync(applicationContext) { progress ->
                    runOnUiThread { cacheStatus.text = progress }
                }
                runOnUiThread {
                    button.isEnabled = true
                    Toast.makeText(this, outcome.message, Toast.LENGTH_LONG).show()
                    refreshCacheStatus()
                    syncDiagnostics.text = DirectorySync.diagnostic(this)
                    if (outcome.ok && Prefs.autoSync(this)) DirectorySyncJob.schedule(applicationContext)
                }
            }.start()
        }
        findViewById<Button>(R.id.btnClearCache).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Erase offline customer directory?")
                .setMessage("This deletes the saved Store 3 caller data from this phone. Future calls will need POS internet access until you sync again.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Erase") { _, _ ->
                    Thread {
                        OfflineCache.clear(applicationContext)
                        runOnUiThread { refreshCacheStatus() }
                    }.start()
                }.show()
        }
        findViewById<Button>(R.id.btnOfflineTest).setOnClickListener {
            val phone = findViewById<EditText>(R.id.testPhone).text.toString().trim()
            if (phone.isBlank()) Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show()
            else CallerOverlay.showAndLookup(applicationContext, phone, offlineOnly = true)
        }
        refreshCacheStatus()
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            Prefs.save(this, api.text.toString(), token.text.toString())
            val phone = findViewById<EditText>(R.id.testPhone).text.toString().trim()
            if (phone.isBlank()) Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show()
            else CallerOverlay.showAndLookup(applicationContext, phone)
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        findViewById<TextView>(R.id.syncDiagnostics)?.text = DirectorySync.diagnostic(this)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }

    @Suppress("DEPRECATION")
    private fun requestScreeningRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 101)
        } else updateStatus()
    }

    private fun updateStatus() {
        if (!::status.isInitialized || !::diagnostic.isInitialized) return
        val roleManager = getSystemService(RoleManager::class.java)
        val screening = roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        val overlay = Settings.canDrawOverlays(this)
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val notices = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "Call Screening: ${if (screening) "ENABLED" else "NOT ENABLED"}\n" +
            "Display over apps: ${if (overlay) "ALLOWED" else "NOT ALLOWED"}\n" +
            "Saved contacts: ${if (contacts) "ALLOWED" else "NOT ALLOWED"}\n" +
            "Notification fallback: ${if (notices) "ALLOWED" else "PERMISSION NEEDED"}\n" +
            "API: ${Prefs.apiUrl(this)}"
        diagnostic.text = "Last incoming callback:\n${CallDiagnostics.lastIncoming(this)}\n\n" +
            "Latest diagnostic event:\n${CallDiagnostics.lastEvent(this)}"
    }
}
