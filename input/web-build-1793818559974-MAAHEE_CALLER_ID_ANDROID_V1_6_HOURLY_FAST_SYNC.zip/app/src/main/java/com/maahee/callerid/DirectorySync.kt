package com.maahee.callerid

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException
import java.net.SocketTimeoutException
import java.util.Locale

/** Sync Store 3 caller data, with actionable HTTP diagnostics and partial commits. */
object DirectorySync {
    data class Outcome(val ok: Boolean, val count: Int, val message: String)
    private const val PAGE_SIZE = 100
    private const val SAVE_EVERY_PAGES = 10
    private const val MAX_PAGES = 3000
    private const val DIAG_FILE = "maahee_caller_sync_diag"

    fun diagnostic(context: Context): String =
        context.getSharedPreferences(DIAG_FILE, Context.MODE_PRIVATE)
            .getString("last", "No sync attempted yet") ?: "No sync attempted yet"

    private fun save(context: Context, message: String) {
        context.getSharedPreferences(DIAG_FILE, Context.MODE_PRIVATE)
            .edit().putString("last", "${java.util.Date()}\n$message").apply()
    }

    private fun base(context: Context): String? {
        val endpoint = Prefs.apiUrl(context).substringBefore('?').trimEnd('/')
        if (!endpoint.startsWith("https://") || !endpoint.endsWith("/api/caller/lookup")) return null
        return endpoint.removeSuffix("/lookup") + "/sync"
    }

    private fun onePage(context: Context, after: Long, size: Int): JSONObject {
        val endpoint = base(context) ?: throw IllegalArgumentException("Use the exact /api/caller/lookup HTTPS URL")
        val token = Prefs.token(context).trim()
        if (token.isBlank()) throw IllegalArgumentException("API token is blank")
        val connection = (URL("$endpoint?after_id=$after&limit=$size")
            .openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8000
            connection.readTimeout = 24000
            connection.useCaches = false
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Accept-Encoding", "gzip")
            connection.setRequestProperty("Authorization", "Bearer $token")
            connection.setRequestProperty("X-Maahee-Caller", "android-v1.5-sync")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val decoded = if (connection.contentEncoding?.contains("gzip", ignoreCase = true) == true && stream != null)
                java.util.zip.GZIPInputStream(stream) else stream
            val body = decoded?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val reason = when (code) {
                    401, 403 -> "Token rejected by POS (HTTP $code)"
                    404 -> "POS /api/caller/sync missing (HTTP 404); install V1.5 PHP controller"
                    500 -> "POS PHP/SQL exception (HTTP 500); check app/logs and server error_log"
                    502, 503, 504 -> "POS server temporarily unavailable (HTTP $code)"
                    else -> "POS sync HTTP $code"
                }
                val brief = body.replace(Regex("<[^>]+>"), " ")
                    .replace(Regex("\\s+"), " ").take(140)
                throw IllegalStateException("$reason. ${brief.trim()}")
            }
            val response = try { JSONObject(body) } catch (_: Exception) {
                throw IllegalStateException("POS returned invalid JSON, possibly a PHP warning: ${body.take(120)}")
            }
            if (response.optInt("store_id", -1) != 3 || response.optString("status") != "success") {
                throw IllegalStateException("Unexpected Store ID or sync API format: ${body.take(150)}")
            }
            if (response.optJSONArray("rows") == null) throw IllegalStateException("Sync returned no rows array")
            return response
        } finally {
            connection.disconnect()
        }
    }

    fun probe(context: Context): Outcome {
        return try {
            val root = onePage(context, 0L, 1)
            val rows = root.getJSONArray("rows").length()
            val msg = "Sync API available • v${root.optString("api_version", "older")} • first page $rows row(s) • more=${root.optBoolean("has_more", false)}"
            save(context, msg)
            Outcome(true, rows, msg)
        } catch (e: Exception) {
            val msg = classify(context, e)
            save(context, msg)
            Outcome(false, 0, msg)
        }
    }

    private fun classify(context: Context, e: Exception): String = when (e) {
        is UnknownHostException -> "DNS failed: POS hostname cannot resolve. ${NetworkInspector.describe(context)}. Try manual sync on Wi-Fi."
        is SocketTimeoutException -> "POS sync timed out. Server may be slow or connection unstable."
        else -> "${e.javaClass.simpleName}: ${e.message?.take(240) ?: "Unknown sync error"}"
    }

    @Synchronized fun sync(context: Context, progress: (String) -> Unit): Outcome {
        val all = JSONObject()
        var after = 0L
        var totalCommitted = 0
        val pending = JSONObject()
        try {
            for (page in 1..MAX_PAGES) {
                progress("Downloading Store 3… page $page • $totalCommitted saved")
                val response = onePage(context, after, PAGE_SIZE)
                val version = response.optString("api_version", "unknown")
                val rows = response.getJSONArray("rows")
                val now = System.currentTimeMillis()
                for (i in 0 until rows.length()) {
                    val row = rows.optJSONObject(i) ?: continue
                    val payload = row.optJSONObject("payload") ?: continue
                    val phones = row.optJSONArray("phones") ?: continue
                    for (j in 0 until phones.length()) {
                        val phone = OfflineCache.normalize(phones.optString(j))
                        if (phone.isBlank()) continue
                        val entry = JSONObject().put("timestamp", now).put("payload", payload)
                        pending.put(phone, entry)
                        all.put(phone, entry)
                    }
                }
                // Batch encrypted writes: rewriting the entire encrypted cache for
                // every tiny page was the largest download-time bottleneck.
                // Periodically checkpoint successful pages so an interrupted sync
                // still provides partially downloaded callers without erasing old data.
                if (page % SAVE_EVERY_PAGES == 0 && pending.length() > 0) {
                    OfflineCache.mergePartialDirectory(context, pending)
                    totalCommitted += pending.length()
                    val keys = pending.keys().asSequence().toList()
                    for (key in keys) pending.remove(key)
                }
                if (Thread.currentThread().isInterrupted) throw InterruptedException("Sync deferred by Android")
                val next = response.optLong("next_after_id", -1L)
                val hasMore = response.optBoolean("has_more", false)
                if (!hasMore) {
                    if (all.length() == 0) {
                        val empty = "POS sync v$version returned 0 Store 3 customer numbers. Verify this store has sales."
                        save(context, empty)
                        return Outcome(false, 0, empty)
                    }
                    OfflineCache.replaceDirectory(context, all)
                    val msg = "Sync complete • ${all.length()} numbers • API v$version. Offline lookup ready."
                    save(context, msg)
                    return Outcome(true, all.length(), msg)
                }
                if (next <= after) throw IllegalStateException("POS sync cursor stalled after page $page")
                after = next
            }
            throw IllegalStateException("Exceeded sync page limit")
        } catch (e: Exception) {
            // Save last incomplete batch on recoverable failures.
            if (pending.length() > 0) {
                try {
                    OfflineCache.mergePartialDirectory(context, pending)
                    totalCommitted += pending.length()
                } catch (_: Exception) { /* preserve original error */ }
            }
            val msg = classify(context, e) + "\nNumbers saved this attempt: $totalCommitted. Earlier cache retained."
            save(context, msg)
            return Outcome(false, totalCommitted, msg)
        }
    }
}
