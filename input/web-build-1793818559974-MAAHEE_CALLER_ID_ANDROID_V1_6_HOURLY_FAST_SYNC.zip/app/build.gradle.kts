plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.maahee.callerid"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.maahee.callerid"
        minSdk = 29
        targetSdk = 35
        versionCode = 6
        versionName = "1.6"
        buildConfigField("String", "DEFAULT_API_URL", "\"https://pos.maahee.co.in/api/caller/lookup\"")
        buildConfigField("String", "DEFAULT_API_TOKEN", "\"\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
