# Maahee Caller ID V1.5 — Sync Repair + Diagnostic

Build this Android ZIP with AndroidForge, **not** the POS API ZIP.

## Install
1. Back up POS file `app/controllers/api/Caller.php`. Replace it with the new V1.5 API file (no changes to `app/config/caller_api.php` or its bearer token).
2. Build Android ZIP in AndroidForge. Install over existing Maahee Caller ID without uninstalling to retain API URL/token and cached data (same signing certificate required).
3. On a connected phone, open Maahee Caller ID and tap **CHECK POS SYNC ENDPOINT**. Read/copy persistent detailed result. It should show API v1.5, Store 3 and first page rows.
4. Tap **SYNC STORE 3 FOR OFFLINE CALLS**; now each successful page is encrypted and saved immediately. Full sync finalizes a coherent new directory.
5. Type a known customer number and tap **SAVE TEST CUSTOMER FOR OFFLINE CALLS**, then **TEST OFFLINE CACHE (NO INTERNET)**. If this succeeds, incoming-call card can work without DNS.
6. Enable Auto-sync if desired. Android schedules best-effort periodic jobs with any network, not just unmetered Wi-Fi. Samsung can defer jobs.

## Diagnostics
- HTTP 401 = wrong API token.
- HTTP 404 = server API controller not updated or route unavailable.
- HTTP 500 = PHP/database error on server; check `app/logs/` and cPanel `error_log`.
- DNS UnknownHost = phone network/DNS; manual cached customer still available after successful online lookup.
- 0 rows = Store 3 data query/phone mismatch.
- Partial sync: the page count and partial saved records are visible; no successful page is discarded by later HTTP errors.

## Security
- POS API must remain protected by bearer token and HTTPS.
- Cache uses app-private Android Keystore AES-256-GCM encrypted files.
- Only Store 3 records are exposed.
- Do not publish server token in GitHub, screenshots or build logs. Rotate the token if it was previously exposed.

Full Gradle build has not been run in this environment. PHP syntax and Android XML are checked during packaging.

## Version 1.6 — faster offline sync & hourly background scheduling
- Default auto-sync is ON for new installations. Existing saved OFF preference is respected.
- Android JobScheduler now has a **1-hour** periodic interval with a 15-minute flex window and **any available network**. The persisted job is restored after restart/app update. Opening the app no longer resets an already-correct hourly job.
- Android may defer work when the app is backgrounded, the device is idle, Samsung places it in Sleeping/Deep Sleeping Apps, or the app is force-stopped. This is **not** a guaranteed 24/7 continuously running service. On Samsung, allow **Settings > Apps > Maahee Caller ID > Battery > Unrestricted**, and exclude from Sleeping/Deep Sleeping Apps. Don't force stop the app.
- Page size changed from **8 to 100** records per HTTP request, with gzip accepted when provided by the POS server. Partial encrypted disk commits happen once per 10 pages instead of every page. A full replacement still occurs only when all pages succeed, retaining the previous full cache after failures.
- After updating, open the app once, verify API token and select **CHECK POS SYNC ENDPOINT**, then perform one manual sync while connected. Hourly jobs are scheduled automatically afterward.
- If the API server imposes a lower page-size limit, it may return fewer rows per request; cursor pagination handles that as long as the server reports `has_more`/`next_after_id` accurately.
- The ZIP contains Android project source, not a signed APK. Build with the same signing key to install over your existing app without losing data.
