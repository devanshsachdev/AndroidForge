# Maahee Phone 2.1.0 — Google Phone-inspired redesign

Application ID remains `com.maahee.callerid`; version code 10. Install with the same signing key to retain existing configuration, customer cache, profiles and notes. Build this source ZIP in AndroidForge. Not an APK.

## Changes
- Main phone screen: search, All/Missed filter, contact avatars, grouped recent numbers, separate call icon, Favorites/Recents/Contacts bottom navigation, raised keypad control, and overflow menu. Tap a number for customer history; long-press for Message, notes, or customer details.
- Overflow > Settings opens a dedicated Phone Settings screen. Default dialer role, call log and calling permissions, contacts, notifications and Android 14+ full-screen setup are kept there. First non-dial launch without the default role opens settings once. Existing advanced POS/overlay settings are under POS connection & offline sync. Customer lookup remains available from overflow and Settings.
- Message opens Android's existing messaging app with an `smsto:` recipient. No SMS permissions, SMS storage, automatic sending, or inbox.
- The native call screen has refreshed visual styling, red decline/end, green answer, and Message when unlocked. Existing call controls, local notes, POS data, and offline sync remain.
- Call recording: Android cellular audio capture requires privileged `CAPTURE_AUDIO_OUTPUT` and `RECORD_AUDIO`. A normal APK cannot acquire the former, including when installed as default dialer. Settings reports support accurately; no Record button is shown without both permissions. On an authorized system build, the recording path uses VOICE_CALL, requires explicit confirmation, stops on disconnect/hold/multiple calls, saves successful output under app-private files, and provides playback/deletion in the number's profile. The recording is local, not uploaded, and is not encrypted by the app beyond Android's app-private storage/device encryption. Firmware may still reject or silence the recording. No microphone-only fallback or accessibility bypass. Inform all participants and obtain permission before recording. The feature is not verified on hardware; do not depend on it for compliance or record keeping.

## Validation
- 29 Kotlin source files parsed by Kotlin PSI without syntax errors.
- 25 pure Kotlin normalization and identity regression checks passed.
- XML and resource reference validation, manifest class checks and archive integrity checked.
- No Android SDK/Gradle build or real-device test available here. The next step is compile in AndroidForge and install on a spare device. Check carrier calls before replacing the store phone dialer.

## Device test checklist
1. Upgrade from V2.0; confirm existing notes, POS settings and cached customers survive.
2. Open home: no permission buttons. Overflow > Settings: complete default phone, notifications, call history, contacts and full-screen incoming call setup.
3. Check incoming/outgoing calls with device locked/unlocked, SIM selection, mute, audio routes, hold, end and emergency routing. Verify original system dialer remains available.
4. Recents All/Missed, Contacts, Favorites, search, keypad entry and incoming call history. Verify recipient in external messaging app; sending is manual.
5. Open detail and lookup with internet, then offline; verify purchases and alterations, notes and sync.
6. Settings > Call recording: ordinary APK should report unavailable. Only on a system-authorized device test explicit consent, actual audible two-sided recording, stop, disconnect, playback and deletion.
