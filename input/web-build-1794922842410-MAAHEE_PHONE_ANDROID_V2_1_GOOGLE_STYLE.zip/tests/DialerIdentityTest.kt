import com.maahee.callerid.DialerIdentity
fun main() {
    val cases = mapOf("9876543210" to "+919876543210", "+91 98765 43210" to "+919876543210", "0091-98765-43210" to "+919876543210", "09876543210" to "+919876543210", "919876543210" to "+919876543210", "९८७६५४३२१०" to "+919876543210", "+44 9876543210" to "+449876543210", "112" to "112", "*123#" to "*123#", "-1" to "", "-2" to "", "private" to "", "" to "")
    cases.forEach { (input,expected) -> check(DialerIdentity.key(input)==expected) { "$input -> ${DialerIdentity.key(input)}" } }
    check(DialerIdentity.posNumber("+44 9876543210")==null)
    check(DialerIdentity.posNumber("112")==null)
    check(DialerIdentity.posNumber("+91 98765 43210")=="9876543210")
    println("Passed ${cases.size+3} dialer identity checks")
}
