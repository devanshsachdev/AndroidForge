package com.maahee.callerid

/** Distinguish international numbers and service codes from the Indian POS directory. */
object DialerIdentity {
    fun key(raw: String): String {
        val value = raw.trim(); if (value in setOf("-1", "-2", "-3", "-4") || value.any { it.isLetter() }) return ""; val d = PhoneNumbers.digits(value)
        if (value.isEmpty() || d.isEmpty()) return ""
        if (value.contains('*') || value.contains('#')) return value.filter { it.isDigit() || it == '*' || it == '#' }
        if (value.startsWith("+")) return "+$d"
        if (d.startsWith("00") && d.length > 10) return "+${d.drop(2)}"
        if (d.length == 10) return "+91$d"
        if (d.length == 12 && d.startsWith("91")) return "+$d"
        if (d.length == 11 && d.startsWith("0")) return "+91${d.drop(1)}"
        return d
    }
    fun posNumber(raw: String): String? = key(raw).takeIf { it.matches(Regex("\\+91[0-9]{10}")) }?.takeLast(10)
}
