package com.maahee.callerid

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.min

/**
 * Incoming call -> upper-center animated card (default).
 * Minimize to a draggable overlay bubble; tap bubble to restore the card.
 * The call is NEVER blocked while the API is fetched.
 */
object CallerOverlay {
    private enum class Mode { CARD, BUBBLE }

    private class LookupSession(val phone: String) {
        @Volatile var requestSerial = 0
        var result: ApiClient.Result? = null
        var loading = true
        var progressText = "Finding customer"
        var offline = false
        var cacheTimestamp = 0L
        var cacheRefreshFailed = false
        var offlineOnly = false
        var localContact: String? = null
        var customerRevealed = false
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var active: LookupSession? = null
    private var currentView: View? = null
    private var windowManager: WindowManager? = null
    private var mode = Mode.CARD

    fun showAndLookup(context: Context, rawPhone: String, offlineOnly: Boolean = false) {
        val app = context.applicationContext
        val phone = rawPhone.trim()
        val masked = CallDiagnostics.mask(phone)
        if (!Settings.canDrawOverlays(app)) {
            CallDiagnostics.event(app, "Popup permission missing")
            if (Prefs.backupNotification(app)) CallNotification.show(app, masked)
            return
        }
        main.post {
            val session = LookupSession(phone).also { it.offlineOnly = offlineOnly }
            active = session
            detachView()
            if (Prefs.startAsBubble(app)) showBubble(app, session) else showCard(app, session)
            CallDiagnostics.event(app, "Caller overlay started (finding customer)")
            if (Prefs.backupNotification(app)) CallNotification.show(app, masked)
            startLookup(app, session)
            main.postDelayed({ if (active === session) closeNow() }, 90000L)
        }
    }

    private fun startLookup(context: Context, session: LookupSession) {
        session.requestSerial++
        val serial = session.requestSerial
        session.loading = session.result == null
        session.progressText = "Finding customer"
        session.cacheRefreshFailed = false
        render(context, session)

        Thread {
            // Optional phone-address-book match is local-only; never uploaded.
            val contactName = LocalContacts.name(context, session.phone)
            main.post {
                if (active === session && session.requestSerial == serial) {
                    session.localContact = contactName
                    render(context, session)
                }
            }
            // Read the on-device encrypted directory BEFORE any HTTP/DNS attempt.
            // This is the key path for incoming calls that temporarily lose data.
            val cached = runCatching { OfflineCache.find(context, session.phone) }.getOrNull()
            if (cached != null) {
                main.post {
                    if (active === session && session.requestSerial == serial) {
                        session.result = ApiClient.Result(true, cached.payload)
                        session.offline = true
                        session.cacheTimestamp = cached.timestamp
                        session.loading = false
                        render(context, session)
                        CallDiagnostics.event(context, "Cached customer found for incoming call")
                    }
                }
            }
            if (session.offlineOnly) {
                if (cached == null) main.post {
                    if (active === session && session.requestSerial == serial) {
                        session.loading = false
                        session.result = ApiClient.Result(false, error = "This number is not in the offline directory. Sync Store 3 first.")
                        render(context, session)
                    }
                }
                return@Thread
            }

            val result = ApiClient.lookupWithRetry(
                context, session.phone,
                { active === session && session.requestSerial == serial },
                { attempt, max, reason ->
                    CallDiagnostics.event(context, "POS network retry $attempt/$max: $reason")
                    main.post {
                        if (active === session && session.requestSerial == serial) {
                            session.progressText = "Connecting to POS (try $attempt/$max)"
                            render(context, session)
                        }
                    }
                }
            )
            if (result.ok && result.json != null) {
                // Cache only confirmed Store 3 lookups; never cache API errors.
                if (result.json.optInt("store_id", 3) == 3 && result.json.optBoolean("found", false)) {
                    runCatching { OfflineCache.remember(context, session.phone, result.json) }
                } else if (!result.json.optBoolean("found", false)) {
                    runCatching { OfflineCache.forget(context, session.phone) }
                }
            }
            main.post {
                if (active === session && session.requestSerial == serial) {
                    session.loading = false
                    if (result.ok || cached == null) {
                        session.result = result
                        session.offline = false
                    } else {
                        // A failed live lookup must NEVER hide previously cached bills.
                        session.cacheRefreshFailed = true
                    }
                    CallDiagnostics.event(context, if (result.ok) "Live POS lookup completed"
                        else if (cached != null) "Offline customer shown while POS was unreachable"
                        else "POS lookup unavailable: ${result.error}")
                    render(context, session)
                }
            }
        }.start()
    }

    private fun addView(context: Context, view: View, params: WindowManager.LayoutParams): Boolean {
        return try {
            val manager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            manager.addView(view, params)
            windowManager = manager
            currentView = view
            true
        } catch (error: Exception) {
            CallDiagnostics.event(context, "Overlay could not open (${error.javaClass.simpleName})")
            if (Prefs.backupNotification(context)) {
                CallNotification.show(context, CallDiagnostics.mask(active?.phone ?: ""))
            }
            false
        }
    }

    private fun newParams(width: Int, gravityValue: Int, xValue: Int, yValue: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = gravityValue
            x = xValue
            y = yValue
        }
    }

    private fun showCard(context: Context, session: LookupSession) {
        if (active !== session) return
        detachView()
        val dm = context.resources.displayMetrics
        val width = min(dp(context, 360), dm.widthPixels - dp(context, 30))
        // Screen upper-center: above the Phone app's accept/decline controls.
        val upperOffset = -(dm.heightPixels * 0.11f).toInt()
        val params = newParams(
            width.coerceAtLeast(dp(context, 220)),
            Gravity.CENTER,
            0,
            upperOffset
        )
        val card = LayoutInflater.from(context).inflate(R.layout.caller_overlay, null)
        card.findViewById<TextView>(R.id.phone).text = session.phone
        card.findViewById<TextView>(R.id.close).setOnClickListener { closeNow() }
        card.findViewById<TextView>(R.id.minimize).setOnClickListener { showBubble(context, session) }
        card.findViewById<Button>(R.id.retryLookup).setOnClickListener { startLookup(context, session) }
        card.findViewById<Button>(R.id.openLookup).setOnClickListener {
            try {
                context.startActivity(Intent(context, CustomerLookupActivity::class.java).apply {
                    putExtra(CustomerLookupActivity.EXTRA_PHONE, session.phone)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                closeNow()
            } catch (_: Exception) {
                Toast.makeText(context, "Unable to open customer lookup", Toast.LENGTH_SHORT).show()
            }
        }

        if (addView(context, card, params)) {
            mode = Mode.CARD
            card.alpha = 0f
            card.scaleX = 0.94f
            card.scaleY = 0.94f
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(230L).start()
            CallDiagnostics.event(context, "Centered caller card displayed")
            render(context, session)
            animateFinding(card, session)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble(context: Context, session: LookupSession) {
        if (active !== session) return
        detachView()
        val dm = context.resources.displayMetrics
        val size = dp(context, 64)
        val initialX = (dm.widthPixels - size - dp(context, 14)).coerceAtLeast(0)
        val initialY = (dm.heightPixels * 0.32f).toInt()
        val x = Prefs.bubbleX(context).takeIf { it >= 0 } ?: initialX
        val y = Prefs.bubbleY(context).takeIf { it >= 0 } ?: initialY
        val params = newParams(size, Gravity.TOP or Gravity.START, x, y)
        params.height = size

        val bubble = LayoutInflater.from(context).inflate(R.layout.caller_bubble, null)
        bubble.isClickable = true
        if (addView(context, bubble, params)) {
            mode = Mode.BUBBLE
            val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
            var downX = 0f
            var downY = 0f
            var originX = 0
            var originY = 0
            var moved = false
            bubble.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        originX = params.x
                        originY = params.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) moved = true
                        if (moved) {
                            params.x = (originX + dx.toInt()).coerceIn(0, (dm.widthPixels - size).coerceAtLeast(0))
                            params.y = (originY + dy.toInt()).coerceIn(dp(context, 24), (dm.heightPixels - size - dp(context, 60)).coerceAtLeast(dp(context, 24)))
                            runCatching { windowManager?.updateViewLayout(bubble, params) }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) Prefs.saveBubblePosition(context, params.x, params.y)
                        else {
                            bubble.performClick()
                            showCard(context, session)
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> false
                }
            }
            render(context, session)
            CallDiagnostics.event(context, "Draggable Maahee bubble displayed")
        }
    }

    private fun animateFinding(card: View, session: LookupSession) {
        val label = card.findViewById<TextView>(R.id.loadingTitle)
        var dots = 0
        val stages = arrayOf(
            "Checking saved numbers", "Finding customer profile",
            "Checking Store 3 purchases", "Finding alterations"
        )
        val task = object : Runnable {
            override fun run() {
                if (active !== session || currentView !== card || !session.loading || mode != Mode.CARD) return
                label.text = (if (session.progressText == "Finding customer")
                    stages[(dots / 2) % stages.size] else session.progressText) + ".".repeat(dots % 4)
                label.alpha = if (dots % 2 == 0) 1f else 0.65f
                dots++
                main.postDelayed(this, 460L)
            }
        }
        main.post(task)
    }

    private fun render(context: Context, session: LookupSession) {
        if (active !== session) return
        val view = currentView ?: return
        if (mode == Mode.BUBBLE) {
            view.findViewById<TextView>(R.id.bubbleStatus)?.text = when {
                session.loading -> "•••"
                session.result?.ok == true -> "✓"
                else -> "!"
            }
            return
        }

        val title = view.findViewById<TextView>(R.id.title)
        val body = view.findViewById<TextView>(R.id.body)
        val loadingText = view.findViewById<TextView>(R.id.loadingTitle)
        val progress = view.findViewById<ProgressBar>(R.id.progress)
        val retry = view.findViewById<Button>(R.id.retryLookup)
        val customerButton = view.findViewById<Button>(R.id.openCustomer)
        val invoiceButton = view.findViewById<Button>(R.id.openInvoice)
        val trackerButton = view.findViewById<Button>(R.id.openTracker)

        customerButton.visibility = View.GONE
        invoiceButton.visibility = View.GONE
        trackerButton.visibility = View.GONE
        retry.visibility = View.GONE

        if (session.loading) {
            title.text = "Maahee Caller"
            progress.visibility = View.VISIBLE
            loadingText.visibility = View.VISIBLE
            loadingText.text = session.progressText
            body.text = if (session.localContact.isNullOrBlank())
                "Securely matching numbers, recent bills and alteration tickets…"
                else "Phone contact: ${session.localContact}\nSearching Store 3 purchases…"
            return
        }

        progress.visibility = View.GONE
        loadingText.visibility = if (session.offline) View.VISIBLE else View.GONE
        if (session.offline) {
            loadingText.text = if (session.offlineOnly) "Saved offline data"
                else if (session.cacheRefreshFailed) "Saved offline • POS not reachable"
                else "Saved offline • checking for updates"
        }
        val result = session.result
        val root = result?.json
        if (result?.ok != true || root == null) {
            title.text = session.localContact?.let { "$it • saved contact" } ?: "Maahee Caller"
            body.text = (if (!session.localContact.isNullOrBlank())
                "Saved on this phone; Store 3 history not yet available.\n\n" else "") +
                (result?.error ?: "POS lookup unavailable") +
                "\n\nIf this happens only during calls, your network may temporarily lose mobile data or DNS while ringing. Try Wi-Fi or enable VoLTE, then tap Retry."
            retry.visibility = View.VISIBLE
            return
        }

        if (!root.optBoolean("found", false)) {
            title.text = session.localContact?.let { "$it • phone contact" } ?: "New / Unknown Caller"
            body.text = "No matching Store 3 purchase history found."
            return
        }

        val customer = root.optJSONObject("customer") ?: JSONObject()
        title.text = customer.optString("name", "Maahee Customer")
        if (!session.customerRevealed) {
            session.customerRevealed = true
            title.alpha = 0f
            title.translationY = dp(context, 7).toFloat()
            title.animate().alpha(1f).translationY(0f).setDuration(330L).start()
        }
        val sales = root.optJSONArray("recent_sales")
        val summary = StringBuilder()
        if (sales == null || sales.length() == 0) {
            summary.append("Customer found • No Store 3 purchases")
        } else {
            for (i in 0 until sales.length()) {
                val sale = sales.optJSONObject(i) ?: continue
                if (summary.isNotEmpty()) summary.append("\n\n")
                summary.append(i + 1).append(". ")
                    .append(sale.optString("date_display", sale.optString("date")))
                    .append("  •  ").append(sale.optString("invoice_no", "#${sale.optInt("sale_id")}"))
                summary.append("\n₹")
                    .append(String.format(Locale.US, "%.2f", sale.optDouble("grand_total", 0.0)))
                val balance = sale.optDouble("balance", 0.0)
                if (balance > 0.005) {
                    summary.append("  • Balance ₹")
                        .append(String.format(Locale.US, "%.2f", balance))
                } else {
                    summary.append("  • PAID")
                }
                val alteration = sale.optJSONObject("alteration")
                if (alteration != null && alteration.optBoolean("has_alteration", false)) {
                    val ticket = alteration.optString("ticket_no", "").trim()
                    summary.append("\n✂ ").append(if (ticket.isBlank()) "Alteration" else ticket)
                    summary.append(" • ").append(alteration.optString("status", "Pending"))
                    val due = alteration.optString("delivery_date_display", "")
                    if (due.isNotBlank()) summary.append(" • ").append(due)
                }
            }
        }

        val latestTicket = findLatestTicket(root)
        if (latestTicket.isNotBlank() && !summary.contains(latestTicket)) {
            summary.append("\n\n✂ Latest ticket: ").append(latestTicket)
        }
        if (session.offline) {
            val stamp = if (session.cacheTimestamp > 0) {
                SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                    .format(java.util.Date(session.cacheTimestamp))
            } else "previous sync"
            summary.insert(0, "OFFLINE COPY • $stamp\nMay be outdated until next sync.\n\n")
        }
        body.text = summary.toString()

        bindButton(context, customerButton, customer.optString("url", ""))
        bindButton(context, invoiceButton, root.optString("latest_invoice_url", ""))
        if (latestTicket.isNotBlank()) {
            bindButton(context, trackerButton, makeTrackerUrl(latestTicket).toString())
        }
    }

    private fun findLatestTicket(root: JSONObject): String {
        fun accepted(value: String): String =
            value.trim().takeIf { it.matches(Regex("[A-Za-z0-9_-]{2,32}")) } ?: ""

        accepted(root.optString("latest_ticket_id", "")).let { if (it.isNotBlank()) return it }
        val sales = root.optJSONArray("recent_sales") ?: return ""
        for (index in 0 until sales.length()) {
            val alteration = sales.optJSONObject(index)?.optJSONObject("alteration") ?: continue
            accepted(alteration.optString("ticket_no", "")).let { if (it.isNotBlank()) return it }
        }
        return ""
    }

    private fun makeTrackerUrl(ticket: String): Uri {
        val tz = TimeZone.getTimeZone("Asia/Kolkata")
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }
        val calendar = Calendar.getInstance(tz)
        val endDate = fmt.format(calendar.time)
        calendar.add(Calendar.MONTH, -3)
        val startDate = fmt.format(calendar.time)
        return Uri.Builder()
            .scheme("https").authority("pos.maahee.co.in").appendPath("tracker")
            .appendQueryParameter("start_date", startDate)
            .appendQueryParameter("end_date", endDate)
            .appendQueryParameter("search", ticket)
            .build()
    }

    private fun bindButton(context: Context, button: Button, url: String) {
        val target = runCatching { Uri.parse(url) }.getOrNull()
        if (target == null || target.scheme != "https" || target.host != "pos.maahee.co.in") return
        button.visibility = View.VISIBLE
        button.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, target)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(context, "Unable to open POS link", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun dp(context: Context, value: Int) =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun detachView() {
        val existing = currentView ?: return
        runCatching { windowManager?.removeViewImmediate(existing) }
        currentView = null
    }

    private fun closeNow() {
        active = null
        detachView()
    }

    fun remove() {
        main.post { closeNow() }
    }
}
