package com.maahee.callerid

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Local, encrypted annotations. Never uploaded to the POS or Android contacts. */
object DialerNotes {
    data class Note(val id: String, val text: String, val time: Long, val callTime: Long)
    data class Profile(val name: String = "", val tag: String = "", val favorite: Boolean = false, val notes: List<Note> = emptyList())
    private const val ALIAS = "maahee_phone_notes_v2"
    private var cached: JSONObject? = null
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS,null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build()); generateKey()
        }
    }
    private fun file(c: Context) = AtomicFile(File(c.filesDir,"maahee_phone_notes_v2.enc"))
    private fun read(c: Context): JSONObject {
        cached?.let { return it }
        val f = file(c); val bytes = try { f.readFully() } catch (e: java.io.FileNotFoundException) { if (f.baseFile.exists()) throw e else return JSONObject().also { cached = it } }
        require(bytes.size >= 29 && bytes[0] == 1.toByte())
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,bytes.copyOfRange(1,13)))
        return JSONObject(String(cipher.doFinal(bytes.copyOfRange(13,bytes.size)),Charsets.UTF_8)).also { cached = it }
    }
    private fun decode(o: JSONObject?): Profile {
        if (o == null) return Profile()
        val a = o.optJSONArray("notes") ?: JSONArray(); val list = (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { Note(it.optString("id"),it.optString("text"),it.optLong("time"),it.optLong("callTime")) } }
        return Profile(o.optString("name"),o.optString("tag"),o.optBoolean("favorite"),list)
    }
    @Synchronized fun profile(c: Context, raw: String) = decode(read(c).optJSONObject(DialerIdentity.key(raw)))
    @Synchronized fun all(c: Context): Map<String,Profile> { val root = read(c); return root.keys().asSequence().associateWith { decode(root.optJSONObject(it)) } }
    @Synchronized fun save(c: Context, raw: String, profile: Profile) {
        val number = DialerIdentity.key(raw); require(number.isNotEmpty()) { "Number is unavailable" }
        val next = JSONObject(read(c).toString()); val a = JSONArray(); profile.notes.forEach { a.put(JSONObject().put("id",it.id).put("text",it.text).put("time",it.time).put("callTime",it.callTime)) }
        next.put(number,JSONObject().put("name",profile.name).put("tag",profile.tag).put("favorite",profile.favorite).put("notes",a))
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key()); val bytes = byteArrayOf(1) + cipher.iv + cipher.doFinal(next.toString().toByteArray(Charsets.UTF_8))
        val f = file(c); val out = f.startWrite(); try { out.write(bytes); f.finishWrite(out); cached = next } catch(e: Exception) { f.failWrite(out); throw e }
    }
}
