package com.maahee.callerid

import android.content.Context
import android.content.Intent
import android.net.Uri

object PhoneActions {
    fun message(c: Context, number: String) {
        val destination=DialerIdentity.key(number)
        if(!destination.matches(Regex("\\+?[0-9]{1,15}"))) { DialerUi.toast(c,"No valid message recipient"); return }
        runCatching { c.startActivity(Intent(Intent.ACTION_SENDTO,Uri.fromParts("smsto",destination,null))) }
            .onFailure { DialerUi.toast(c,"No messaging app is available") }
    }
}
