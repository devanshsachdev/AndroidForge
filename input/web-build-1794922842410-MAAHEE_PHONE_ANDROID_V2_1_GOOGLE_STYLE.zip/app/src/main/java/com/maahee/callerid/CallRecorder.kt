package com.maahee.callerid

import android.Manifest
import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.telecom.Call
import java.io.File

/** System-authorized telephony audio only. No microphone fallback or accessibility workaround. */
object CallRecorder {
    private var recorder:MediaRecorder?=null
    private var owner:Call?=null
    private var pending:File?=null
    private var destination:File?=null
    fun privileged(c:Context)=DialerData.allowed(c,"android.permission.CAPTURE_AUDIO_OUTPUT")
    fun supported(c:Context)=privileged(c)&&DialerData.allowed(c,Manifest.permission.RECORD_AUDIO)
    fun status(c:Context)=when{!privileged(c)->"Unavailable on this installation: Android restricts cellular call audio to privileged system apps.";!supported(c)->"System audio access available. Recording permission is required.";else->"Manual recording available for testing on this firmware. Obtain consent before recording."}
    fun active(call:Call)=owner===call && recorder!=null
    private fun folder(c:Context)=File(c.filesDir,"call_recordings").apply{mkdirs()}
    private fun prefix(phone:String)=java.security.MessageDigest.getInstance("SHA-256").digest(DialerIdentity.key(phone).toByteArray()).joinToString(""){ "%02x".format(it.toInt() and 255) }
    fun files(c:Context,phone:String):List<File> = folder(c).listFiles()?.filter{it.name.startsWith(prefix(phone)+"_") && it.extension=="m4a"}?.sortedByDescending{it.lastModified()}.orEmpty()
    @Suppress("DEPRECATION") fun start(c:Context,call:Call,phone:String):Boolean {
        if(!supported(c)||recorder!=null||call.state!=Call.STATE_ACTIVE||DialerIdentity.key(phone).isBlank())return false
        val base=prefix(phone)+"_"+System.currentTimeMillis();val temp=File(folder(c),"$base.part");val output=File(folder(c),"$base.m4a")
        var m:MediaRecorder?=null
        return try{val instance=if(Build.VERSION.SDK_INT>=31)MediaRecorder(c)else MediaRecorder();m=instance;instance.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);instance.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);instance.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);instance.setOutputFile(temp.absolutePath);instance.prepare();instance.start();recorder=instance;owner=call;pending=temp;destination=output;true}catch(e:Exception){runCatching{m?.release()};temp.delete();false}
    }
    fun stop():Boolean {val r=recorder?:return false;val temp=pending;val output=destination;recorder=null;owner=null;pending=null;destination=null;val ok=runCatching{r.stop()}.isSuccess;runCatching{r.release()};val saved=ok && temp!=null && output!=null && temp.length()>0 && temp.renameTo(output);if(!saved)temp?.delete();return saved}
    fun reconcile(calls:List<Call>){val call=owner?:return;if(calls.size!=1 || call !in calls || call.state!=Call.STATE_ACTIVE)stop()}
}
