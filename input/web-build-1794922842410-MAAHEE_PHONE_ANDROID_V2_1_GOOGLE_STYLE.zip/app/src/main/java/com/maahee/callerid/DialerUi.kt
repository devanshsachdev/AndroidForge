package com.maahee.callerid

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DialerUi {
    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density + .5f).toInt()
    fun column(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
    fun row(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
    fun text(c: Context, value: String, size: Float = 14f, bold: Boolean = false) = TextView(c).apply {
        text = value; textSize = size; setTextColor(c.getColor(R.color.maahee_ink)); if (bold) setTypeface(null, Typeface.BOLD)
    }
    fun button(c: Context, label: String, primary: Boolean = false, action: () -> Unit) = Button(c).apply {
        text = label; isAllCaps = false; textSize = 14f; minHeight = dp(c, 48); minimumHeight = dp(c, 48)
        background=round(c,if(primary)0xff0b57d0.toInt() else 0xffeef1f7.toInt(),26)
        setTextColor(c.getColor(if (primary) R.color.maahee_surface else R.color.maahee_ink)); setOnClickListener { action() }
    }
    fun round(c:Context,color:Int,radius:Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius=dp(c,radius).toFloat() }
    fun pill(c:Context,label:String,selected:Boolean,action:()->Unit)=TextView(c).apply{
        text=label; textSize=14f; gravity=android.view.Gravity.CENTER;minHeight=dp(c,48);val p=dp(c,16);setPadding(p,dp(c,8),p,dp(c,8));background=round(c,if(selected)0xffd3e3fd.toInt() else 0xffeef1f7.toInt(),28);setTextColor(0xff1f1f1f.toInt());setOnClickListener{action()}
    }
    fun avatar(c:Context,name:String)=TextView(c).apply{ text=name.trim().firstOrNull()?.uppercaseChar()?.toString()?:"?";gravity=android.view.Gravity.CENTER;textSize=20f;setTextColor(0xff174ea6.toInt());background=round(c,0xffd3e3fd.toInt(),50) }
    fun icon(c:Context,kind:String,description:String,action:(View)->Unit):View=ImageButton(c).apply{
        val id=when(kind){"phone"->R.drawable.ic_phone;"more"->R.drawable.ic_more;"star"->R.drawable.ic_star;"history"->R.drawable.ic_history;else->R.drawable.ic_person}
        setImageResource(id);setColorFilter(0xff3c4043.toInt());background=round(c,android.graphics.Color.TRANSPARENT,24);layoutParams=LinearLayout.LayoutParams(dp(c,48),dp(c,48));scaleType=ImageView.ScaleType.CENTER;contentDescription=description;setOnClickListener{action(it)}
    }
    fun nav(c:Context,label:String,kind:String,selected:Boolean,action:()->Unit)=column(c).apply{
        gravity=android.view.Gravity.CENTER;val image=ImageView(c).apply{setImageResource(when(kind){"star"->R.drawable.ic_star;"history"->R.drawable.ic_history;else->R.drawable.ic_person});setColorFilter(if(selected)0xff174ea6.toInt() else 0xff5f6368.toInt());scaleType=ImageView.ScaleType.CENTER;background=round(c,if(selected)0xffd3e3fd.toInt() else android.graphics.Color.TRANSPARENT,20)};addView(image,LinearLayout.LayoutParams(dp(c,64),dp(c,34)));addView(text(c,label,12f,selected));setPadding(0,dp(c,4),0,dp(c,4));contentDescription=label;isSelected=selected;setOnClickListener{action()}
    }
    fun LinearLayout.addBlock(view: View, gap: Int = 8) { addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(context, gap) }) }
    fun LinearLayout.addEqual(view: View) { addView(view, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(context, 4) }) }
    fun card(c: Context) = column(c).apply { background=round(c,0xfff1f4f9.toInt(),20); val p = dp(c, 14); setPadding(p,p,p,p) }
    fun root(a: Activity): LinearLayout = column(a).apply {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(a.window, false); setBackgroundColor(0xfffafcff.toInt()); val p = dp(a, 14)
        setPadding(p,p,p,p); ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime())
            v.setPadding(p + bars.left,p + bars.top,p + bars.right,p + bars.bottom); insets
        }; a.setContentView(this); ViewCompat.requestApplyInsets(this)
    }
    fun scroll(parent: LinearLayout): LinearLayout { val c = parent.context; val content = column(c); val sv = ScrollView(c).apply { isFillViewport = true; addView(content) }; parent.addView(sv, LinearLayout.LayoutParams(-1,0,1f)); return content }
    fun date(timestamp: Long) = SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.getDefault()).format(Date(timestamp))
    fun toast(c: Context, s: String) = Toast.makeText(c,s,Toast.LENGTH_SHORT).show()
}
