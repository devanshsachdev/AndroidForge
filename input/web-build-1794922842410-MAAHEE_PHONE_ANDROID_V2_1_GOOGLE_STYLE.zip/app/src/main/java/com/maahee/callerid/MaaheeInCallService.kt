package com.maahee.callerid

import android.app.*
import android.content.*
import android.os.*
import android.telecom.*

/** Android Telecom owns calls. No network operation is needed to answer or disconnect. */
@Suppress("DEPRECATION")
class MaaheeInCallService : InCallService() {
    companion object {
        private var instance: MaaheeInCallService?=null
        fun current()=instance
        const val CHANNEL="maahee_calls_v2"
        const val ONGOING="maahee_ongoing_v2"
        const val ID=7020
        const val ANSWER="com.maahee.callerid.ANSWER"
        const val END="com.maahee.callerid.END"
    }
    private val tracked=LinkedHashMap<Call,Call.Callback>()
    private val ids=LinkedHashMap<Call,Int>(); private var nextId=java.security.SecureRandom().nextInt(500000)+100
    private val listeners=LinkedHashSet<()->Unit>()
    fun listen(f:()->Unit){listeners.add(f)}
    fun unlisten(f:()->Unit){listeners.remove(f)}
    fun all()=tracked.keys.filter{it.state!=Call.STATE_DISCONNECTED && it.state!=Call.STATE_DISCONNECTING}.toList()
    fun primary():Call?=all().let{list->list.firstOrNull{it.state==Call.STATE_RINGING} ?: list.firstOrNull{it.state==Call.STATE_ACTIVE} ?: list.firstOrNull()}
    fun number(call:Call)=call.details.handle?.takeIf{it.scheme=="tel" && call.details.handlePresentation==TelecomManager.PRESENTATION_ALLOWED}?.schemeSpecificPart.orEmpty()
    private var mutedNow=false
    fun isMutedNow()=if(Build.VERSION.SDK_INT>=34) mutedNow else callAudioState?.isMuted==true
    fun mute(){setMuted(!isMutedNow())}
    private var endpoints:List<CallEndpoint> = emptyList()
    private var endpoint:CallEndpoint?=null
    data class AudioOption(val label:String,val choose:()->Unit)
    fun audioOptions():List<AudioOption> {
        if(Build.VERSION.SDK_INT>=34 && endpoints.isNotEmpty()) return endpoints.map { e -> AudioOption(e.endpointName.toString() + if(e==endpoint) " (current)" else "") { requestCallEndpointChange(e,mainExecutor,object:OutcomeReceiver<Void?,CallEndpointException>{override fun onResult(result:Void?){};override fun onError(error:CallEndpointException){DialerUi.toast(this@MaaheeInCallService,"Audio output could not be changed")}}) } }
        val state=callAudioState ?: return emptyList()
        return listOf("Phone" to CallAudioState.ROUTE_EARPIECE,"Speaker" to CallAudioState.ROUTE_SPEAKER,"Bluetooth" to CallAudioState.ROUTE_BLUETOOTH,"Wired headset" to CallAudioState.ROUTE_WIRED_HEADSET).filter{state.supportedRouteMask and it.second != 0}.map { (name,route) -> AudioOption(name+if(state.route==route) " (current)" else ""){setAudioRoute(route)} }
    }
    @androidx.annotation.RequiresApi(34) override fun onCallEndpointChanged(callEndpoint:CallEndpoint){super.onCallEndpointChanged(callEndpoint);endpoint=callEndpoint;listeners.toList().forEach{it()}}
    @androidx.annotation.RequiresApi(34) override fun onAvailableCallEndpointsChanged(availableEndpoints:List<CallEndpoint>){super.onAvailableCallEndpointsChanged(availableEndpoints);endpoints=availableEndpoints.toList();listeners.toList().forEach{it()}}
    @androidx.annotation.RequiresApi(34) override fun onMuteStateChanged(isMuted:Boolean){super.onMuteStateChanged(isMuted);mutedNow=isMuted;listeners.toList().forEach{it()}}
    override fun onCreate(){super.onCreate();instance=this;val nm=getSystemService(NotificationManager::class.java) ?: return;nm.createNotificationChannel(NotificationChannel(CHANNEL,"Incoming phone calls",NotificationManager.IMPORTANCE_HIGH).apply{setSound(null,null);lockscreenVisibility=Notification.VISIBILITY_PRIVATE});nm.createNotificationChannel(NotificationChannel(ONGOING,"Ongoing phone calls",NotificationManager.IMPORTANCE_LOW))}
    override fun onCallAdded(call:Call){super.onCallAdded(call);instance=this; val cb=object:Call.Callback(){override fun onStateChanged(call:Call,state:Int){changed()};override fun onDetailsChanged(call:Call,details:Call.Details){changed()};override fun onConferenceableCallsChanged(call:Call,conferenceableCalls:MutableList<Call>){changed()}};tracked[call]=cb;ids[call]=nextId++;call.registerCallback(cb,Handler(Looper.getMainLooper()));changed(); if(call.state!=Call.STATE_RINGING || !fullScreenAvailable()) open() }
    override fun onCallRemoved(call:Call){tracked.remove(call)?.let{call.unregisterCallback(it)};ids.remove(call);changed();super.onCallRemoved(call)}
    override fun onCallAudioStateChanged(audioState:CallAudioState?){super.onCallAudioStateChanged(audioState);listeners.toList().forEach{it()}}
    override fun onBringToForeground(showDialpad:Boolean){super.onBringToForeground(showDialpad);open()}
    private fun open(){runCatching{startActivity(Intent(this,DialerCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP))}}
    private fun fullScreenAvailable():Boolean { val nm=getSystemService(NotificationManager::class.java) ?: return false; return nm.areNotificationsEnabled() && nm.getNotificationChannel(CHANNEL)?.importance != NotificationManager.IMPORTANCE_NONE && (Build.VERSION.SDK_INT<34 || nm.canUseFullScreenIntent()) }
    private fun changed(){CallRecorder.reconcile(all());notifyCall();listeners.toList().forEach{it()}}
    private fun action(call:Call,what:String):PendingIntent{val id=ids[call]?:0;return PendingIntent.getBroadcast(this,id*2+if(what==ANSWER)0 else 1,Intent(this,DialerCallActionReceiver::class.java).setAction(what).putExtra("callId",id),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)}
    fun perform(id:Int,action:String?){val c=ids.entries.firstOrNull{it.value==id}?.key?:return; when(action){ANSWER->if(c.state==Call.STATE_RINGING)c.answer(VideoProfile.STATE_AUDIO_ONLY);END->if(c.state==Call.STATE_RINGING)c.reject(false,null)else c.disconnect()}}
    fun refreshNotification(){notifyCall()}
    private fun notifyCall(){val nm=getSystemService(NotificationManager::class.java) ?: return;val c=primary();if(c==null){nm.cancel(ID);return}; val ringing=c.state==Call.STATE_RINGING
        val launch=PendingIntent.getActivity(this,0,Intent(this,DialerCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b=Notification.Builder(this,if(ringing)CHANNEL else ONGOING).setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(if(ringing)"Incoming call" else if(CallRecorder.active(c)) "Recording · Maahee Phone" else "Maahee Phone · Call in progress").setContentText(number(c).ifBlank{"Private number"}).setContentIntent(launch).setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(true).setOnlyAlertOnce(true)
        if(Build.VERSION.SDK_INT>=31){val person=Person.Builder().setName(number(c).ifBlank{"Private number"}).setImportant(true).build();b.setStyle(if(ringing)Notification.CallStyle.forIncomingCall(person,action(c,END),action(c,ANSWER)) else Notification.CallStyle.forOngoingCall(person,action(c,END)))}else{b.addAction(Notification.Action.Builder(null,if(ringing)"Decline" else "End",action(c,END)).build());if(ringing)b.addAction(Notification.Action.Builder(null,"Answer",action(c,ANSWER)).build())}
        if(ringing)b.setFullScreenIntent(launch,true)
        runCatching{nm.notify(ID,b.build())}
    }
    override fun onDestroy(){CallRecorder.stop();tracked.forEach{(c,cb)->c.unregisterCallback(cb)};tracked.clear();ids.clear();getSystemService(NotificationManager::class.java)?.cancel(ID);listeners.toList().forEach{it()};listeners.clear();if(instance===this)instance=null;super.onDestroy()}
}
class DialerCallActionReceiver: BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){MaaheeInCallService.current()?.perform(intent.getIntExtra("callId",-1),intent.action)}}
