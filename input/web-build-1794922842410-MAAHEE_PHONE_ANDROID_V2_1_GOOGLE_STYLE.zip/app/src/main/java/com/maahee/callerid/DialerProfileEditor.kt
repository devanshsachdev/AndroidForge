package com.maahee.callerid

import android.app.Activity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.maahee.callerid.DialerUi.addBlock

object DialerProfileEditor {
    fun show(a: Activity, phone: String, callTime: Long = 0L, onSaved: () -> Unit) {
        if (DialerIdentity.key(phone).isEmpty()) { DialerUi.toast(a,"Private numbers cannot be marked"); return }
        val old = runCatching { DialerNotes.profile(a,phone) }.getOrElse { DialerUi.toast(a,"Cannot open encrypted notes"); return }
        val form = DialerUi.column(a).apply { val p = DialerUi.dp(a,18); setPadding(p,0,p,0) }
        val name = EditText(a).apply { hint = "Custom caller name"; setSingleLine(true); setText(old.name) }
        val tags = listOf("", "Customer", "Alteration", "Follow up", "Order enquiry", "Payment", "Supplier", "Personal", "Other")
        val tag = Spinner(a).apply { adapter = ArrayAdapter(a,android.R.layout.simple_spinner_dropdown_item,tags.map { it.ifBlank { "No category" } }); setSelection(tags.indexOf(old.tag).coerceAtLeast(0)) }
        val favorite = CheckBox(a).apply { text = "Add to favorites"; isChecked = old.favorite }
        val note = EditText(a).apply { hint = "Add a new call note (optional)"; minLines = 3; maxLines = 6; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        form.addBlock(name); form.addBlock(tag); form.addBlock(favorite); form.addBlock(note)
        val scroll = ScrollView(a).apply { addView(form) }
        val dialog = AlertDialog.Builder(a).setTitle("Mark caller · $phone").setView(scroll).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val value = note.text.toString().trim(); val latest = runCatching { DialerNotes.profile(a,phone) }.getOrElse { DialerUi.toast(a,"Cannot read notes"); return@setOnClickListener }
            val next = latest.copy(name = name.text.toString().trim().take(120), tag = tags[tag.selectedItemPosition], favorite = favorite.isChecked,
                notes = if (value.isEmpty()) latest.notes else latest.notes + DialerNotes.Note(java.util.UUID.randomUUID().toString(),value.take(4000),System.currentTimeMillis(),callTime))
            runCatching { DialerNotes.save(a,phone,next) }.onSuccess { dialog.dismiss(); onSaved() }.onFailure { DialerUi.toast(a,"Could not save encrypted notes") }
        } }; dialog.show()
    }
}
