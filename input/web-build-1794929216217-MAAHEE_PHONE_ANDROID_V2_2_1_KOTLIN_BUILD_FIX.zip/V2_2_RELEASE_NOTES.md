# Maahee Phone 2.2.0 (versionCode 11)

Upgrade from V2.1 using the same signing key. Application ID and local encrypted caller notes, POS configuration, offline cache and existing recording paths are unchanged.

## Changes
- Service-owned Android proximity wake lock (WAKE_LOCK permission). Active only while dialing/connecting/connected via the earpiece, disabled on speaker/headset/Bluetooth or call termination; no manual runtime permission required. Hardware/firmware support required.
- One-tap Speaker / Speaker on button on the live call screen. Uses Android 14+ endpoint selection and legacy route API for older releases. Separate Audio route menu retained.
- Incoming and outgoing call header resolves custom caller name, offline/live POS name or contact name, followed by up to 64 characters of the latest note (or category). Recents uses the same label. Notes are kept separate and encrypted; the lock screen hides private names/notes. No phone contacts or POS records are overwritten.
- Optional automatic recording in Phone settings on system-authorized devices. Default off. Obtain applicable notice/consent before calls. Attempts recording once per eligible connected single-party call; excludes private numbers, emergency or short/service numbers, unsupported installations, and multiple/conference calls. Stops on hold, conference/multiple calls or disconnect; does not restart automatically after manual stop. Manual recording retains consent confirmation. A visible in-call and notification recording indicator is provided.
- Completed recordings stay in app-private local storage (no age-based deletion); global Call recordings entry in menu and settings, with playback and deliberate deletion. Existing per-number playback remains. The global library identifies recordings by timestamp, not number; hashed per-number filenames preserve existing storage layout. An interrupted or very short recording may fail to finalize. Uninstall/clear app data removes recordings; they are not backed up or uploaded. Standard APK installation cannot obtain the privileged CAPTURE_AUDIO_OUTPUT permission required for VOICE_CALL recording.

## Validation and limitations
31 Kotlin app files parsed with Kotlin PSI (syntax only); 25 pure JVM phone/identity tests passed; 23 XML files parsed. No Android SDK or Gradle build environment is available here. The supplied CI error was a final exit-code message, not the actual compiler diagnostic. This release is not a verified fix for that unknown compiler error. If CI fails again, provide the first `e: file...` / `What went wrong` lines from the AndroidForge diagnosis or the full AndroidForge-logs artifact.

## Device checks
1. Install with same certificate and select Maahee Phone as default dialer in Settings.
2. Answer and place a call: on earpiece, cover sensor and confirm screen off, uncover and confirm on; toggle speaker while sensor uncovered, confirm screen stays on when covered. Verify wired/Bluetooth routes and end call.
3. Make a note, then dial or receive a call from same number; confirm latest note appears after name when unlocked and remains hidden when locked. Confirm customer profile and POS history still open.
4. Check Settings > Call recording availability. If compatible, obtain consent and enable automatic recording, make a single non-emergency call, confirm recording indicator then verify playable audio in Call recordings after hangup, and test retention across relaunch. Normal APKs will report unavailable.
5. Verify original default phone can be restored and test on spare device before store deployment.
