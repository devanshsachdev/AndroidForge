package com.maahee.callerid

import android.content.Context
import android.os.PowerManager

/** Hold the hardware proximity wake lock only during an earpiece call. */
class ProximityController(context: Context) {
    private val lock: PowerManager.WakeLock? = runCatching {
        val power = context.getSystemService(PowerManager::class.java)
        if (power != null && power.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            power.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "MaaheePhone:CallProximity").apply { setReferenceCounted(false) }
        } else null
    }.getOrNull()

    fun update(enabled: Boolean) {
        val current = lock ?: return
        runCatching {
            if (enabled && !current.isHeld) current.acquire()
            else if (!enabled && current.isHeld) current.release()
        }
    }

    fun close() = update(false)
}
