package com.maahee.callerid

import android.os.Bundle
import android.media.MediaPlayer
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual

class RecordingLibraryActivity : AppCompatActivity() {
    private lateinit var body:LinearLayout
    private var player:MediaPlayer?=null
    override fun onCreate(state:Bundle?) {
        super.onCreate(state)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        val root=DialerUi.root(this)
        root.addBlock(DialerUi.button(this,"‹ Back"){finish()})
        root.addBlock(DialerUi.text(this,"Call recordings",26f,true))
        root.addBlock(DialerUi.button(this,"Stop playback"){stop()})
        body=DialerUi.scroll(root)
    }
    override fun onResume(){super.onResume();render()}
    override fun onPause(){stop();super.onPause()}
    private fun stop(){runCatching{player?.release()};player=null}
    private fun render(){
        body.removeAllViews()
        val files=CallRecorder.allFiles(this)
        body.addBlock(DialerUi.text(this,"${files.size} saved recordings · Private device storage"))
        if(files.isEmpty())body.addBlock(DialerUi.text(this,"No recordings saved. Recording requires system-authorized call audio."))
        files.forEach { file ->
            val card=DialerUi.card(this)
            card.addBlock(DialerUi.text(this,DialerUi.date(file.lastModified()),16f,true))
            card.addBlock(DialerUi.text(this,"${file.length()/1024} KB"))
            val row=DialerUi.row(this)
            row.addEqual(DialerUi.button(this,"Play"){stop();runCatching{val m=MediaPlayer();player=m;m.setDataSource(file.absolutePath);m.prepare();m.setOnCompletionListener{stop()};m.start()}.onFailure{stop();DialerUi.toast(this,"Unable to play recording")}})
            row.addEqual(DialerUi.button(this,"Delete"){AlertDialog.Builder(this).setMessage("Permanently delete this recording?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->stop();if(file.delete())render()else DialerUi.toast(this,"Unable to delete recording")}.show()})
            card.addBlock(row);body.addBlock(card)
        }
    }
}
