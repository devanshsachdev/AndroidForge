package com.maahee.callerid

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract
import android.Manifest
import android.content.pm.PackageManager

object DialerData {
    data class Log(val id: Long, val number: String, val name: String, val date: Long, val duration: Long, val type: Int) {
        fun typeLabel() = when(type) { CallLog.Calls.INCOMING_TYPE -> "Incoming"; CallLog.Calls.OUTGOING_TYPE -> "Outgoing"; CallLog.Calls.MISSED_TYPE -> "Missed"; CallLog.Calls.REJECTED_TYPE -> "Rejected"; CallLog.Calls.BLOCKED_TYPE -> "Blocked"; CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"; else -> "Call" }
    }
    data class Contact(val number: String, val name: String)
    fun allowed(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun logs(c: Context, number: String? = null, limit: Int = 500): List<Log> {
        if (!allowed(c,Manifest.permission.READ_CALL_LOG)) return emptyList()
        val cols = arrayOf(CallLog.Calls._ID,CallLog.Calls.NUMBER,CallLog.Calls.CACHED_NAME,CallLog.Calls.DATE,CallLog.Calls.DURATION,CallLog.Calls.TYPE,CallLog.Calls.NUMBER_PRESENTATION)
        val key = number?.let { DialerIdentity.key(it) }; val result = mutableListOf<Log>()
        c.contentResolver.query(CallLog.Calls.CONTENT_URI,cols,null,null,"${CallLog.Calls.DATE} DESC")?.use { cur ->
            while (cur.moveToNext() && result.size < limit) {
                val phone = if(cur.getInt(6)==CallLog.Calls.PRESENTATION_ALLOWED) cur.getString(1).orEmpty() else ""; if (key != null && (key.isEmpty() || DialerIdentity.key(phone) != key)) continue
                result += Log(cur.getLong(0),phone,cur.getString(2).orEmpty(),cur.getLong(3),cur.getLong(4),cur.getInt(5))
            }
        }; return result
    }
    fun contacts(c: Context): List<Contact> {
        if (!allowed(c,Manifest.permission.READ_CONTACTS)) return emptyList()
        val result = mutableListOf<Contact>()
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),null,null,"${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC")?.use { cur ->
            while(cur.moveToNext()) { val n = cur.getString(0).orEmpty(); if (n.isNotBlank()) result += Contact(n,cur.getString(1).orEmpty()) }
        }; return result.distinctBy { DialerIdentity.key(it.number) to it.name }
    }
    fun name(c: Context, phone: String, fallback: String = ""): String {
        val profile = runCatching { DialerNotes.profile(c,phone) }.getOrNull()
        if (!profile?.name.isNullOrBlank()) return profile!!.name
        val cached = DialerIdentity.posNumber(phone)?.let { runCatching { OfflineCache.find(c,it) }.getOrNull() }
        if (cached != null) return CustomerPresentation.name(cached.payload)
        return fallback.takeIf { it.isNotBlank() } ?: LocalContacts.name(c,phone) ?: phone.ifBlank { "Private number" }
    }
    /** Keep the saved base name intact; append a short latest-note preview for the call UI. */
    fun callLabel(c: Context, phone: String, fallback: String = ""): String {
        val base = name(c, phone, fallback)
        val profile = runCatching { DialerNotes.profile(c,phone) }.getOrNull()
        val summary = profile?.notes?.filter { it.text.isNotBlank() }?.maxByOrNull { it.time }?.text
            ?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
        val snippet = if (summary.length > 64) summary.take(61) + "…" else summary
        return if (snippet.isNotEmpty()) "$base · $snippet" else if (!profile?.tag.isNullOrBlank()) "$base · ${profile?.tag}" else base
    }
}
