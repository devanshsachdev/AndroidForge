package com.maahee.callerid

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.maahee.callerid.DialerUi.addBlock
import com.maahee.callerid.DialerUi.addEqual

class DialerActivity : AppCompatActivity() {
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private lateinit var live: Button
    private var tab = "Recents"
    private var request = 0
    private val delayedSearch = Runnable { refresh() }
    private var observing = false
    private val handler = Handler(Looper.getMainLooper())
    private val observer = object : ContentObserver(handler) { override fun onChange(selfChange: Boolean) { if(tab == "Recents") refresh() } }
    private lateinit var navigation: LinearLayout
    private lateinit var heading: TextView
    private lateinit var keypadButton: TextView
    private var previousTab = "Recents"
    private var missedOnly = false
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = DialerUi.root(this).apply{isFocusableInTouchMode=true;requestFocus()}
        val bar = DialerUi.row(this)
        search = EditText(this).apply { hint = "Search name or number"; setSingleLine(true); textSize = 16f; background = DialerUi.round(this@DialerActivity,0xffeef1f7.toInt(),28); val p=DialerUi.dp(this@DialerActivity,16); setPadding(p,p,p,p) }
        bar.addView(search,LinearLayout.LayoutParams(0,-2,1f))
        bar.addView(DialerUi.icon(this,"more","More options") { menu(it) })
        root.addBlock(bar,12)
        live = DialerUi.button(this,"Return to active call",true) { startActivity(Intent(this,DialerCallActivity::class.java)) }; root.addBlock(live)
        live.visibility=View.GONE
        heading=DialerUi.text(this,"Recents",28f,false); root.addBlock(heading,8)
        body = DialerUi.scroll(root)
        val floater=DialerUi.row(this).apply { gravity=android.view.Gravity.END }
        keypadButton=DialerUi.pill(this,"Keypad",true){ if(tab=="Keypad") changeTab(previousTab) else changeTab("Keypad") }; floater.addView(keypadButton); root.addBlock(floater,8)
        navigation=DialerUi.row(this); root.addBlock(navigation,0)
        search.addTextChangedListener(object: TextWatcher { override fun beforeTextChanged(s: CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){ if(tab != "Keypad") { request++; handler.removeCallbacks(delayedSearch); handler.postDelayed(delayedSearch, 220L) } }; override fun afterTextChanged(s:Editable?){} })
        previousTab=state?.getString("previousTab") ?: "Recents"
        missedOnly=state?.getBoolean("missedOnly") ?: false
        changeTab(state?.getString("tab") ?: if(intent.action == Intent.ACTION_DIAL) "Keypad" else "Recents")
        if(intent.action == Intent.ACTION_DIAL) applyDialIntent(intent)
        else if(!roleHeld() && !getPreferences(MODE_PRIVATE).getBoolean("setupSeen",false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("setupSeen",true).apply(); setup()
        }
        if(Prefs.autoSync(this)) DirectorySyncJob.schedule(applicationContext)
    }
    private fun menu(anchor:View){ PopupMenu(this,anchor).apply {
        menu.add("Customer lookup").setOnMenuItemClickListener { startActivity(Intent(this@DialerActivity,CustomerLookupActivity::class.java));true }
        menu.add("Call recordings").setOnMenuItemClickListener { startActivity(Intent(this@DialerActivity,RecordingLibraryActivity::class.java));true }
        menu.add("Settings").setOnMenuItemClickListener { setup();true }; show()
    } }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); if(intent.action == Intent.ACTION_DIAL) applyDialIntent(intent) }
    override fun onSaveInstanceState(outState: Bundle) { outState.putString("tab",tab);outState.putString("previousTab",previousTab);outState.putBoolean("missedOnly",missedOnly); super.onSaveInstanceState(outState) }
    private fun applyDialIntent(i: Intent) { changeTab("Keypad"); if(i.data?.scheme == "tel") keypadInput?.setText(i.data?.schemeSpecificPart.orEmpty()) }
    override fun onResume() { super.onResume(); live.visibility = if(MaaheeInCallService.current()?.primary() != null) View.VISIBLE else View.GONE; if(DialerData.allowed(this,Manifest.permission.READ_CALL_LOG) && !observing) { runCatching { contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI,true,observer); observing = true } }; if(tab != "Keypad") refresh() }
    override fun onPause() { if(observing){ contentResolver.unregisterContentObserver(observer); observing=false }; super.onPause() }
    override fun onDestroy(){ request++; handler.removeCallbacksAndMessages(null); super.onDestroy() }
    private fun roleHeld() = getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_DIALER) == true
    private fun setup(){startActivity(Intent(this,PhoneSettingsActivity::class.java))}
    private fun changeTab(value:String){
        if(value=="Keypad" && tab!="Keypad") previousTab=tab else if(value!="Keypad") previousTab=value
        tab=value; search.visibility=if(value=="Keypad") View.GONE else View.VISIBLE; if(value=="Keypad"){search.clearFocus();(getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.hideSoftInputFromWindow(search.windowToken,0)}; request++
        heading.text=value; keypadButton.text=if(value=="Keypad") "Close keypad" else "Keypad"
        navigation.removeAllViews()
        listOf("Favorites" to "star","Recents" to "history","Contacts" to "person").forEach { (label,icon) ->
            val selected=label==value || (value=="Keypad" && label==previousTab)
            navigation.addView(DialerUi.nav(this,label,icon,selected){changeTab(label)},LinearLayout.LayoutParams(0,-2,1f))
        }
        if(value=="Keypad") keypad() else refresh()
    }
    private data class Row(val number:String,val title:String,val description:String,val date:Long=0L,val tag:String="",val missed:Boolean=false)
    private fun refresh(){
        if(!::body.isInitialized || tab=="Keypad") return
        val serial=++request; val selected=tab; val term=search.text.toString().trim(); val c=applicationContext; val filterMissed=missedOnly && selected=="Recents"
        body.removeAllViews(); filters(selected)
        body.addBlock(DialerUi.text(this,"Loading $selected…"))
        Thread {
            val result=runCatching {
                val profiles=runCatching { DialerNotes.all(c) }.getOrDefault(emptyMap())
                val rows=when(selected){
                    "Contacts" -> DialerData.contacts(c).map { val p=profiles[DialerIdentity.key(it.number)]; Row(it.number,p?.name?.takeIf{ n->n.isNotBlank() } ?: it.name,it.number,tag=p?.tag.orEmpty()) }
                    "Favorites" -> profiles.filterValues{it.favorite}.map{(n,p)-> Row(n,DialerData.name(c,n),n,tag=p.tag)}
                    else -> DialerData.logs(c).filter{!filterMissed || it.type==CallLog.Calls.MISSED_TYPE}.groupBy{ DialerIdentity.key(it.number).ifBlank { "private-${it.id}" } }.values.map{ group-> val l=group.first(); val p=profiles[DialerIdentity.key(l.number)]; Row(l.number,DialerData.callLabel(c,l.number,l.name),"${l.typeLabel()} · ${DialerUi.date(l.date)} · ${group.size} in recent log",l.date,p?.tag.orEmpty(),l.type==CallLog.Calls.MISSED_TYPE) }
                }; rows.filter { term.isBlank() || it.title.contains(term,true) || it.number.contains(term,true) || it.tag.contains(term,true) || (PhoneNumbers.digits(term).isNotEmpty() && PhoneNumbers.digits(it.number).contains(PhoneNumbers.digits(term))) }.take(200)
            }
            runOnUiThread { if(serial != request || isFinishing || isDestroyed) return@runOnUiThread
                body.removeAllViews(); filters(selected)
                val denied=(selected=="Recents" && !DialerData.allowed(this,Manifest.permission.READ_CALL_LOG)) || (selected=="Contacts" && !DialerData.allowed(this,Manifest.permission.READ_CONTACTS))
                if(denied){ body.addBlock(DialerUi.text(this,"$selected unavailable. Manage access in Settings.",15f)); return@runOnUiThread }
                result.onFailure { body.addBlock(DialerUi.text(this,"Could not load $selected.")) }
                result.getOrNull()?.let { rows -> if(rows.isEmpty()) body.addBlock(DialerUi.text(this,"No matching $selected",15f)); rows.forEach { item ->
                    val line=DialerUi.row(this); val info=DialerUi.column(this)
                    val display=item.title.ifBlank{"Private number"}
                    line.addView(DialerUi.avatar(this,display),LinearLayout.LayoutParams(DialerUi.dp(this,46),DialerUi.dp(this,46)).apply{marginEnd=DialerUi.dp(this@DialerActivity,14)})
                    info.addBlock(DialerUi.text(this,display,17f,true),4)
                    val secondary=DialerUi.text(this,item.description,13f).apply{setTextColor(if(item.missed) 0xffba1a1a.toInt() else 0xff5f6368.toInt())};info.addBlock(secondary,2)
                    if(item.tag.isNotBlank()) info.addBlock(DialerUi.text(this,item.tag,12f),0)
                    line.addView(info,LinearLayout.LayoutParams(0,-2,1f)); line.setPadding(0,DialerUi.dp(this,12),0,DialerUi.dp(this,12))
                    val valid=DialerIdentity.key(item.number).isNotBlank()
                    if(valid) line.addView(DialerUi.icon(this,"phone","Call $display"){place(item.number)})
                    line.setOnClickListener { if(valid) startActivity(DialerDetailActivity.intent(this,item.number,item.date)) else DialerUi.toast(this,"Number withheld") }
                    line.setOnLongClickListener { if(!valid) return@setOnLongClickListener false; androidx.appcompat.app.AlertDialog.Builder(this).setTitle(display).setItems(arrayOf("Message","Mark / add note","Customer details")){_,i->when(i){0->PhoneActions.message(this,item.number);1->DialerProfileEditor.show(this,item.number,item.date){refresh()};2->startActivity(DialerDetailActivity.intent(this,item.number,item.date))}}.show();true }
                    body.addBlock(line,0)
                } }
            }
        }.start()
    }
    private fun filters(selected:String){if(selected!="Recents")return; val row=DialerUi.row(this);row.addView(DialerUi.pill(this,"All",!missedOnly){missedOnly=false;refresh()});row.addView(DialerUi.pill(this,"Missed",missedOnly){missedOnly=true;refresh()});body.addBlock(row,4)}
    private var keypadInput: EditText?=null
    private fun keypad(){ body.removeAllViews(); val input=EditText(this).apply{ inputType=android.text.InputType.TYPE_CLASS_PHONE; textSize=28f; gravity=android.view.Gravity.CENTER; showSoftInputOnFocus=false; setSingleLine(true); hint="Enter number" }; keypadInput=input; body.addBlock(input)
        val letters=mapOf("2" to "ABC","3" to "DEF","4" to "GHI","5" to "JKL","6" to "MNO","7" to "PQRS","8" to "TUV","9" to "WXYZ","0" to "+")
        listOf("123","456","789","*0#").forEach{ keys-> val row=DialerUi.row(this); keys.forEach{ digit->val k=digit.toString();val btn=DialerUi.pill(this,k+ (letters[k]?.let{"\n$it"} ?: ""),false){input.append(k)};btn.textSize=22f;btn.minHeight=DialerUi.dp(this,70);btn.gravity=android.view.Gravity.CENTER;if(k=="0")btn.setOnLongClickListener{input.append("+");true};row.addEqual(btn)};body.addBlock(row) }
        val controls=DialerUi.row(this); controls.addEqual(DialerUi.button(this,"+ "){input.append("+")}); controls.addEqual(DialerUi.button(this,"Delete"){if(input.length()>0) input.text.delete(input.length()-1,input.length())}); body.addBlock(controls)
        body.addBlock(DialerUi.button(this,"Call",true){place(input.text.toString())}); body.addBlock(DialerUi.button(this,"Message"){PhoneActions.message(this,input.text.toString())}); body.addBlock(DialerUi.button(this,"Open number details"){ if(DialerIdentity.key(input.text.toString()).isNotBlank()) startActivity(DialerDetailActivity.intent(this,input.text.toString())) })
    }
    private fun place(number:String){ if(number.isBlank() || DialerIdentity.key(number).isBlank()) return; if(!roleHeld()){setup();return}; if(!DialerData.allowed(this,Manifest.permission.CALL_PHONE)){setup();return}; runCatching { requireNotNull(getSystemService(TelecomManager::class.java)).placeCall(Uri.fromParts("tel",number,null),Bundle()) }.onFailure { DialerUi.toast(this,"Unable to place call") } }
}
