# Maahee Phone 2.2.1 (versionCode 12)

Targeted fix for the three Kotlin compiler errors reported by AndroidForge in V2.2.0:

- `DialerActivity.kt:40`: use `this@DialerActivity` for the search field background and padding helpers.
- `DialerActivity.kt:108`: use `this@DialerActivity` for the avatar layout margin helper.

The explicit activity receiver avoids passing an EditText or LinearLayout.LayoutParams where a Context is required. No feature or server changes; proximity handling, speaker, caller notes and supported-device recording features remain as in V2.2.0. Recording still requires privileged call audio access and caller consent.

Build with AndroidForge as before. Same application ID; same signing key is required to upgrade without uninstalling. Full Android build and device validation remain pending.
