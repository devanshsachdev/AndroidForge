package `in`.maahee.pos

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@Composable fun LoginScreen(auth: AuthStore, api: PosApi, onSuccess: (JSONObject) -> Unit) {
    val scope = rememberCoroutineScope()
    var domain by remember { mutableStateOf(auth.url) }
    var identity by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(25.dp),
        verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(77.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Wine, Color(0xFF974B60)))), contentAlignment=Alignment.Center) {
            Text("M", color = Color.White, fontSize=42.sp, fontWeight=FontWeight.Light)
        }
        Spacer(Modifier.height(24.dp))
        Text("MAAHEE", style=MaterialTheme.typography.labelLarge, letterSpacing=3.sp, color=Gold)
        Spacer(Modifier.height(8.dp))
        Text("Your boutique.\nIn your hands.", style=MaterialTheme.typography.headlineLarge, lineHeight=36.sp)
        Spacer(Modifier.height(12.dp))
        Text("A refined mobile workspace for billing, sales and store operations.", color=Subdued)
        Spacer(Modifier.height(35.dp))
        PremiumCard {
            Text("Sign in to POS", style=MaterialTheme.typography.titleLarge)
            OutlinedTextField(domain, onValueChange={domain=it}, label={Text("Secure POS address")},
                singleLine=true, modifier=Modifier.fillMaxWidth(), leadingIcon={Icon(Icons.Outlined.Language,null)})
            OutlinedTextField(identity, onValueChange={identity=it}, label={Text("Username or email")},
                singleLine=true, modifier=Modifier.fillMaxWidth(), leadingIcon={Icon(Icons.Outlined.PersonOutline,null)})
            OutlinedTextField(password, onValueChange={password=it}, label={Text("Password")},
                visualTransformation=PasswordVisualTransformation(), singleLine=true,
                modifier=Modifier.fillMaxWidth(), leadingIcon={Icon(Icons.Outlined.LockOutline,null)})
            if (error.isNotEmpty()) ErrorCard(error)
            Button(onClick={
                auth.url=domain; error=""; loading=true
                scope.launch {
                    try { onSuccess(api.login(identity.trim(), password)) }
                    catch (e:Exception) { error=e.message ?: "Login failed" }
                    finally { loading=false }
                }
            }, enabled=!loading && identity.isNotBlank() && password.isNotBlank() && domain.startsWith("https://"),
                modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(14.dp)) {
                if (loading) CircularProgressIndicator(Modifier.size(20.dp),color=Color.White,strokeWidth=2.dp)
                else { Text("Continue securely");Spacer(Modifier.width(8.dp));Icon(Icons.Outlined.ArrowForward,null) }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("Your staff login is verified by your existing POS server. No credentials are embedded in the app.",
            style=MaterialTheme.typography.bodySmall,color=Subdued)
    }
}

@Composable fun SelectStoreScreen(api: PosApi, onChoose: (Int) -> Unit) {
    var data by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    val scope= rememberCoroutineScope()
    LaunchedEffect(Unit) {
        try { data = api.stores().asObjects() } catch(e:Exception) { error=e.message.orEmpty() } finally { busy=false }
    }
    Column(Modifier.fillMaxSize().background(Cream).padding(22.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(36.dp))
        BrandHeader("Your workplace", "Choose a store", "Select the location you are working at today.")
        if (busy) Busy()
        if (error.isNotEmpty()) ErrorCard(error)
        data.forEach { s ->
            PremiumCard(Modifier.fillMaxWidth().clickable {
                scope.launch { try { api.selectStore(s.optInt("id"));onChoose(s.optInt("id")) }
                    catch(e:Exception) { error=e.message.orEmpty() } }
            }) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Storefront,null,tint=Gold)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.str("name"),style=MaterialTheme.typography.titleMedium)
                        Text(s.str("city"),color=Subdued,style=MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Outlined.ChevronRight,null,tint=Wine)
                }
            }
        }
    }
}

@Composable fun DashboardScreen(api: PosApi, navigate: (String) -> Unit) {
    var metrics by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        loading=true; error=""
        try { metrics=api.dashboard() } catch(e:Exception){error=e.message.orEmpty()} finally{loading=false}
    }
    LazyColumn(Modifier.fillMaxSize().background(Cream),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item { BrandHeader("Your daily pulse","A beautiful day to sell", "Everything happening at your boutique, at a glance.") }
        if (error.isNotEmpty()) item { ErrorCard(error) { reload++ } }
        if (loading) item { Busy() }
        metrics?.let { m ->
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    StatCard("Today's sales",m.money("sales_total").rupees(),"Gross billed",Modifier.weight(1f),true)
                    StatCard("Invoices",m.optInt("sales_count").toString(),"Today's count",Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    StatCard("Payments received",m.money("paid_total").rupees(),"Collected today",Modifier.weight(1f))
                    StatCard("Low stock",m.optInt("low_stock").toString(),"5 units or fewer",Modifier.weight(1f))
                }
            }
            item { SalesSparkline(m.optJSONArray("daily")) }
            item { SectionTitle("Quick actions", "Refresh") { reload++ } }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    ActionCard("New bill",Icons.Outlined.PointOfSale,Modifier.weight(1f)) { navigate("billing") }
                    ActionCard("All sales",Icons.Outlined.ReceiptLong,Modifier.weight(1f)) { navigate("sales") }
                    ActionCard("Inventory",Icons.Outlined.Inventory2,Modifier.weight(1f)) { navigate("products") }
                }
            }
            item { SectionTitle("Recent invoices","See all") { navigate("sales") } }
            val recent=m.optJSONArray("recent")?.asObjects().orEmpty()
            if (recent.isEmpty()) item { EmptyState("No invoices yet","Your latest sales will appear here.") }
            items(recent,key={it.optInt("id")}) { sale ->
                PremiumCard(Modifier.fillMaxWidth().clickable { navigate("sales") }) {
                    InvoiceRow(sale)
                }
            }
        }
    }
}
@Composable private fun ActionCard(label:String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier, onClick:()->Unit) {
    Card(onClick=onClick,modifier=modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(horizontal=12.dp,vertical=18.dp),horizontalAlignment=Alignment.CenterHorizontally,
            verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Icon(icon,null,tint=Wine,modifier=Modifier.size(25.dp))
            Text(label,style=MaterialTheme.typography.labelMedium,maxLines=1)
        }
    }
}
@Composable fun InvoiceRow(sale: JSONObject) {
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Rose),contentAlignment=Alignment.Center) {
            Icon(Icons.Outlined.ReceiptLong,null,tint=Wine)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(sale.str("customer_name").ifBlank{"Walk-in"},fontWeight=FontWeight.SemiBold,maxLines=1)
            Text("#${sale.str("ser_no").ifBlank{sale.str("id")}} • ${sale.str("date").take(10)}",color=Subdued,style=MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment=Alignment.End) {
            Text(sale.money("grand_total").rupees(),fontWeight=FontWeight.Bold,color=Wine)
            Pill(sale.str("status").ifBlank { "sale" }, if(sale.str("status")=="paid") Sage else Wine)
        }
    }
}

@Composable fun SearchBar(value:String,onChange:(String)->Unit,placeholder:String,modifier:Modifier=Modifier) {
    OutlinedTextField(value,onValueChange=onChange,modifier=modifier.fillMaxWidth(),singleLine=true,
        shape=RoundedCornerShape(16.dp),placeholder={Text(placeholder)},leadingIcon={Icon(Icons.Outlined.Search,null)},
        trailingIcon={ if(value.isNotEmpty()) IconButton(onClick={onChange("")}) {Icon(Icons.Outlined.Close,null)} })
}

@Composable fun ProductsScreen(api: PosApi, onBill: () -> Unit) {
    var query by remember{mutableStateOf("")}
    var data by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var error by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(true)}
    LaunchedEffect(query) {delay(260);loading=true;try{data=api.products(query).asObjects()} catch(e:Exception){error=e.message.orEmpty()} finally{loading=false}}
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { BrandHeader("Product library","Inventory", "Live stock and selling prices from your POS.") }
        item { SearchBar(query,{query=it},"Search by product name or barcode") }
        if(error.isNotEmpty())item{ErrorCard(error)}
        if(loading)item{Busy()}
        if(data.isEmpty()&&!loading)item{EmptyState("No products found","Try a different search.")}
        items(data,key={it.optInt("id")}) { p ->
            PremiumCard {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.str("name"),style=MaterialTheme.typography.titleMedium,maxLines=2)
                        Text(p.str("code"),style=MaterialTheme.typography.bodySmall,color=Subdued)
                    }
                    Text(p.money("store_price").rupees(),fontWeight=FontWeight.Bold,color=Wine)
                }
                Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                    Pill("${p.optInt("quantity")} in stock", if(p.optInt("quantity")<=5) Wine else Sage)
                    TextButton(onClick=onBill) { Text("New bill"); Icon(Icons.Outlined.ArrowForward,null,Modifier.size(16.dp)) }
                }
            }
        }
    }
}

@Composable fun SalesScreen(api: PosApi, openSale: (Int)->Unit) {
    var q by remember{mutableStateOf("")}
    var data by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember{mutableStateOf(true)}
    var error by remember{mutableStateOf("")}
    var refresh by remember{mutableIntStateOf(0)}
    LaunchedEffect(q,refresh) { delay(250);loading=true;error="";try{data=api.sales(q).asObjects()}catch(e:Exception){error=e.message.orEmpty()}finally{loading=false} }
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {BrandHeader("Your transactions","Sales ledger","Open invoices and review payment status.")}
        item {SearchBar(q,{q=it},"Customer or invoice number")}
        item {Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) {TextButton(onClick={refresh++}){Icon(Icons.Outlined.Refresh,null);Text("Refresh")}}}
        if(error.isNotEmpty())item{ErrorCard(error)}
        if(loading)item{Busy()}
        if(data.isEmpty()&&!loading)item{EmptyState("No matching sales","New invoices will appear here.")}
        items(data,key={it.optInt("id")}){sale->
            PremiumCard(Modifier.fillMaxWidth().clickable{openSale(sale.optInt("id"))}){InvoiceRow(sale)}
        }
    }
}

@Composable fun CustomersScreen(api: PosApi) {
    var query by remember{mutableStateOf("")}
    var data by remember {mutableStateOf<List<JSONObject>>(emptyList())}
    var loading by remember{mutableStateOf(true)}
    var error by remember{mutableStateOf("")}
    var showNew by remember{mutableStateOf(false)}
    var reload by remember{mutableIntStateOf(0)}
    LaunchedEffect(query,reload) { delay(230); loading=true;error="";try{data=api.customers(query).asObjects()}catch(e:Exception){error=e.message.orEmpty()}finally{loading=false} }
    if (showNew) NewCustomerDialog(api,onDismiss={showNew=false},onSaved={showNew=false;reload++})
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {BrandHeader("Relationships matter","Customers","Search profiles, mobile numbers and loyalty points.")}
        item {Button(onClick={showNew=true},modifier=Modifier.fillMaxWidth()) {Icon(Icons.Outlined.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("Add customer")}}
        item {SearchBar(query,{query=it},"Search customer name or mobile")}
        if(error.isNotEmpty()) item{ErrorCard(error)}
        if(loading)item{Busy()}
        items(data,key={it.optInt("id")}){c->
            PremiumCard {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Rose),contentAlignment=Alignment.Center){
                        Text(c.str("name").take(1).uppercase(),fontWeight=FontWeight.Bold,color=Wine)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.str("name"),fontWeight=FontWeight.SemiBold)
                        Text(c.str("phone"),color=Subdued,style=MaterialTheme.typography.bodySmall)
                    }
                    Pill("${c.optInt("total_points")} pts",Gold)
                }
            }
        }
        if(data.isEmpty()&&!loading)item{EmptyState("No customers","You can add your first customer here.")}
    }
}
@Composable fun NewCustomerDialog(api: PosApi,onDismiss:()->Unit,onSaved:()->Unit) {
    val scope=rememberCoroutineScope()
    var name by remember{mutableStateOf("")}
    var mobile by remember{mutableStateOf("")}
    var email by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("New customer")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            OutlinedTextField(name,{name=it},label={Text("Full name")},singleLine=true)
            OutlinedTextField(mobile,{mobile=it},label={Text("Mobile number")},singleLine=true,
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone))
            OutlinedTextField(email,{email=it},label={Text("Email (optional)")},singleLine=true)
            if(error.isNotEmpty())ErrorCard(error)
        }
    },confirmButton={Button(onClick={loading=true;scope.launch{try{api.createCustomer(name,mobile,email);onSaved()}
        catch(e:Exception){error=e.message.orEmpty()}finally{loading=false}}},
        enabled=!loading&&name.length>=2&&mobile.length>=8){Text("Save customer")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable fun TrackerScreen(api: PosApi) {
    var records by remember{mutableStateOf<List<JSONObject>>(emptyList())}
    var loading by remember{mutableStateOf(true)}
    var error by remember{mutableStateOf("")}
    var refresh by remember{mutableIntStateOf(0)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(refresh){loading=true;try{records=api.tracker().asObjects()}catch(e:Exception){error=e.message.orEmpty()}finally{loading=false}}
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { BrandHeader("Studio workflows","Workshop tracker","Track cutting, stitching, readiness and delivery.") }
        if(error.isNotEmpty())item{ErrorCard(error)}
        if(loading)item{Busy()}
        if(records.isEmpty()&&!loading)item{EmptyState("No tailoring orders","Orders with alterations will be shown here.")}
        items(records,key={it.optInt("id")}){order ->
            var expanded by remember{mutableStateOf(false)}
            PremiumCard {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(order.str("customer_name"),fontWeight=FontWeight.SemiBold)
                        Text("Bill #${order.str("ser_no")} • ${order.str("delivery_date").take(10)}",color=Subdued,style=MaterialTheme.typography.bodySmall)
                    }
                    Pill(order.str("tailoring_status").ifBlank{"Pending"})
                }
                Box {
                    OutlinedButton(onClick={expanded=true}){Text("Update stage");Icon(Icons.Outlined.KeyboardArrowDown,null)}
                    DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                        listOf("Pending","Cutting","Stitching","Ready","Delivered").forEach { stage ->
                            DropdownMenuItem(text={Text(stage)},onClick={expanded=false;
                                scope.launch {try{api.trackerStatus(order.optInt("id"),stage);refresh++}
                                    catch(e:Exception){error=e.message.orEmpty()}}})
                        }
                    }
                }
            }
        }
    }
}

@Composable fun RecordsScreen(api: PosApi, title: String, resource: String) {
    var query by remember{mutableStateOf("")}
    var records by remember{mutableStateOf<List<JSONObject>>(emptyList())}
    var error by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(true)}
    LaunchedEffect(resource,query){delay(250);loading=true;error="";try{records=api.records(resource,query).asObjects()}
        catch(e:Exception){error=e.message.orEmpty()}finally{loading=false}}
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {BrandHeader("Connected records",title,"Live view of your existing POS data.")}
        item {SearchBar(query,{query=it},"Search $title")}
        if(error.isNotEmpty())item{ErrorCard(error)}
        if(loading)item{Busy()}
        if(records.isEmpty()&&!loading)item{EmptyState("No records found","This module has no matching records.")}
        items(records,key={it.optInt("id")}){r->
            val keys=listOf("name","reference","supplier_name","card_no","credit_note_no","date","code")
            val primary=keys.firstNotNullOfOrNull{ k ->r.str(k).takeIf{it.isNotBlank()} }?:"Record #${r.optInt("id")}"
            val amount=listOf("grand_total","balance","amount","value").firstOrNull{r.has(it)}
            PremiumCard {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(primary,fontWeight=FontWeight.SemiBold)
                        Text("Record #${r.optInt("id")}",color=Subdued,style=MaterialTheme.typography.bodySmall)
                    }
                    if(amount!=null)Text(r.money(amount).rupees(),fontWeight=FontWeight.Bold,color=Wine)
                }
                val detail=r.keys().asSequence().filter{it!="id"&&it !in keys && it!=amount}.take(3)
                    .map { "$it: ${r.optString(it)}" }.joinToString("   •   ")
                if(detail.isNotBlank())Text(detail,style=MaterialTheme.typography.bodySmall,color=Subdued,maxLines=2)
            }
        }
    }
}

@Composable fun ModuleMenuScreen(auth: AuthStore, navigate: (ModuleItem)->Unit, logout:()->Unit, switchStore:()->Unit) {
    var query by remember{mutableStateOf("")}
    val groups=remember(query){allModules.filter{it.title.contains(query,true)||it.group.contains(query,true)}.groupBy{it.group}}
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {BrandHeader("Everything in one place","All modules","${allModules.size} POS workspace destinations, organized for your team.")}
        item {PremiumCard {
            Text(auth.name,style=MaterialTheme.typography.titleMedium)
            Text("Store #${auth.storeId} • Connected securely",color=Sage,style=MaterialTheme.typography.bodySmall)
            Row {TextButton(onClick=switchStore){Text("Change store")};Spacer(Modifier.weight(1f));TextButton(onClick=logout){Text("Sign out")}}
        }}
        item {SearchBar(query,{query=it},"Find a feature or page")}
        groups.forEach{(group,modules)->
            item{Text(group.uppercase(),fontWeight=FontWeight.Bold,letterSpacing=1.sp,color=Gold,style=MaterialTheme.typography.labelSmall,
                modifier=Modifier.padding(top=10.dp,bottom=2.dp))}
            items(modules){m->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).clickable{navigate(m)}
                    .padding(horizontal=14.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(if(m.kind=="planned")Icons.Outlined.LockClock else Icons.Outlined.ChevronRight,null,
                        tint=if(m.kind=="planned")Subdued else Wine,modifier=Modifier.size(18.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(m.title,Modifier.weight(1f),style=MaterialTheme.typography.bodyMedium)
                    if(m.kind!="planned")Pill("LIVE",Sage)
                    else Text("Planned",style=MaterialTheme.typography.labelSmall,color=Subdued)
                }
            }
        }
    }
}

@Composable fun ModuleScreen(m: ModuleItem, api: PosApi, onBill:()->Unit, onSale:(Int)->Unit) {
    when(m.kind){
        "dashboard"->DashboardScreen(api,{})
        "billing"->BillingScreen(api,onSale)
        "sales"->SalesScreen(api,onSale)
        "products"->ProductsScreen(api,onBill)
        "customers"->CustomersScreen(api)
        "tracker"->TrackerScreen(api)
        "register"->RegisterScreen(api)
        else -> if(m.kind.startsWith("records:")) RecordsScreen(api,m.title,m.kind.substringAfter(':'))
        else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Cream).padding(22.dp),
            verticalArrangement=Arrangement.spacedBy(20.dp)) {
            BrandHeader(m.group,m.title,"This area is included in the native navigation design.")
            PremiumCard {
                Icon(Icons.Outlined.Construction,null,tint=Gold,modifier=Modifier.size(42.dp))
                Text("Native workflow pending",style=MaterialTheme.typography.titleLarge)
                Text("The original POS provides this page, but the mobile API doesn't yet support its full operations. " +
                    "It is intentionally not presented as working, to protect your data and accounting.",color=Subdued)
                DividerLine()
                Text("Existing server path: ${m.legacyPath}",style=MaterialTheme.typography.bodySmall)
                if(m.sourceStatus=="Unresolved")ErrorCard("This path was also unresolved in the source-code route audit.")
            }
        }
    }
}
