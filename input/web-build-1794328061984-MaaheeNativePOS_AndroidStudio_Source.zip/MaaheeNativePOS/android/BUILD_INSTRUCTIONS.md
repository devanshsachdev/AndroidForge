# Build the Android app

This ZIP contains an **Android Studio Gradle project**, not a prebuilt APK. The code was authored in an environment without the Android SDK, Gradle distribution, or dependency download access. Build and test it before sideloading to staff devices.

1. Install a current Android Studio, JDK 17, Android SDK Platform 35, SDK Build Tools 35.0.0 and Gradle 8.9.
2. This source archive contains Gradle version metadata but **no official Gradle wrapper JAR**. On a machine with Gradle 8.9 installed, run `gradle wrapper --gradle-version 8.9` inside `android/`. This creates the official wrapper JAR and launch scripts. Alternatively, use a local Gradle 8.9 installation configured in Android Studio.
3. Open the `android/` directory in Android Studio and sync the project. Fix any dependency or API build errors before use.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or `./gradlew assembleDebug` after generating the wrapper.
5. Connect to the staging POS backend and execute the checklist in `../docs/QA_CHECKLIST.md`.
6. For production, configure app signing, separate product flavors or environments, release security review, play policy review and an update strategy.

If you put the **contents** of `android/` at the root of a GitHub repository, the included Actions workflow will provision Android SDK and Gradle and upload a debug APK to the build's Artifacts section. Treat the first build as a validation build and inspect the logs for compile or runtime issues.
