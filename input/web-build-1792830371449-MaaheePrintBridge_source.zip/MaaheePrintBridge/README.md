# Maahee Print Bridge — Shreyans P58D (experimental)

## What this is
Native Android Print Service for printing **the PDF received from Chrome's ordinary Android Print dialog**, without redesigning barcode templates. It advertises 48 × 30 mm paper and a custom editable paper size. It sends monochrome raster output over Bluetooth Classic SPP using ESC/POS `GS v 0`.

**This is test source, not a proven P58D driver**. The P58D protocol (ESC/POS vs CPCL / proprietary vs BLE), density/speed device commands, hardware gap-sensor and paper positioning have not been verified. The app's contrast setting is software raster threshold; 'speed' changes transmission pacing, not physical print motor speed. Gap feed is not gap detection. Printing can fail or shift labels if your printer is not ESC/POS compatible.

## How to build
1. Install Android Studio with Android SDK API 35 and JDK 17.
2. Open `MaaheePrintBridge` folder, allow Gradle sync and select Build > Build APK(s).
3. Install on Android 8.0+ device; pair P58D in Bluetooth settings.
4. Open Maahee Print Bridge, grant Bluetooth permission, select the paired printer.
5. Open Android Settings > Printing and **enable Maahee Print Bridge**.
6. In your POS in Chrome, use the existing Print button, select **Shreyans P58D**, choose **48 × 30 mm** and inspect the preview before printing.
7. Start with a test using expendable paper. If no output or incorrect output, do not repeatedly print; obtain manufacturer SDK/protocol first.

## Important limitations
- Not built or tested against a physical printer in this environment.
- No APK included: Android SDK/Gradle environment unavailable here.
- Android's print dialog and Chrome choose when to reuse a saved destination. A third-party print service cannot force itself to open or become the default automatically.
- The native print dialog only lists paper sizes advertised by the service, not freeform custom input. Enter a custom size in the plugin, then reopen the print dialog.
- Some browser page styles assume A4/Letter regardless of selected media. Fix `@page` rules in POS **only if** Chrome preview fails to honor paper size.
- Bluetooth SPP is required for this prototype. BLE-only or vendor-proprietary protocols need a different adapter.
- 'Print complete' here means bytes transmitted to Bluetooth, not physical print confirmation.
- Not intended for arbitrary long multi-page A4/PDF jobs.
- The print service currently does not handle complex printer status / calibration and should not be used unattended in production.

## Reference app
The user's latest message mentions a printer-compatible reference app, but no app name, APK, or Play Store URL accompanied it. Compare its connection protocol/SDK before final hardware driver development.
