package `in`.maahee.printbridge

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun label(text: String) { root.addView(TextView(this).apply { this.text = text; textSize = 16f; setPadding(0, 18, 0, 6) }) }
    private fun button(text: String, run: () -> Unit) { root.addView(Button(this).apply { this.text = text; setOnClickListener { run() } }) }
    private fun input(default: String): EditText = EditText(this).apply { setText(default); inputType = 2; root.addView(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 35, 30, 35) }
        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams(-1,-2)) })
        label("Maahee Print Bridge — P58D testing driver")
        label("1. Pair the printer in Android Bluetooth settings. Then grant Nearby devices permission and select it here.")
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            button("Grant Bluetooth permission") { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12) }
        }
        button("Refresh paired printers") { showPrinters() }
        label("Selected printer MAC: " + (BridgePrefs.address(this).ifEmpty { "None" }))
        button("Open Android Print Service settings") { startActivity(Intent(Settings.ACTION_PRINT_SETTINGS)) }
        label("Print width (mm), height (mm). Restart print dialog after changes.")
        val w = input(BridgePrefs.paperWidth(this).toString()); val h = input(BridgePrefs.paperHeight(this).toString())
        button("Save label dimensions") {
            val wi = w.text.toString().toIntOrNull(); val he = h.text.toString().toIntOrNull()
            if (wi != null && he != null && wi in 20..58 && he in 10..300) { BridgePrefs.setPaper(this, wi, he); toast("Saved. Reopen Chrome print dialog.") }
            else toast("Use 20–58mm width and 10–300mm height")
        }
        label("Raster threshold: Light / Medium / Dark (software contrast, not guaranteed hardware density)")
        val density = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Light", "Medium", "Dark")); setSelection(BridgePrefs.density(this@MainActivity).coerceIn(0,2)); root.addView(this) }
        label("Bluetooth send pacing (experimental)")
        val speed = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Conservative", "Normal", "Fast")); setSelection(BridgePrefs.speed(this@MainActivity).coerceIn(0,2)); root.addView(this) }
        label("Extra feed after page, lines (0 recommended; not true gap-sensor calibration)")
        val feed = input(BridgePrefs.gapFeed(this).toString())
        button("Save thermal settings") { BridgePrefs.setDensity(this,density.selectedItemPosition); BridgePrefs.setSpeed(this,speed.selectedItemPosition); BridgePrefs.setGapFeed(this,feed.text.toString().toIntOrNull()?.coerceIn(0,20) ?: 0); toast("Saved") }
        button("Send ESC/POS test text") {
            Thread {
                try { BluetoothEscPos(this).test(); runOnUiThread { toast("Test data sent (confirm paper output)") } }
                catch (e: Exception) { runOnUiThread { toast("Printer test failed: ${e.message}") } }
            }.start()
        }
        label("NOTE: This is an ESC/POS Bluetooth SPP test driver. P58D protocol, actual hardware density/speed commands, and gap detection are not yet verified. It will NOT work with proprietary-only or BLE-only printers without a compatible driver.")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun showPrinters() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 12); return }
        try {
            val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
            val devices = adapter?.bondedDevices?.sortedBy { it.name ?: it.address }.orEmpty()
            if (devices.isEmpty()) { toast("No paired Bluetooth devices"); return }
            val names = devices.map { (it.name ?: "Unnamed") + " (" + it.address + ")" }.toTypedArray()
            android.app.AlertDialog.Builder(this).setTitle("Choose paired printer").setItems(names) { _, index ->
                BridgePrefs.setAddress(this, devices[index].address)
                toast("Selected " + names[index] + ". Reopen print dialog.")
                recreate()
            }.show()
        } catch(e: SecurityException) { toast("Grant Nearby devices permission") }
    }
}
