package `in`.maahee.printbridge

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import java.io.OutputStream
import java.util.UUID
import kotlin.math.min

/** Experimental Bluetooth Classic SPP + ESC/POS raster driver, NOT a verified P58D driver. */
class BluetoothEscPos(private val context: Context) {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private fun connectAndRun(action: (OutputStream) -> Unit) {
        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            throw SecurityException("Grant Nearby Devices permission in the app")
        val address = BridgePrefs.address(context)
        require(address.isNotEmpty()) { "Select the paired printer in app settings" }
        val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: error("Bluetooth is unavailable")
        val device = adapter.getRemoteDevice(address)
        val socket = device.createRfcommSocketToServiceRecord(spp)
        try {
            socket.connect()
            val stream = socket.outputStream
            action(stream)
            stream.flush()
        } finally { try { socket.close() } catch (_: Exception) {} }
    }
    fun test() = connectAndRun { out ->
        out.write(byteArrayOf(0x1b, 0x40))
        out.write("MAAHEE P58D TEST\nBluetooth ESC/POS SPP\n\n".toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf(0x0a,0x0a))
    }
    fun printPdf(fd: ParcelFileDescriptor, attributes: PrintAttributes, copies: Int) {
        // Android Print Framework hands services a PDF. Render the PDF as-is, never re-create its barcode.
        val widthMils = attributes.mediaSize?.widthMils ?: 1890
        val widthDots = min(384, (widthMils / 1000.0 * 203).toInt()).coerceAtLeast(8)
        val alignedDots = widthDots / 8 * 8
        val renderer = PdfRenderer(fd)
        try {
            connectAndRun { out ->
                out.write(byteArrayOf(0x1b, 0x40))
                repeat(copies.coerceIn(1, 1000)) {
                    for (pageIndex in 0 until renderer.pageCount) {
                        renderer.openPage(pageIndex).use { page ->
                            val targetHeight = (page.height.toDouble() * alignedDots / page.width).toInt().coerceAtLeast(1)
                            // Label jobs should be short; guard RAM before allocating.
                            require(targetHeight <= 5000) { "Page too long: choose the label paper size in Chrome" }
                            val bitmap = Bitmap.createBitmap(alignedDots, targetHeight, Bitmap.Config.ARGB_8888)
                            try {
                                bitmap.eraseColor(Color.WHITE)
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                sendRaster(bitmap, out)
                            } finally { bitmap.recycle() }
                        }
                    }
                }
            }
        } finally { renderer.close() }
    }
    private fun sendRaster(bitmap: Bitmap, out: OutputStream) {
        val width = bitmap.width
        val bandRows = 96
        val widthBytes = width / 8
        val contrast = BridgePrefs.density(context)
        val threshold = when (contrast) { 0 -> 115; 2 -> 195; else -> 155 }
        val pacing = when (BridgePrefs.speed(context)) { 0 -> 40L; 2 -> 0L; else -> 15L }
        for (startY in 0 until bitmap.height step bandRows) {
            val rows = min(bandRows, bitmap.height - startY)
            // GS v 0: raster image. Not guaranteed supported by P58D firmware.
            out.write(byteArrayOf(0x1d, 0x76, 0x30, 0x00,
                (widthBytes and 0xff).toByte(), (widthBytes shr 8).toByte(),
                (rows and 0xff).toByte(), (rows shr 8).toByte()))
            val bits = ByteArray(widthBytes * rows)
            val pixels = IntArray(width)
            for (row in 0 until rows) {
                bitmap.getPixels(pixels, 0, width, 0, startY + row, width, 1)
                for (x in 0 until width) {
                    val color = pixels[x]
                    val grey = (Color.red(color)*299 + Color.green(color)*587 + Color.blue(color)*114)/1000
                    if (grey < threshold) {
                        val index = row * widthBytes + x / 8
                        bits[index] = (bits[index].toInt() or (0x80 shr (x % 8))).toByte()
                    }
                }
            }
            out.write(bits)
            out.flush()
            if (pacing > 0) Thread.sleep(pacing)
        }
        val feed = BridgePrefs.gapFeed(context)
        if (feed > 0) out.write(byteArrayOf(0x1b, 0x64, feed.toByte()))
    }
}
