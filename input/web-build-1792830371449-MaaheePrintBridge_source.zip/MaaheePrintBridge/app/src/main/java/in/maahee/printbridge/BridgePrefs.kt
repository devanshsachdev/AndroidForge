package `in`.maahee.printbridge

import android.content.Context

object BridgePrefs {
    private fun p(context: Context) = context.getSharedPreferences("printer", Context.MODE_PRIVATE)
    fun address(context: Context) = p(context).getString("address", "") ?: ""
    fun setAddress(context: Context, address: String) = p(context).edit().putString("address", address).apply()
    fun density(context: Context) = p(context).getInt("density", 2)
    fun setDensity(context: Context, v: Int) = p(context).edit().putInt("density", v).apply()
    fun speed(context: Context) = p(context).getInt("speed", 1)
    fun setSpeed(context: Context, v: Int) = p(context).edit().putInt("speed", v).apply()
    fun gapFeed(context: Context) = p(context).getInt("gap_feed", 0)
    fun setGapFeed(context: Context, v: Int) = p(context).edit().putInt("gap_feed", v).apply()
    fun paperWidth(context: Context) = p(context).getInt("width", 48)
    fun paperHeight(context: Context) = p(context).getInt("height", 30)
    fun setPaper(context: Context, w: Int, h: Int) = p(context).edit().putInt("width", w).putInt("height", h).apply()
}
