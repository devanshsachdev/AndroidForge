package `in`.maahee.printbridge

import android.print.PrintAttributes
import android.print.PrintDocumentInfo
import android.print.PrinterCapabilitiesInfo
import android.print.PrinterId
import android.print.PrinterInfo
import android.printservice.PrintJob
import android.printservice.PrintService
import android.printservice.PrinterDiscoverySession
import android.os.Build

class MaaheePrintService : PrintService() {
    override fun onCreatePrinterDiscoverySession(): PrinterDiscoverySession = Discovery()
    override fun onRequestCancelPrintJob(job: PrintJob) { job.cancel() }
    override fun onPrintJobQueued(job: PrintJob) {
        Thread {
            try {
                if (!job.start()) return@Thread
                val fd = job.document.data ?: throw IllegalStateException("Print document unavailable")
                val attributes = job.info.attributes
                val paperWidthMils = attributes.mediaSize?.widthMils ?: 1890
                val paperHeightMils = attributes.mediaSize?.heightMils ?: 1181
                val widthMm = paperWidthMils / 39.3700787
                val heightMm = paperHeightMils / 39.3700787
                if (widthMm > 58.5 || widthMm < 15 || heightMm < 8) {
                    throw IllegalArgumentException("Select a label paper size no wider than 58mm")
                }
                BluetoothEscPos(this).printPdf(fd, attributes, job.info.copies.coerceAtLeast(1))
                job.complete() // Data was sent, not physical printing confirmation.
            } catch (e: Exception) {
                job.fail("Unable to send to Shreyans P58D: ${e.message}")
            }
        }.start()
    }

    inner class Discovery : PrinterDiscoverySession() {
        private val printerId: PrinterId = generatePrinterId("p58d")
        override fun onStartPrinterDiscovery(priorityList: MutableList<PrinterId>) { refresh() }
        override fun onStopPrinterDiscovery() {}
        override fun onValidatePrinters(printerIds: MutableList<PrinterId>) { refresh() }
        override fun onStartPrinterStateTracking(printerId: PrinterId) { refresh() }
        override fun onStopPrinterStateTracking(printerId: PrinterId) {}
        override fun onDestroy() {}
        private fun refresh() {
            val addr = BridgePrefs.address(this@MaaheePrintService)
            if (addr.isBlank()) { removePrinters(printers.map { it.id }); return }
            val media = PrintAttributes.MediaSize("maahee_48x30", "48 × 30 mm", 1890, 1181)
            val width = BridgePrefs.paperWidth(this@MaaheePrintService)
            val height = BridgePrefs.paperHeight(this@MaaheePrintService)
            val custom = PrintAttributes.MediaSize("maahee_custom_${width}x${height}", "$width × $height mm", (width * 1000 / 25.4).toInt(), (height * 1000 / 25.4).toInt())
            val builder = PrinterCapabilitiesInfo.Builder(printerId)
                .addMediaSize(media, true)
                .addResolution(PrintAttributes.Resolution("203dpi", "203 dpi", 203, 203), true)
                .setColorModes(PrintAttributes.COLOR_MODE_MONOCHROME, PrintAttributes.COLOR_MODE_MONOCHROME)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            if (custom.id != media.id) builder.addMediaSize(custom, false)
            val printer = PrinterInfo.Builder(printerId, "Shreyans P58D ($addr)", PrinterInfo.STATUS_IDLE)
                .setCapabilities(builder.build())
                .build()
            addPrinters(listOf(printer))
        }
    }
}
