# Maahee Caller ID V1.5 — Sync Repair + Diagnostic

Build this Android ZIP with AndroidForge, **not** the POS API ZIP.

## Install
1. Back up POS file `app/controllers/api/Caller.php`. Replace it with the new V1.5 API file (no changes to `app/config/caller_api.php` or its bearer token).
2. Build Android ZIP in AndroidForge. Install over existing Maahee Caller ID without uninstalling to retain API URL/token and cached data (same signing certificate required).
3. On a connected phone, open Maahee Caller ID and tap **CHECK POS SYNC ENDPOINT**. Read/copy persistent detailed result. It should show API v1.5, Store 3 and first page rows.
4. Tap **SYNC STORE 3 FOR OFFLINE CALLS**; now each successful page is encrypted and saved immediately. Full sync finalizes a coherent new directory.
5. Type a known customer number and tap **SAVE TEST CUSTOMER FOR OFFLINE CALLS**, then **TEST OFFLINE CACHE (NO INTERNET)**. If this succeeds, incoming-call card can work without DNS.
6. Enable Auto-sync if desired. Android schedules best-effort periodic jobs with any network, not just unmetered Wi-Fi. Samsung can defer jobs.

## Diagnostics
- HTTP 401 = wrong API token.
- HTTP 404 = server API controller not updated or route unavailable.
- HTTP 500 = PHP/database error on server; check `app/logs/` and cPanel `error_log`.
- DNS UnknownHost = phone network/DNS; manual cached customer still available after successful online lookup.
- 0 rows = Store 3 data query/phone mismatch.
- Partial sync: the page count and partial saved records are visible; no successful page is discarded by later HTTP errors.

## Security
- POS API must remain protected by bearer token and HTTPS.
- Cache uses app-private Android Keystore AES-256-GCM encrypted files.
- Only Store 3 records are exposed.
- Do not publish server token in GitHub, screenshots or build logs. Rotate the token if it was previously exposed.

Full Gradle build has not been run in this environment. PHP syntax and Android XML are checked during packaging.
