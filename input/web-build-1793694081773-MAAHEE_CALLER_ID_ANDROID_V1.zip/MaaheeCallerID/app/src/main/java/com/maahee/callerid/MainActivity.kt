package com.maahee.callerid

import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status=findViewById(R.id.statusText)
        val api=findViewById<EditText>(R.id.apiUrl)
        val token=findViewById<EditText>(R.id.apiToken)
        api.setText(Prefs.apiUrl(this)); token.setText(Prefs.token(this))
        findViewById<Button>(R.id.btnSave).setOnClickListener{
            Prefs.save(this,api.text.toString(),token.text.toString())
            Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnScreening).setOnClickListener{ requestScreeningRole() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener{
            if(!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener{
            Prefs.save(this,api.text.toString(),token.text.toString())
            val p=findViewById<EditText>(R.id.testPhone).text.toString().trim()
            if(p.isBlank()) Toast.makeText(this,"Enter a phone number",Toast.LENGTH_SHORT).show()
            else CallerOverlay.showAndLookup(applicationContext,p)
        }
    }
    override fun onResume(){ super.onResume(); updateStatus() }
    private fun requestScreeningRole(){
        val rm=getSystemService(RoleManager::class.java)
        if(rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING))
            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),101)
        else updateStatus()
    }
    private fun updateStatus(){
        val rm=getSystemService(RoleManager::class.java)
        val screen=rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        val overlay=Settings.canDrawOverlays(this)
        status.text="Call Screening: ${if(screen) "ENABLED" else "NOT ENABLED"}
Display over apps: ${if(overlay) "ALLOWED" else "NOT ALLOWED"}
API: ${Prefs.apiUrl(this)}"
    }
}
