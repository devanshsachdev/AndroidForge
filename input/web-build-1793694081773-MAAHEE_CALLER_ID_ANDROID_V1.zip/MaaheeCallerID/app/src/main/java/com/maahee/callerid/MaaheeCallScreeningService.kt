package com.maahee.callerid

import android.telecom.Call
import android.telecom.CallScreeningService

class MaaheeCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSilenceCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()

        if (callDetails.callDirection == Call.Details.DIRECTION_INCOMING) {
            val number = callDetails.handle?.schemeSpecificPart.orEmpty()
            if (number.isNotBlank()) CallerOverlay.showAndLookup(applicationContext, number)
        }
        // Never delay/block the ringing call for a network lookup.
        respondToCall(callDetails, response)
    }
}
