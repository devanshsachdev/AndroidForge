# Maahee Caller ID V1

Native Android 10+ caller lookup app for Maahee POS.

## What it does
- Requests Android Call Screening role.
- Requests Display Over Other Apps permission.
- On incoming screened call, immediately allows the call and shows a floating Maahee card.
- Calls `https://pos.maahee.co.in/api/caller/lookup?phone=...`.
- Shows customer + last 3 Store 3 purchases + balance + alteration ticket/status/delivery date.
- Buttons open Customer, latest Invoice and Tracker in the POS.
- No READ_CALL_LOG permission.

## API token preconfigured in this project
`mci_z1feGBoROOWaax5L6rAdKqTkFs_1M5o7TQghvj-D9r0`

The same token is in the included server patch. Rotate both if you distribute the APK outside your staff devices.

## Android limitation
Android's official CallScreeningService documentation says screening callbacks are for numbers not in the user's contacts list. For a guaranteed popup on *all saved contacts too*, a later version would need a more invasive default Phone/Dialer design.

## Build
Open this folder in Android Studio with JDK 17, sync Gradle, then Build > Build APK(s).

## First run
1. Enable Call Screening.
2. Allow Display Over Other Apps.
3. Confirm API URL/token.
4. Use Test POS Lookup Popup with a known customer phone.
5. Make a real incoming call from a number not stored in Contacts.
